import React from 'react';
import { PageHeader } from '../../shared/components/ui/PageHeader';
import { useAcademic } from '../academic/hooks/useAcademic';
import { CollegesTab } from '../academic/components/CollegesTab';

export const CollegesListPage: React.FC = () => {
  const { colleges, addCollege, editCollege, deactivateCollege } = useAcademic();

  return (
    <div className="space-y-6 pb-12">
      <PageHeader
        title="VTU Affiliated & Autonomous Colleges Directory"
        description="Master registry of engineering colleges across Bengaluru, Mysuru, Belagavi, and Kalaburagi regions."
      />

      <CollegesTab
        colleges={colleges}
        onAddCollege={addCollege}
        onEditCollege={editCollege}
        onDeactivateCollege={deactivateCollege}
      />
    </div>
  );
};

