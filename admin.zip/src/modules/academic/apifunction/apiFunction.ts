import { apiClient } from '../../../shared/api/apiClient';
import { Scheme, Branch, Semester, CourseType, Course, College, Department } from '../types/type';

const extractArray = <T>(res: any): T[] => {
  if (Array.isArray(res)) return res;
  if (Array.isArray(res?.data)) return res.data;
  if (Array.isArray(res?.data?.data)) return res.data.data;
  return [];
};

const extractObject = <T>(res: any): T => {
  if (res?.data && typeof res.data === 'object' && !Array.isArray(res.data)) {
    return res.data;
  }
  return res;
};

// ------------------------------------------
// 1. SCHEMES API FUNCTIONS
// ------------------------------------------
export const getSchemesApiFunction = async (): Promise<Scheme[]> => {
  const response = await apiClient.get('/academics/schemes');
  return extractArray<Scheme>(response.data);
};

export const getSchemeByIdApiFunction = async (id: string): Promise<Scheme> => {
  const response = await apiClient.get(`/academics/schemes/${id}`);
  return extractObject<Scheme>(response.data);
};

export const createSchemeApiFunction = async (payload: Partial<Scheme>): Promise<Scheme> => {
  const response = await apiClient.post('/academics/schemes', payload);
  return extractObject<Scheme>(response.data);
};

export const updateSchemeApiFunction = async (id: string, payload: Partial<Scheme>): Promise<Scheme> => {
  const response = await apiClient.patch(`/academics/schemes/${id}`, payload);
  return extractObject<Scheme>(response.data);
};

export const deleteSchemeApiFunction = async (id: string): Promise<Scheme> => {
  const response = await apiClient.delete(`/academics/schemes/${id}`);
  return extractObject<Scheme>(response.data);
};

// ------------------------------------------
// 2. BRANCHES API FUNCTIONS
// ------------------------------------------
export const getBranchesApiFunction = async (): Promise<Branch[]> => {
  const response = await apiClient.get('/academics/branches');
  return extractArray<Branch>(response.data);
};

export const getBranchByIdApiFunction = async (id: string): Promise<Branch> => {
  const response = await apiClient.get(`/academics/branches/${id}`);
  return extractObject<Branch>(response.data);
};

export const createBranchApiFunction = async (payload: Partial<Branch>): Promise<Branch> => {
  const response = await apiClient.post('/academics/branches', payload);
  return extractObject<Branch>(response.data);
};

export const updateBranchApiFunction = async (id: string, payload: Partial<Branch>): Promise<Branch> => {
  const response = await apiClient.patch(`/academics/branches/${id}`, payload);
  return extractObject<Branch>(response.data);
};

export const deleteBranchApiFunction = async (id: string): Promise<Branch> => {
  const response = await apiClient.delete(`/academics/branches/${id}`);
  return extractObject<Branch>(response.data);
};

// ------------------------------------------
// 3. SEMESTERS API FUNCTIONS
// ------------------------------------------
export const getSemestersApiFunction = async (): Promise<Semester[]> => {
  const response = await apiClient.get('/academics/semesters');
  return extractArray<Semester>(response.data);
};

// ------------------------------------------
// 4. COURSE TYPES (CATEGORIES) API FUNCTIONS
// ------------------------------------------
export const getCourseTypesApiFunction = async (): Promise<CourseType[]> => {
  const response = await apiClient.get('/academics/course-types');
  return extractArray<CourseType>(response.data);
};

export const createCourseTypeApiFunction = async (payload: Partial<CourseType>): Promise<CourseType> => {
  const response = await apiClient.post('/academics/course-types', payload);
  return extractObject<CourseType>(response.data);
};

export const updateCourseTypeApiFunction = async (id: string, payload: Partial<CourseType>): Promise<CourseType> => {
  const response = await apiClient.patch(`/academics/course-types/${id}`, payload);
  return extractObject<CourseType>(response.data);
};

export const deleteCourseTypeApiFunction = async (id: string): Promise<CourseType> => {
  const response = await apiClient.delete(`/academics/course-types/${id}`);
  return extractObject<CourseType>(response.data);
};

// ------------------------------------------
// 5. COURSES (SYLLABUS/SUBJECTS) API FUNCTIONS
// ------------------------------------------
export const getCoursesApiFunction = async (params?: {
  schemeId?: string;
  branchId?: string;
  semesterId?: string;
  status?: string;
}): Promise<Course[]> => {
  const response = await apiClient.get('/academics/courses', { params });
  return extractArray<Course>(response.data);
};

export const getCourseByIdApiFunction = async (id: string): Promise<Course> => {
  const response = await apiClient.get(`/academics/courses/${id}`);
  return extractObject<Course>(response.data);
};

export const createCourseApiFunction = async (payload: Partial<Course>): Promise<Course> => {
  const response = await apiClient.post('/academics/courses', payload);
  return extractObject<Course>(response.data);
};

export const updateCourseApiFunction = async (id: string, payload: Partial<Course>): Promise<Course> => {
  const response = await apiClient.patch(`/academics/courses/${id}`, payload);
  return extractObject<Course>(response.data);
};

export const updateCourseModulesApiFunction = async (courseId: string, modules: any[]): Promise<Course> => {
  const response = await apiClient.post(`/academics/courses/${courseId}/modules`, { modules });
  return extractObject<Course>(response.data);
};

export const deleteCourseApiFunction = async (id: string): Promise<Course> => {
  const response = await apiClient.delete(`/academics/courses/${id}`);
  return extractObject<Course>(response.data);
};

// ------------------------------------------
// 6. COLLEGES API FUNCTIONS
// ------------------------------------------
export const getCollegesApiFunction = async (): Promise<College[]> => {
  const response = await apiClient.get('/academics/colleges');
  return extractArray<College>(response.data);
};

export const getCollegeByIdApiFunction = async (id: string): Promise<College> => {
  const response = await apiClient.get(`/academics/colleges/${id}`);
  return extractObject<College>(response.data);
};

export const createCollegeApiFunction = async (payload: Partial<College>): Promise<College> => {
  const response = await apiClient.post('/academics/colleges', payload);
  return extractObject<College>(response.data);
};

export const updateCollegeApiFunction = async (id: string, payload: Partial<College>): Promise<College> => {
  const response = await apiClient.patch(`/academics/colleges/${id}`, payload);
  return extractObject<College>(response.data);
};

export const deleteCollegeApiFunction = async (id: string): Promise<College> => {
  const response = await apiClient.delete(`/academics/colleges/${id}`);
  return extractObject<College>(response.data);
};

// ------------------------------------------
// 7. BULK IMPORT API FUNCTIONS
// ------------------------------------------
export const bulkImportSchemesApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/schemes/bulk', dtos);
  return response.data;
};

export const bulkImportBranchesApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/branches/bulk', dtos);
  return response.data;
};

export const bulkImportCourseTypesApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/course-types/bulk', dtos);
  return response.data;
};

export const bulkImportCoursesApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/courses/bulk', dtos);
  return response.data;
};

export const bulkImportCollegesApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/colleges/bulk', dtos);
  return response.data;
};

// ------------------------------------------
// 8. DEPARTMENTS API FUNCTIONS
// ------------------------------------------
export const getDepartmentsApiFunction = async (): Promise<Department[]> => {
  const response = await apiClient.get('/academics/departments');
  return extractArray<Department>(response.data);
};

export const getDepartmentByIdApiFunction = async (id: string): Promise<Department> => {
  const response = await apiClient.get(`/academics/departments/${id}`);
  return extractObject<Department>(response.data);
};

export const createDepartmentApiFunction = async (payload: Partial<Department>): Promise<Department> => {
  const response = await apiClient.post('/academics/departments', payload);
  return extractObject<Department>(response.data);
};

export const updateDepartmentApiFunction = async (id: string, payload: Partial<Department>): Promise<Department> => {
  const response = await apiClient.patch(`/academics/departments/${id}`, payload);
  return extractObject<Department>(response.data);
};

export const deleteDepartmentApiFunction = async (id: string): Promise<Department> => {
  const response = await apiClient.delete(`/academics/departments/${id}`);
  return extractObject<Department>(response.data);
};

export const bulkImportDepartmentsApiFunction = async (dtos: any[]) => {
  const response = await apiClient.post('/academics/departments/bulk', dtos);
  return response.data;
};
