import { useState, useCallback, useEffect } from 'react';
import { Scheme, Branch, Semester, CourseType, Course, College, Department } from '../types/type';
import { toast } from '../../../shared/components/toast/ToastContext';
import {
  getSchemesApiFunction,
  createSchemeApiFunction,
  updateSchemeApiFunction,
  deleteSchemeApiFunction,
  getDepartmentsApiFunction,
  createDepartmentApiFunction,
  updateDepartmentApiFunction,
  deleteDepartmentApiFunction,
  bulkImportDepartmentsApiFunction,
  getBranchesApiFunction,
  createBranchApiFunction,
  updateBranchApiFunction,
  deleteBranchApiFunction,
  getSemestersApiFunction,
  getCourseTypesApiFunction,
  createCourseTypeApiFunction,
  updateCourseTypeApiFunction,
  deleteCourseTypeApiFunction,
  getCoursesApiFunction,
  createCourseApiFunction,
  updateCourseApiFunction,
  updateCourseModulesApiFunction,
  deleteCourseApiFunction,
  getCollegesApiFunction,
  createCollegeApiFunction,
  updateCollegeApiFunction,
  deleteCollegeApiFunction,
  bulkImportSchemesApiFunction,
  bulkImportBranchesApiFunction,
  bulkImportCourseTypesApiFunction,
  bulkImportCoursesApiFunction,
  bulkImportCollegesApiFunction,
} from '../apifunction/apiFunction';

export const useAcademic = () => {
  const [schemes, setSchemes] = useState<Scheme[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [courseTypes, setCourseTypes] = useState<CourseType[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [colleges, setColleges] = useState<College[]>([]);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch all initial data
  const fetchAllData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [sch, dept, br, sem, ct, cr, col] = await Promise.all([
        getSchemesApiFunction(),
        getDepartmentsApiFunction(),
        getBranchesApiFunction(),
        getSemestersApiFunction(),
        getCourseTypesApiFunction(),
        getCoursesApiFunction(),
        getCollegesApiFunction(),
      ]);
      setSchemes(sch);
      setDepartments(dept);
      setBranches(br);
      setSemesters(sem);
      setCourseTypes(ct);
      setCourses(cr);
      setColleges(col);
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to load academic masters.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // Schemes Handlers
  const addScheme = async (payload: Partial<Scheme>) => {
    const created = await createSchemeApiFunction(payload);
    setSchemes((prev) => [created, ...prev]);
    toast.success(`Scheme "${created.name || created.schemeYear}" created successfully!`, 'Scheme Created');
    return created;
  };

  const editScheme = async (id: string, payload: Partial<Scheme>) => {
    const updated = await updateSchemeApiFunction(id, payload);
    setSchemes((prev) => prev.map((s) => (s.id === id ? updated : s)));
    toast.success(`Scheme updated successfully!`, 'Scheme Updated');
    return updated;
  };

  const deactivateScheme = async (id: string) => {
    const updated = await deleteSchemeApiFunction(id);
    setSchemes((prev) => prev.map((s) => (s.id === id ? updated : s)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`Scheme status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  // Branches Handlers
  const addBranch = async (payload: Partial<Branch>) => {
    const created = await createBranchApiFunction(payload);
    setBranches((prev) => [...prev, created]);
    toast.success(`Branch "${created.code} - ${created.name}" created successfully!`, 'Branch Added');
    return created;
  };

  const editBranch = async (id: string, payload: Partial<Branch>) => {
    const updated = await updateBranchApiFunction(id, payload);
    setBranches((prev) => prev.map((b) => (b.id === id ? updated : b)));
    toast.success(`Branch updated successfully!`, 'Branch Updated');
    return updated;
  };

  const deactivateBranch = async (id: string) => {
    const updated = await deleteBranchApiFunction(id);
    setBranches((prev) => prev.map((b) => (b.id === id ? updated : b)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`Branch status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  // Course Types Handlers
  const addCourseType = async (payload: Partial<CourseType>) => {
    const created = await createCourseTypeApiFunction(payload);
    setCourseTypes((prev) => [...prev, created]);
    toast.success(`Course Category "${created.name}" created successfully!`, 'Category Added');
    return created;
  };

  const editCourseType = async (id: string, payload: Partial<CourseType>) => {
    const updated = await updateCourseTypeApiFunction(id, payload);
    setCourseTypes((prev) => prev.map((ct) => (ct.id === id ? updated : ct)));
    toast.success(`Course Category updated successfully!`, 'Category Updated');
    return updated;
  };

  const deactivateCourseType = async (id: string) => {
    const updated = await deleteCourseTypeApiFunction(id);
    setCourseTypes((prev) => prev.map((ct) => (ct.id === id ? updated : ct)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`Category status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  // Courses Handlers
  const filterCourses = async (filters?: { schemeId?: string; branchId?: string; semesterId?: string; status?: string }) => {
    setIsLoading(true);
    try {
      const data = await getCoursesApiFunction(filters);
      setCourses(data);
    } catch (err: any) {
      setError(err.message || 'Failed to filter subjects');
    } finally {
      setIsLoading(false);
    }
  };

  const addCourse = async (payload: Partial<Course>) => {
    const created = await createCourseApiFunction(payload);
    setCourses((prev) => [created, ...prev]);
    toast.success(`Subject "${created.subjectCode} - ${created.title}" added successfully!`, 'Subject Added');
    return created;
  };

  const editCourse = async (id: string, payload: Partial<Course>) => {
    const updated = await updateCourseApiFunction(id, payload);
    setCourses((prev) => prev.map((c) => (c.id === id ? updated : c)));
    toast.success(`Subject updated successfully!`, 'Subject Updated');
    return updated;
  };

  const updateModules = async (courseId: string, modules: any[]) => {
    const updated = await updateCourseModulesApiFunction(courseId, modules);
    setCourses((prev) => prev.map((c) => (c.id === courseId ? updated : c)));
    toast.success(`Modules & units syllabus updated for course!`, 'Syllabus Updated');
    return updated;
  };

  const deactivateCourse = async (id: string) => {
    const updated = await deleteCourseApiFunction(id);
    setCourses((prev) => prev.map((c) => (c.id === id ? updated : c)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`Subject status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  // Colleges Handlers
  const addCollege = async (payload: Partial<College>) => {
    const created = await createCollegeApiFunction(payload);
    setColleges((prev) => [created, ...prev]);
    toast.success(`College "${created.code} - ${created.name}" registered successfully!`, 'College Registered');
    return created;
  };

  const editCollege = async (id: string, payload: Partial<College>) => {
    const updated = await updateCollegeApiFunction(id, payload);
    setColleges((prev) => prev.map((col) => (col.id === id ? updated : col)));
    toast.success(`College updated successfully!`, 'College Updated');
    return updated;
  };

  const deactivateCollege = async (id: string) => {
    const updated = await deleteCollegeApiFunction(id);
    setColleges((prev) => prev.map((col) => (col.id === id ? updated : col)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`College status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  // Bulk Handlers
  const bulkImportSchemes = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportSchemesApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} schemes!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import schemes bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  const bulkImportBranches = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportBranchesApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} branches!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import branches bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  const bulkImportCourseTypes = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportCourseTypesApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} course categories!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import course categories bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  const bulkImportCourses = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportCoursesApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} subjects!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import subjects bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  const bulkImportColleges = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportCollegesApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} colleges!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import colleges bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  // Departments Handlers
  const addDepartment = async (payload: Partial<Department>) => {
    const created = await createDepartmentApiFunction(payload);
    setDepartments((prev) => [created, ...prev]);
    toast.success(`Department "${created.code} - ${created.name}" created successfully!`, 'Department Added');
    return created;
  };

  const editDepartment = async (id: string, payload: Partial<Department>) => {
    const updated = await updateDepartmentApiFunction(id, payload);
    setDepartments((prev) => prev.map((d) => (d.id === id ? updated : d)));
    toast.success(`Department updated successfully!`, 'Department Updated');
    return updated;
  };

  const deactivateDepartment = async (id: string) => {
    const updated = await deleteDepartmentApiFunction(id);
    setDepartments((prev) => prev.map((d) => (d.id === id ? updated : d)));
    const statusText = updated.status === 'INACTIVE' ? 'deactivated' : 'activated';
    toast.info(`Department status changed to ${statusText}.`, 'Status Change');
    return updated;
  };

  const bulkImportDepartments = async (dtos: any[]) => {
    setIsLoading(true);
    try {
      const res = await bulkImportDepartmentsApiFunction(dtos);
      await fetchAllData();
      toast.success(`Successfully imported ${res.importedCount || dtos.length} departments!`, 'Bulk Import Complete');
      return res;
    } catch (err: any) {
      toast.error('Failed to import departments bulk data');
    } finally {
      setIsLoading(false);
    }
  };

  return {
    schemes,
    departments,
    branches,
    semesters,
    courseTypes,
    courses,
    colleges,
    isLoading,
    error,
    refreshData: fetchAllData,
    // Schemes
    addScheme,
    editScheme,
    deactivateScheme,
    bulkImportSchemes,
    // Departments
    addDepartment,
    editDepartment,
    deactivateDepartment,
    bulkImportDepartments,
    // Branches
    addBranch,
    editBranch,
    deactivateBranch,
    bulkImportBranches,
    // Course Types
    addCourseType,
    editCourseType,
    deactivateCourseType,
    bulkImportCourseTypes,
    // Courses
    filterCourses,
    addCourse,
    editCourse,
    updateModules,
    deactivateCourse,
    bulkImportCourses,
    // Colleges
    addCollege,
    editCollege,
    deactivateCollege,
    bulkImportColleges,
  };
};
