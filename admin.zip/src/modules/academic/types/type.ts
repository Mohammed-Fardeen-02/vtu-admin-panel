export type StatusType = 'ACTIVE' | 'INACTIVE';

export interface Scheme {
  id: string;
  schemeYear: string;
  name: string;
  description?: string;
  totalCredits: number;
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
  _count?: { courses: number };
}

export interface Department {
  id: string;
  code: string;
  name: string;
  description?: string;
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
  _count?: { branches: number };
}

export interface Branch {
  id: string;
  code: string;
  name: string;
  department?: string;
  departmentId?: string;
  deptRef?: Department;
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
  _count?: { courses: number };
}

export interface Semester {
  id: string;
  number: number;
  label: string;
  status: StatusType;
  createdAt: string;
  updatedAt: string;
}

export interface CourseType {
  id: string;
  code: string;
  name: string;
  description?: string;
  defaultCredits: number;
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
  _count?: { courses: number };
}

export interface UnitItem {
  id: string;
  unitNumber: string; // e.g. "1.1", "1.2", "Unit 1"
  title: string;
  topics: string;
  description?: string;
  notesCount?: number;
}

export interface ModuleItem {
  id: string;
  moduleNumber: number; // 1, 2, 3, etc.
  title: string;
  description?: string;
  units: UnitItem[];
  notesCount?: number;
}

export interface SyllabusUnit {
  unitNumber: number;
  title: string;
  topics: string;
}

export interface Course {
  id: string;
  subjectCode: string;
  title: string;
  schemeId: string;
  branchId: string;
  semesterId: string;
  courseTypeId: string;
  credits: number;
  seeMarks: number;
  cieMarks: number;
  syllabusUnits?: any;
  syllabusModules?: ModuleItem[];
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
  scheme?: Scheme;
  branch?: Branch;
  semester?: Semester;
  courseType?: CourseType;
}

export interface College {
  id: string;
  code: string;
  name: string;
  region: string;
  type: string;
  address?: string;
  contactEmail?: string;
  contactPhone?: string;
  websiteUrl?: string;
  status: StatusType;
  createdBy?: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
}
