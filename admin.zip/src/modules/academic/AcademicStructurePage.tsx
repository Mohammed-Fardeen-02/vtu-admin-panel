import React, { useState } from 'react';
import { Layers, Building2, Building, Tag, BookOpen, GraduationCap, RefreshCw, AlertCircle, FolderTree } from 'lucide-react';
import { PageHeader } from '../../shared/components/ui/PageHeader';
import { useAcademic } from './hooks/useAcademic';
import { SchemesTab } from './components/SchemesTab';
import { DepartmentsTab } from './components/DepartmentsTab';
import { BranchesTab } from './components/BranchesTab';
import { CourseTypesTab } from './components/CourseTypesTab';
import { CoursesTab } from './components/CoursesTab';
import { ModulesTab } from './components/ModulesTab';
import { CollegesTab } from './components/CollegesTab';

export type AcademicSubModuleTab = 'SCHEMES' | 'DEPARTMENTS' | 'BRANCHES' | 'CATEGORIES' | 'COURSES' | 'MODULES' | 'COLLEGES';

export const AcademicStructurePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AcademicSubModuleTab>('SCHEMES');
  const {
    schemes,
    departments,
    branches,
    semesters,
    courseTypes,
    courses,
    colleges,
    isLoading,
    error,
    refreshData,
    addScheme,
    editScheme,
    deactivateScheme,
    bulkImportSchemes,
    addDepartment,
    editDepartment,
    deactivateDepartment,
    bulkImportDepartments,
    addBranch,
    editBranch,
    deactivateBranch,
    bulkImportBranches,
    addCourseType,
    editCourseType,
    deactivateCourseType,
    bulkImportCourseTypes,
    filterCourses,
    addCourse,
    editCourse,
    updateModules,
    deactivateCourse,
    bulkImportCourses,
    addCollege,
    editCollege,
    deactivateCollege,
    bulkImportColleges,
  } = useAcademic();

  return (
    <div className="space-y-6 pb-12">
      {/* Page Title Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <PageHeader
          title="VTU Academic Hierarchy & College Masters"
          description="Single Source of Truth for Schemes, Departments, Engineering Branches, Course Categories, Subjects, Modules & Units, and College Registrations."
        />

        <button
          onClick={refreshData}
          disabled={isLoading}
          className="flex items-center gap-2 rounded-xl border border-border bg-card px-3.5 py-2 text-xs font-bold text-foreground hover:bg-accent transition-all shadow-sm"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin text-primary' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-600 text-xs font-semibold">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Sub-Modules Tab Navigation */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl border border-border bg-card shadow-sm">
        <button
          onClick={() => setActiveTab('SCHEMES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'SCHEMES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <GraduationCap className="h-4 w-4" />
          <span>Schemes Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{schemes.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('DEPARTMENTS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'DEPARTMENTS'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <Building className="h-4 w-4" />
          <span>Departments Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{departments.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('BRANCHES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'BRANCHES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <Building2 className="h-4 w-4" />
          <span>Branches Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{branches.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('CATEGORIES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'CATEGORIES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <Tag className="h-4 w-4" />
          <span>Categories Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{courseTypes.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('COURSES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'COURSES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <BookOpen className="h-4 w-4" />
          <span>Subjects Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{courses.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('MODULES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'MODULES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <FolderTree className="h-4 w-4" />
          <span>Modules & Units Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{courses.length}</span>
        </button>

        <button
          onClick={() => setActiveTab('COLLEGES')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-2 ${
            activeTab === 'COLLEGES'
              ? 'bg-primary text-white shadow-md'
              : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
          }`}
        >
          <Layers className="h-4 w-4" />
          <span>Colleges Master</span>
          <span className="ml-1 text-[10px] px-1.5 py-0.5 rounded-full bg-white/20">{colleges.length}</span>
        </button>
      </div>

      {/* Tab View Container */}
      <div className="mt-4">
        {activeTab === 'SCHEMES' && (
          <SchemesTab
            schemes={schemes}
            onAddScheme={addScheme}
            onEditScheme={editScheme}
            onDeactivateScheme={deactivateScheme}
            onBulkImportScheme={bulkImportSchemes}
          />
        )}

        {activeTab === 'DEPARTMENTS' && (
          <DepartmentsTab
            departments={departments}
            onAddDepartment={addDepartment}
            onEditDepartment={editDepartment}
            onDeactivateDepartment={deactivateDepartment}
            onBulkImportDepartment={bulkImportDepartments}
          />
        )}

        {activeTab === 'BRANCHES' && (
          <BranchesTab
            branches={branches}
            departments={departments}
            onAddBranch={addBranch}
            onEditBranch={editBranch}
            onDeactivateBranch={deactivateBranch}
            onBulkImportBranch={bulkImportBranches}
          />
        )}

        {activeTab === 'CATEGORIES' && (
          <CourseTypesTab
            courseTypes={courseTypes}
            onAddCourseType={addCourseType}
            onEditCourseType={editCourseType}
            onDeactivateCourseType={deactivateCourseType}
            onBulkImportCourseType={bulkImportCourseTypes}
          />
        )}

        {activeTab === 'COURSES' && (
          <CoursesTab
            courses={courses}
            schemes={schemes}
            branches={branches}
            semesters={semesters}
            courseTypes={courseTypes}
            onFilterCourses={filterCourses}
            onAddCourse={addCourse}
            onEditCourse={editCourse}
            onDeactivateCourse={deactivateCourse}
            onBulkImportCourse={bulkImportCourses}
          />
        )}

        {activeTab === 'MODULES' && (
          <ModulesTab
            courses={courses}
            schemes={schemes}
            branches={branches}
            semesters={semesters}
            onUpdateModules={updateModules}
          />
        )}

        {activeTab === 'COLLEGES' && (
          <CollegesTab
            colleges={colleges}
            onAddCollege={addCollege}
            onEditCollege={editCollege}
            onDeactivateCollege={deactivateCollege}
            onBulkImportCollege={bulkImportColleges}
          />
        )}
      </div>
    </div>
  );
};
