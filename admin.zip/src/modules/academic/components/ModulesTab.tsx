import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  FolderPlus,
  FilePlus,
  ChevronDown,
  ChevronRight,
  Plus,
  Search,
  Edit2,
  Trash2,
  Upload,
  Download,
  FileText,
  Layers,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { Course, Scheme, Branch, Semester, ModuleItem, UnitItem } from '../types/type';
import { Button, Input, Select, Modal, Card, CardContent, Badge } from '../../../shared/components/ui';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { useNotesStore } from '../../../store/useNotesStore';
import { NoteFormModal } from '../../notes/components/NoteFormModal';

interface ModulesTabProps {
  courses: Course[];
  schemes: Scheme[];
  branches: Branch[];
  semesters: Semester[];
  onUpdateModules: (courseId: string, modules: ModuleItem[]) => Promise<any>;
}

export const ModulesTab: React.FC<ModulesTabProps> = ({
  courses,
  schemes = [],
  branches = [],
  semesters = [],
  onUpdateModules,
}) => {
  const { notes, addNote } = useNotesStore();

  // Selection Filters
  const [selectedSchemeId, setSelectedSchemeId] = useState<string>('');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('');
  const [selectedSemId, setSelectedSemId] = useState<string>('');
  const [selectedCourseId, setSelectedCourseId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Accordion Expanded State (module IDs)
  const [expandedModuleIds, setExpandedModuleIds] = useState<Set<string>>(new Set());

  // Modal States
  const [isModuleModalOpen, setIsModuleModalOpen] = useState(false);
  const [editingModule, setEditingModule] = useState<ModuleItem | null>(null);
  const [moduleTitle, setModuleTitle] = useState('');
  const [moduleDescription, setModuleDescription] = useState('');

  const [isUnitModalOpen, setIsUnitModalOpen] = useState(false);
  const [targetModuleForUnit, setTargetModuleForUnit] = useState<ModuleItem | null>(null);
  const [editingUnit, setEditingUnit] = useState<UnitItem | null>(null);
  const [unitNumber, setUnitNumber] = useState('');
  const [unitTitle, setUnitTitle] = useState('');
  const [unitTopics, setUnitTopics] = useState('');

  // Notes Direct Upload Modal State
  const [isNoteUploadModalOpen, setIsNoteUploadModalOpen] = useState(false);
  const [targetUploadModule, setTargetUploadModule] = useState<ModuleItem | null>(null);
  const [targetUploadUnit, setTargetUploadUnit] = useState<UnitItem | null>(null);

  // Mapped Dropdown Options
  const schemeOptions = schemes.map((s) => ({ label: `${s.schemeYear} Scheme`, value: s.id }));
  const branchOptions = branches.map((b) => ({ label: `${b.code} - ${b.name}`, value: b.id }));
  const semesterOptions = semesters.map((sem) => ({ label: `Semester ${sem.number}`, value: sem.id }));

  // Course Filtered List
  const filteredCourses = useMemo(() => {
    return courses.filter((c) => {
      const matchScheme = selectedSchemeId ? c.schemeId === selectedSchemeId : true;
      const matchBranch = selectedBranchId ? c.branchId === selectedBranchId : true;
      const matchSem = selectedSemId ? c.semesterId === selectedSemId : true;
      return matchScheme && matchBranch && matchSem;
    });
  }, [courses, selectedSchemeId, selectedBranchId, selectedSemId]);

  const courseOptions = filteredCourses.map((c) => ({
    label: `${c.subjectCode} - ${c.title}`,
    value: c.id,
  }));

  // Selected Active Course
  const activeCourse = useMemo(() => {
    return courses.find((c) => c.id === selectedCourseId) || filteredCourses[0] || null;
  }, [courses, selectedCourseId, filteredCourses]);

  // Current Modules Array for Active Course
  const currentModules: ModuleItem[] = useMemo(() => {
    if (!activeCourse) return [];

    let rawModules: any = activeCourse.syllabusModules || activeCourse.syllabusUnits;

    if (Array.isArray(rawModules)) {
      return rawModules.map((m: any, idx: number): ModuleItem => {
        if (m.units && Array.isArray(m.units)) {
          return {
            id: m.id || `mod-${idx + 1}`,
            moduleNumber: m.moduleNumber || idx + 1,
            title: m.title || `Module ${idx + 1}`,
            description: m.description || '',
            units: m.units.map((u: any, uIdx: number): UnitItem => ({
              id: u.id || `unit-${idx + 1}-${uIdx + 1}`,
              unitNumber: u.unitNumber || `${idx + 1}.${uIdx + 1}`,
              title: u.title || `Unit ${uIdx + 1}`,
              topics: u.topics || '',
              description: u.description || '',
            })),
          };
        } else {
          // Flatten legacy single unit structure into module with 1 unit
          return {
            id: `mod-${idx + 1}`,
            moduleNumber: m.unitNumber || idx + 1,
            title: `Module ${m.unitNumber || idx + 1}: ${m.title || 'Overview'}`,
            description: '',
            units: [
              {
                id: `unit-${idx + 1}-1`,
                unitNumber: `${idx + 1}.1`,
                title: String(m.title || `Unit ${idx + 1}`),
                topics: m.topics || '',
                description: '',
              },
            ],
          };
        }
      });
    }

    return [];
  }, [activeCourse]);

  // Filtered Modules by Search Query
  const displayedModules = useMemo(() => {
    if (!searchQuery.trim()) return currentModules;
    const q = searchQuery.toLowerCase();
    return currentModules.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        (m.description || '').toLowerCase().includes(q) ||
        m.units.some((u) => u.title.toLowerCase().includes(q) || u.topics.toLowerCase().includes(q))
    );
  }, [currentModules, searchQuery]);

  // Toggle Module Accordion Expand
  const toggleExpandModule = (modId: string) => {
    setExpandedModuleIds((prev) => {
      const next = new Set(prev);
      if (next.has(modId)) next.delete(modId);
      else next.add(modId);
      return next;
    });
  };

  const expandAll = () => {
    setExpandedModuleIds(new Set(currentModules.map((m) => m.id)));
  };

  const collapseAll = () => {
    setExpandedModuleIds(new Set());
  };

  // Auto-Generate Standard 5-Module VTU Template
  const handleAutoGenerateTemplate = async () => {
    if (!activeCourse) return;

    const templateModules: ModuleItem[] = [1, 2, 3, 4, 5].map((num): ModuleItem => ({
      id: `mod-${Date.now()}-${num}`,
      moduleNumber: num,
      title: `Module ${num}: Standard VTU Unit Outline`,
      description: `Core theoretical & analytical topics for Module ${num} of ${activeCourse.subjectCode}`,
      units: [
        {
          id: `unit-${Date.now()}-${num}-1`,
          unitNumber: `${num}.1`,
          title: `Unit ${num}.1 Core Concepts & Fundamentals`,
          topics: `Key principles, theoretical framework, architecture & definitions for Module ${num}.`,
          description: '',
        },
        {
          id: `unit-${Date.now()}-${num}-2`,
          unitNumber: `${num}.2`,
          title: `Unit ${num}.2 Advanced Applications & Analytical Problems`,
          topics: `Analytical problem solving, practical case studies & exam problem patterns.`,
          description: '',
        },
      ],
    }));

    await onUpdateModules(activeCourse.id, templateModules);
    setExpandedModuleIds(new Set(templateModules.map((m) => m.id)));
  };

  // Module CRUD Handlers
  const openAddModuleModal = () => {
    setEditingModule(null);
    setModuleTitle('');
    setModuleDescription('');
    setIsModuleModalOpen(true);
  };

  const openEditModuleModal = (m: ModuleItem) => {
    setEditingModule(m);
    setModuleTitle(m.title);
    setModuleDescription(m.description || '');
    setIsModuleModalOpen(true);
  };

  const handleSaveModule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse) return;

    let updatedList: ModuleItem[];
    if (editingModule) {
      updatedList = currentModules.map((m) =>
        m.id === editingModule.id ? { ...m, title: moduleTitle, description: moduleDescription } : m
      );
    } else {
      const nextNum = currentModules.length + 1;
      const newModule: ModuleItem = {
        id: `mod-${Date.now()}`,
        moduleNumber: nextNum,
        title: moduleTitle || `Module ${nextNum}`,
        description: moduleDescription,
        units: [],
      };
      updatedList = [...currentModules, newModule];
    }

    await onUpdateModules(activeCourse.id, updatedList);
    setIsModuleModalOpen(false);
  };

  const handleDeleteModule = async (modId: string) => {
    if (!activeCourse) return;
    const updatedList = currentModules.filter((m) => m.id !== modId);
    await onUpdateModules(activeCourse.id, updatedList);
  };

  // Unit CRUD Handlers
  const openAddUnitModal = (mod: ModuleItem) => {
    setTargetModuleForUnit(mod);
    setEditingUnit(null);
    const nextUnitSubNum = mod.units.length + 1;
    setUnitNumber(`${mod.moduleNumber}.${nextUnitSubNum}`);
    setUnitTitle('');
    setUnitTopics('');
    setIsUnitModalOpen(true);
  };

  const openEditUnitModal = (mod: ModuleItem, u: UnitItem) => {
    setTargetModuleForUnit(mod);
    setEditingUnit(u);
    setUnitNumber(u.unitNumber);
    setUnitTitle(u.title);
    setUnitTopics(u.topics);
    setIsUnitModalOpen(true);
  };

  const handleSaveUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse || !targetModuleForUnit) return;

    const updatedList = currentModules.map((m) => {
      if (m.id !== targetModuleForUnit.id) return m;

      let nextUnits: UnitItem[];
      if (editingUnit) {
        nextUnits = m.units.map((u) =>
          u.id === editingUnit.id
            ? { ...u, unitNumber, title: unitTitle, topics: unitTopics }
            : u
        );
      } else {
        const newUnit: UnitItem = {
          id: `unit-${Date.now()}`,
          unitNumber: unitNumber || `${m.moduleNumber}.${m.units.length + 1}`,
          title: unitTitle,
          topics: unitTopics,
        };
        nextUnits = [...m.units, newUnit];
      }

      return { ...m, units: nextUnits };
    });

    await onUpdateModules(activeCourse.id, updatedList);
    setIsUnitModalOpen(false);
  };

  const handleDeleteUnit = async (modId: string, unitId: string) => {
    if (!activeCourse) return;
    const updatedList = currentModules.map((m) => {
      if (m.id !== modId) return m;
      return { ...m, units: m.units.filter((u) => u.id !== unitId) };
    });
    await onUpdateModules(activeCourse.id, updatedList);
  };

  // Trigger Notes Upload for specific Module or Unit
  const openDirectNoteUpload = (mod: ModuleItem, unit?: UnitItem) => {
    setTargetUploadModule(mod);
    setTargetUploadUnit(unit || null);
    setIsNoteUploadModalOpen(true);
  };

  // Helper count of uploaded notes per module/unit
  const getNotesCountForSubject = (subjectCode: string, modTitle?: string) => {
    if (!subjectCode) return 0;
    return notes.filter(
      (n) =>
        n.subjectCode?.toLowerCase() === subjectCode.toLowerCase() &&
        (modTitle ? (n.title || '').toLowerCase().includes(modTitle.toLowerCase()) : true)
    ).length;
  };

  const handleExportCSV = () => {
    if (!activeCourse) return;
    const rows: string[][] = [];
    currentModules.forEach((m) => {
      m.units.forEach((u) => {
        rows.push([activeCourse.subjectCode, activeCourse.title, `Module ${m.moduleNumber}`, m.title, u.unitNumber, u.title, u.topics]);
      });
    });
    downloadCSV(`${activeCourse.subjectCode}_modules_units_syllabus`, ['subjectCode', 'subjectTitle', 'moduleNumber', 'moduleTitle', 'unitNumber', 'unitTitle', 'topics'], rows);
  };

  return (
    <div className="space-y-6">
      {/* Subject & Scheme Selection Filter Toolbar */}
      <Card className="p-4 border-border bg-card/60 shadow-sm">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            {/* Scheme Dropdown */}
            <div className="w-40">
              <Select
                value={selectedSchemeId}
                onChange={(e) => setSelectedSchemeId(e.target.value)}
                placeholder="All Schemes"
                options={schemeOptions}
              />
            </div>

            {/* Branch Dropdown */}
            <div className="w-44">
              <Select
                value={selectedBranchId}
                onChange={(e) => setSelectedBranchId(e.target.value)}
                placeholder="All Branches"
                options={branchOptions}
              />
            </div>

            {/* Semester Dropdown */}
            <div className="w-36">
              <Select
                value={selectedSemId}
                onChange={(e) => setSelectedSemId(e.target.value)}
                placeholder="All Semesters"
                options={semesterOptions}
              />
            </div>

            {/* Course Selector Dropdown */}
            <div className="w-full sm:w-72">
              <Select
                value={activeCourse?.id || ''}
                onChange={(e) => setSelectedCourseId(e.target.value)}
                placeholder="-- Select Subject / Course --"
                options={courseOptions}
              />
            </div>
          </div>

          <div className="flex items-center gap-2 w-full lg:w-auto justify-end">
            <Button variant="outline" size="sm" onClick={handleExportCSV} disabled={!activeCourse} icon={<Download className="h-3.5 w-3.5 text-emerald-500" />}>
              Export CSV
            </Button>
          </div>
        </div>
      </Card>

      {/* Course Context Header */}
      {activeCourse ? (
        <div className="p-5 rounded-2xl border border-border bg-card shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-2xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center font-black text-sm shrink-0">
              {activeCourse.subjectCode}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-foreground">{activeCourse.title}</h3>
                <Badge variant="primary" className="text-[10px]">
                  {activeCourse.branch?.code || 'CSE'}
                </Badge>
                <Badge variant="neutral" className="text-[10px]">
                  Sem {activeCourse.semester?.number || 5}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5">
                {activeCourse.scheme?.schemeYear} Scheme • {currentModules.length} Modules Configured • Total {currentModules.reduce((acc, m) => acc + m.units.length, 0)} Units Defined
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" size="sm" onClick={expandAll} className="text-xs">
              Expand All
            </Button>
            <Button variant="outline" size="sm" onClick={collapseAll} className="text-xs">
              Collapse All
            </Button>
            <Button variant="primary" size="sm" onClick={openAddModuleModal} icon={<FolderPlus className="h-4 w-4" />}>
              + Add New Module
            </Button>
          </div>
        </div>
      ) : (
        <Card className="p-8 text-center text-muted-foreground">
          <BookOpen className="h-10 w-10 text-primary mx-auto mb-2 opacity-50" />
          <p className="font-bold">No Subject Selected</p>
          <p className="text-xs mt-1">Select a scheme, branch, or subject from the dropdown above.</p>
        </Card>
      )}

      {/* Module Tree / Accordion View */}
      {activeCourse && (
        <div className="space-y-4">
          {/* Module Search Filter */}
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search modules, unit titles, or syllabus topics..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
            />
          </div>

          {displayedModules.length === 0 ? (
            <Card className="p-10 text-center space-y-3">
              <Sparkles className="h-10 w-10 text-amber-500 mx-auto opacity-70" />
              <div>
                <h4 className="text-base font-bold text-foreground">No Modules Configured Yet</h4>
                <p className="text-xs text-muted-foreground max-w-md mx-auto mt-1">
                  This course does not have modules defined yet. You can auto-generate the standard VTU 5-module template or create modules manually.
                </p>
              </div>

              <div className="flex items-center justify-center gap-3 pt-2">
                <Button variant="primary" size="sm" onClick={handleAutoGenerateTemplate} icon={<Sparkles className="h-4 w-4" />}>
                  Auto-Generate 5 VTU Modules
                </Button>
                <Button variant="outline" size="sm" onClick={openAddModuleModal} icon={<Plus className="h-4 w-4" />}>
                  Add Custom Module
                </Button>
              </div>
            </Card>
          ) : (
            displayedModules.map((mod) => {
              const isExpanded = expandedModuleIds.has(mod.id);
              const moduleNotesCount = getNotesCountForSubject(activeCourse.subjectCode, mod.title);

              return (
                <div key={mod.id} className="rounded-2xl border border-border bg-card overflow-hidden shadow-sm transition-all">
                  {/* Module Header Bar */}
                  <div
                    onClick={() => toggleExpandModule(mod.id)}
                    className="p-4 flex items-center justify-between gap-4 cursor-pointer hover:bg-accent/40 transition-colors border-b border-border/40"
                  >
                    <div className="flex items-center gap-3">
                      <button className="text-muted-foreground hover:text-foreground">
                        {isExpanded ? <ChevronDown className="h-5 w-5 text-primary" /> : <ChevronRight className="h-5 w-5 text-muted-foreground" />}
                      </button>
                      <div className="h-9 px-3 rounded-xl bg-primary/10 border border-primary/20 text-primary font-black text-xs flex items-center justify-center">
                        Module {mod.moduleNumber}
                      </div>
                      <div>
                        <h4 className="text-sm font-extrabold text-foreground">{mod.title}</h4>
                        {mod.description && <p className="text-xs text-muted-foreground line-clamp-1">{mod.description}</p>}
                      </div>
                    </div>

                    <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <Badge variant="neutral" className="text-[10px]">
                        {mod.units.length} {mod.units.length === 1 ? 'Unit' : 'Units'}
                      </Badge>

                      {/* Direct Upload Notes Button on Module */}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDirectNoteUpload(mod)}
                        icon={<FilePlus className="h-3.5 w-3.5 text-primary" />}
                        className="text-xs"
                      >
                        Upload Notes {moduleNotesCount > 0 && `(${moduleNotesCount})`}
                      </Button>

                      {/* Add Unit */}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openAddUnitModal(mod)}
                        icon={<Plus className="h-3.5 w-3.5" />}
                        className="text-xs"
                      >
                        Add Unit
                      </Button>

                      {/* Edit Module */}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditModuleModal(mod)}
                        icon={<Edit2 className="h-3.5 w-3.5" />}
                      />

                      {/* Delete Module */}
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteModule(mod.id)}
                        icon={<Trash2 className="h-3.5 w-3.5" />}
                      />
                    </div>
                  </div>

                  {/* Module Units Body (Expanded) */}
                  {isExpanded && (
                    <div className="p-4 bg-muted/20 space-y-3">
                      {mod.units.length === 0 ? (
                        <div className="p-4 rounded-xl border border-dashed border-border text-center text-xs text-muted-foreground">
                          No units added to Module {mod.moduleNumber} yet.{' '}
                          <button onClick={() => openAddUnitModal(mod)} className="text-primary font-bold hover:underline ml-1">
                            + Add Unit
                          </button>
                        </div>
                      ) : (
                        mod.units.map((unit) => (
                          <div key={unit.id} className="p-4 rounded-xl border border-border bg-card flex flex-col md:flex-row md:items-start justify-between gap-3 shadow-xs hover:border-primary/40 transition-all">
                            <div className="space-y-1 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="font-extrabold text-xs px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                                  Unit {unit.unitNumber}
                                </span>
                                <h5 className="text-xs font-bold text-foreground">{unit.title}</h5>
                              </div>
                              <p className="text-xs text-muted-foreground leading-relaxed">{unit.topics}</p>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              {/* Direct Upload Notes Button on Unit */}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openDirectNoteUpload(mod, unit)}
                                icon={<Upload className="h-3 w-3 text-emerald-500" />}
                                className="text-[11px] py-1 h-7"
                              >
                                Add Note
                              </Button>

                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openEditUnitModal(mod, unit)}
                                icon={<Edit2 className="h-3 w-3" />}
                                className="h-7 w-7 p-0"
                              />

                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleDeleteUnit(mod.id, unit.id)}
                                icon={<Trash2 className="h-3 w-3" />}
                                className="h-7 w-7 p-0"
                              />
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Add / Edit Module Modal */}
      <Modal
        isOpen={isModuleModalOpen}
        onClose={() => setIsModuleModalOpen(false)}
        title={editingModule ? `Edit Module ${editingModule.moduleNumber}` : 'Add New Module'}
        subtitle={`Configure module for ${activeCourse?.subjectCode || 'selected course'}`}
        maxWidth="md"
      >
        <form onSubmit={handleSaveModule} className="space-y-4 pt-2">
          <Input
            label="Module Title *"
            required
            value={moduleTitle}
            onChange={(e) => setModuleTitle(e.target.value)}
            placeholder="e.g. Module 1: Relational Data Model & ER Diagrams"
          />

          <div className="space-y-1">
            <label className="text-xs font-bold text-foreground">Module Overview / Description</label>
            <textarea
              rows={3}
              value={moduleDescription}
              onChange={(e) => setModuleDescription(e.target.value)}
              placeholder="Brief summary of key learning objectives & scope for this module..."
              className="w-full p-3 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none resize-none"
            />
          </div>

          <div className="pt-3 border-t border-border flex items-center justify-end gap-2">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsModuleModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingModule ? 'Save Changes' : 'Create Module'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Add / Edit Unit Modal */}
      <Modal
        isOpen={isUnitModalOpen}
        onClose={() => setIsUnitModalOpen(false)}
        title={editingUnit ? `Edit Unit ${editingUnit.unitNumber}` : `Add Unit to Module ${targetModuleForUnit?.moduleNumber}`}
        subtitle="Specify unit/sub-topic number, title, and detailed syllabus content"
        maxWidth="lg"
      >
        <form onSubmit={handleSaveUnit} className="space-y-4 pt-2">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Unit Number / Code *"
              required
              value={unitNumber}
              onChange={(e) => setUnitNumber(e.target.value)}
              placeholder="e.g. 1.1 or Unit A"
            />

            <div className="md:col-span-2">
              <Input
                label="Unit Title *"
                required
                value={unitTitle}
                onChange={(e) => setUnitTitle(e.target.value)}
                placeholder="e.g. Entity-Relationship (ER) Modeling"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-foreground">Syllabus Topics & Key Concepts *</label>
            <textarea
              rows={4}
              required
              value={unitTopics}
              onChange={(e) => setUnitTopics(e.target.value)}
              placeholder="Enter detailed topics covered in this unit (e.g., Entities, Attributes, Entity Sets, Primary & Foreign Keys, Relational Constraints...)"
              className="w-full p-3 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none resize-none"
            />
          </div>

          <div className="pt-3 border-t border-border flex items-center justify-end gap-2">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsUnitModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingUnit ? 'Save Changes' : 'Add Unit'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Direct Notes Upload Modal */}
      {isNoteUploadModalOpen && targetUploadModule && (
        <NoteFormModal
          isOpen={isNoteUploadModalOpen}
          onClose={() => {
            setIsNoteUploadModalOpen(false);
            setTargetUploadModule(null);
            setTargetUploadUnit(null);
          }}
          initialNote={{
            id: '',
            title: targetUploadUnit
              ? `${activeCourse?.subjectCode} Notes - Unit ${targetUploadUnit.unitNumber}`
              : `${activeCourse?.subjectCode} Notes - Module ${targetUploadModule.moduleNumber}`,
            description: targetUploadUnit
              ? `Study notes for Unit ${targetUploadUnit.unitNumber}: ${targetUploadUnit.title}`
              : `Comprehensive notes for ${targetUploadModule.title}`,
            subjectCode: activeCourse?.subjectCode || '',
            subjectName: activeCourse?.title || '',
            subjectId: activeCourse?.id || '',
            branchCode: activeCourse?.branch?.code || 'CSE',
            schemeYear: activeCourse?.scheme?.schemeYear || '2022',
            semester: activeCourse?.semester?.number || 5,
            format: 'PDF',
            status: 'PUBLISHED',
            fileUrl: 'https://res.cloudinary.com/vtu/sample_notes.pdf',
            secureUrl: 'https://res.cloudinary.com/vtu/sample_notes.pdf',
            fileSize: '2.4 MB',
            fileSizeBytes: 2500000,
            pageCount: 18,
            authorName: 'VTU Faculty / Admin',
            authorRole: 'ADMIN',
            validation: {
              fileTypeValid: true,
              fileSizeValid: true,
              virusScanStatus: 'CLEAN',
              contentQualityRating: 5,
              ocrScanStatus: 'PASSED',
              duplicateScore: 0,
            },
            reportsCount: 0,
            downloads: 0,
            bookmarksCount: 0,
            viewsCount: 0,
            averageRating: 5.0,
            orderPriority: 1,
            uploadDate: new Date().toISOString().split('T')[0],
            lastModified: new Date().toISOString().split('T')[0],
          }}
          onSave={(noteData) => {
            addNote(noteData);
            setIsNoteUploadModalOpen(false);
            setTargetUploadModule(null);
            setTargetUploadUnit(null);
            return { success: true };
          }}
        />
      )}
    </div>
  );
};
