import React, { useState, useEffect } from 'react';
import { X, Layers, AlertCircle } from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { AcademicModule } from '../../../shared/types/academic.types';

export interface ModuleFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (mod: Omit<AcademicModule, 'id'> | AcademicModule) => { success: boolean; error?: string };
  subjectId: string;
  initialModule?: AcademicModule | null;
  existingModulesCount: number;
}

export const ModuleFormModal: React.FC<ModuleFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  subjectId,
  initialModule,
  existingModulesCount,
}) => {
  const [moduleNumber, setModuleNumber] = useState(1);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [teachingHours, setTeachingHours] = useState(8);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialModule) {
      setModuleNumber(initialModule.moduleNumber);
      setTitle(initialModule.title);
      setDescription(initialModule.description || '');
      setTeachingHours(initialModule.teachingHours || 8);
    } else {
      setModuleNumber(existingModulesCount + 1);
      setTitle(`Module ${existingModulesCount + 1}: `);
      setDescription('');
      setTeachingHours(8);
    }
    setErrorMsg('');
  }, [initialModule, existingModulesCount, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Module title is required.');
      return;
    }

    const payload = {
      ...(initialModule ? { id: initialModule.id } : {}),
      subjectId,
      moduleNumber: Number(moduleNumber),
      title: title.trim(),
      description: description.trim(),
      teachingHours: Number(teachingHours),
      status: initialModule ? initialModule.status : ('ACTIVE' as const),
      order: Number(moduleNumber),
    };

    const res = onSave(payload as any);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to save module.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-border/60 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <Layers className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-black text-foreground">
              {initialModule ? 'Edit Module' : 'Add New Module'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-accent"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">Module No. *</label>
              <input
                type="number"
                min="1"
                max="10"
                value={moduleNumber}
                onChange={(e) => setModuleNumber(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Teaching Hours *</label>
              <input
                type="number"
                min="1"
                max="30"
                value={teachingHours}
                onChange={(e) => setTeachingHours(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Module Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Module 1: Introduction to Database Systems"
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
              required
            />
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Module Topics Summary</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              placeholder="Summary of topics covered in this module..."
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
            <Button variant="outline" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {initialModule ? 'Update Module' : 'Save Module'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
