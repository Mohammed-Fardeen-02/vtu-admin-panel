import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical, Eye, Edit2, Power, Trash2 } from 'lucide-react';
import { StatusType } from '../types/type';

interface ActionDropdownProps {
  status?: StatusType;
  onView?: () => void;
  onEdit?: () => void;
  onToggleStatus?: () => void;
  onDelete?: () => void;
}

export const ActionDropdown: React.FC<ActionDropdownProps> = ({
  status = 'ACTIVE',
  onView,
  onEdit,
  onToggleStatus,
  onDelete,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="rounded-lg p-1.5 text-muted-foreground hover:bg-accent hover:text-foreground transition-colors border border-border/50"
        title="Actions Menu"
      >
        <MoreVertical className="h-4 w-4" />
      </button>

      {isOpen && (
        <div className="absolute right-0 z-50 mt-1 w-44 origin-top-right rounded-xl border border-border bg-card shadow-xl p-1 animate-in fade-in duration-150">
          {onView && (
            <button
              onClick={() => {
                setIsOpen(false);
                onView();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-foreground hover:bg-primary/10 hover:text-primary rounded-lg transition-colors"
            >
              <Eye className="h-3.5 w-3.5 text-blue-500" />
              <span>View Overview</span>
            </button>
          )}

          {onEdit && (
            <button
              onClick={() => {
                setIsOpen(false);
                onEdit();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-foreground hover:bg-amber-500/10 hover:text-amber-600 rounded-lg transition-colors"
            >
              <Edit2 className="h-3.5 w-3.5 text-amber-500" />
              <span>Edit Record</span>
            </button>
          )}

          {onToggleStatus && (
            <button
              onClick={() => {
                setIsOpen(false);
                onToggleStatus();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-foreground hover:bg-emerald-500/10 hover:text-emerald-600 rounded-lg transition-colors"
            >
              <Power className={`h-3.5 w-3.5 ${status === 'ACTIVE' ? 'text-amber-500' : 'text-emerald-500'}`} />
              <span>{status === 'ACTIVE' ? 'Set Inactive' : 'Set Active'}</span>
            </button>
          )}

          {onDelete && (
            <>
              <div className="my-1 border-t border-border" />
              <button
                onClick={() => {
                  setIsOpen(false);
                  onDelete();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Deactivate / Delete</span>
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};
