import React, { useState } from 'react';
import { Plus, Search, CheckCircle2, XCircle, UserCheck, Calendar, Download, Upload, Building2 } from 'lucide-react';
import { Branch, Department, StatusType } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface BranchesTabProps {
  branches: Branch[];
  departments?: Department[];
  onAddBranch: (payload: Partial<Branch>) => Promise<any>;
  onEditBranch: (id: string, payload: Partial<Branch>) => Promise<any>;
  onDeactivateBranch: (id: string) => Promise<any>;
  onBulkImportBranch?: (dtos: any[]) => Promise<any>;
}

export const BranchesTab: React.FC<BranchesTabProps> = ({
  branches,
  departments = [],
  onAddBranch,
  onEditBranch,
  onDeactivateBranch,
  onBulkImportBranch,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBranch, setSelectedBranch] = useState<Branch | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [departmentName, setDepartmentName] = useState('');
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirm Modal
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const branchList = Array.isArray(branches) ? branches : [];
  const deptList = Array.isArray(departments) ? departments : [];

  const filteredBranches = branchList.filter(
    (b) =>
      b.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (b.department && b.department.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Map departments into Select options
  const departmentSelectOptions = deptList.map((d) => ({
    label: `${d.code} - ${d.name}`,
    value: d.id,
  }));

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_engineering_branches',
      ['code', 'name', 'department', 'status'],
      filteredBranches.map((b) => [b.code, b.name, b.deptRef?.name || b.department || '', b.status])
    );
  };

  const openCreateModal = () => {
    setEditingId(null);
    setCode('');
    setName('');
    const defaultDept = deptList.length > 0 ? deptList[0] : null;
    setDepartmentId(defaultDept ? defaultDept.id : '');
    setDepartmentName(defaultDept ? defaultDept.name : '');
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (b: Branch) => {
    setEditingId(b.id);
    setCode(b.code);
    setName(b.name);
    // Find matching department in master
    const matchedDept = deptList.find((d) => d.id === b.departmentId || d.name === b.department);
    setDepartmentId(matchedDept ? matchedDept.id : b.departmentId || '');
    setDepartmentName(matchedDept ? matchedDept.name : b.department || '');
    setStatus(b.status);
    setIsFormModalOpen(true);
  };

  const handleDepartmentChange = (selectedId: string) => {
    setDepartmentId(selectedId);
    const matched = deptList.find((d) => d.id === selectedId);
    if (matched) {
      setDepartmentName(matched.name);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      code,
      name,
      department: departmentName,
      departmentId: departmentId || undefined,
      status,
    };

    if (editingId) {
      await onEditBranch(editingId, payload);
    } else {
      await onAddBranch(payload);
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (b: Branch) => {
    const nextStatus: StatusType = b.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditBranch(b.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (b: Branch) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate Branch "${b.code}"?`,
      message: `Are you sure you want to deactivate ${b.code} (${b.name})? Existing mapping remains safe.`,
      actionId: b.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search & Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="w-full sm:w-80">
          <Input
            placeholder="Search Branch Code, Name, or Dept..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="h-4 w-4" />}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Add Engineering Branch</span>
          </Button>
        </div>
      </div>

      {/* Branches Table Component */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Branch Code</TableHead>
            <TableHead>Branch Name</TableHead>
            <TableHead>Department (Master)</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Audit Meta</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredBranches.map((branch) => {
            const displayDeptName = branch.deptRef?.name || branch.department || 'General Department';
            return (
              <TableRow key={branch.id}>
                <TableCell className="font-bold text-foreground">
                  <div className="flex items-center gap-2">
                    <div className="h-7 px-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-black text-xs">
                      {branch.code}
                    </div>
                  </div>
                </TableCell>
                <TableCell className="font-semibold text-foreground">{branch.name}</TableCell>
                <TableCell className="text-muted-foreground font-medium">
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-primary" />
                    <span>{displayDeptName}</span>
                  </div>
                </TableCell>
                <TableCell>
                  {branch.status === 'ACTIVE' ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                      <CheckCircle2 className="h-3 w-3" /> ACTIVE
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-[10px] font-black text-red-600 dark:text-red-400 uppercase tracking-wider">
                      <XCircle className="h-3 w-3" /> INACTIVE
                    </span>
                  )}
                </TableCell>
                <TableCell className="text-[11px] text-muted-foreground">
                  <div className="flex flex-col">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> {new Date(branch.createdAt).toLocaleDateString()}
                    </span>
                    <span className="flex items-center gap-1 text-[10px] mt-0.5 text-foreground/70 font-semibold">
                      <UserCheck className="h-3 w-3 text-primary" /> {branch.createdBy || 'Admin'}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <ActionDropdown
                    status={branch.status}
                    onView={() => {
                      setSelectedBranch(branch);
                      setIsViewModalOpen(true);
                    }}
                    onEdit={() => openEditModal(branch)}
                    onToggleStatus={() => handleToggleStatus(branch)}
                    onDelete={() => triggerDeactivateConfirm(branch)}
                  />
                </TableCell>
              </TableRow>
            );
          })}

          {filteredBranches.length === 0 && (
            <TableRow>
              <TableCell colSpan={6} className="py-8 text-center text-muted-foreground">
                No engineering branches found matching search. Click "+ Add Engineering Branch" to create one.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit Branch */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit Engineering Branch' : 'Add Engineering Branch'}
        subtitle="Manage academic engineering branch details and department master links"
        maxWidth="lg"
      >
        <form id="branch-form" onSubmit={handleFormSubmit} className="space-y-4 pt-2">
          <Input
            label="Branch Code / Abbreviation *"
            required
            disabled={!!editingId}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="e.g. CSE, ECE, AIML, ME"
          />

          <Input
            label="Full Branch Name *"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Computer Science & Engineering"
          />

          {/* Department Selection from Master DB */}
          <div>
            <Select
              label="Department (Fetched from Department Master) *"
              value={departmentId}
              onChange={(e) => handleDepartmentChange(e.target.value)}
              placeholder={deptList.length === 0 ? 'No Departments Found (Add in Department Master)' : '-- Select Department --'}
              options={departmentSelectOptions}
              helperText={
                deptList.length === 0
                  ? 'Please navigate to the "Departments Master" tab to populate department master data.'
                  : 'Select an existing Department created in the Department Master.'
              }
            />
          </div>

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled for Students & Academics)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Create Branch'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Centered Overview Modal */}
      {selectedBranch && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Branch Overview: ${selectedBranch.code}`}
          subtitle={selectedBranch.name}
          maxWidth="md"
        >
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 border-b border-border pb-4">
              <div className="h-12 w-12 rounded-2xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center font-black text-lg">
                {selectedBranch.code}
              </div>
              <div>
                <h4 className="text-base font-extrabold text-foreground">{selectedBranch.name}</h4>
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                  <Building2 className="w-3.5 h-3.5 text-primary" />
                  {selectedBranch.deptRef?.name || selectedBranch.department || 'General Department'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-muted/30 p-4 rounded-xl border border-border/60">
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Branch Code</span>
                <span className="font-black text-foreground text-sm">{selectedBranch.code}</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Status</span>
                <span className={`font-extrabold text-xs ${selectedBranch.status === 'ACTIVE' ? 'text-emerald-500' : 'text-red-500'}`}>
                  {selectedBranch.status}
                </span>
              </div>
            </div>

            <div className="pt-2 border-t border-border flex flex-col gap-1 text-xs text-muted-foreground">
              <span>Created At: {new Date(selectedBranch.createdAt).toLocaleString()}</span>
              <span>Updated At: {new Date(selectedBranch.updatedAt).toLocaleString()}</span>
              <span>Created By: {selectedBranch.createdBy || 'Admin'}</span>
            </div>
          </div>
        </Modal>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import Engineering Branches"
        entityName="Branches"
        sampleHeaders={['code', 'name', 'department', 'status']}
        sampleRows={[
          ['AI', 'Artificial Intelligence & Data Science', 'Computer Science & Engineering', 'ACTIVE'],
          ['BT', 'Biotechnology Engineering', 'Chemical & Bio Engineering', 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportBranch) {
            await onBulkImportBranch(
              parsedRecords.map((r) => ({
                code: r.code,
                name: r.name,
                department: r.department || 'Engineering',
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateBranch(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
