import React, { useState } from 'react';
import { Upload, Download, FileSpreadsheet, AlertCircle, CheckCircle2, X } from 'lucide-react';
import { downloadCSV, parseCSV } from '../../../shared/utils/csvExport';

interface BulkImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  entityName: string;
  sampleHeaders: string[];
  sampleRows: (string | number)[][];
  onConfirmImport: (parsedRecords: any[]) => Promise<void>;
}

export const BulkImportModal: React.FC<BulkImportModalProps> = ({
  isOpen,
  onClose,
  title,
  entityName,
  sampleHeaders,
  sampleRows,
  onConfirmImport,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<Record<string, string>[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownloadTemplate = () => {
    downloadCSV(`${entityName.toLowerCase()}_import_template`, sampleHeaders, sampleRows);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    if (!uploadedFile.name.endsWith('.csv')) {
      setError('Please upload a valid .csv file.');
      return;
    }

    setFile(uploadedFile);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      const records = parseCSV(text);
      if (records.length === 0) {
        setError('The uploaded CSV file is empty or formatted incorrectly.');
        setParsedData([]);
      } else {
        setParsedData(records);
      }
    };
    reader.readAsText(uploadedFile);
  };

  const handleImport = async () => {
    if (parsedData.length === 0) return;
    setIsSubmitting(true);
    setError(null);
    try {
      await onConfirmImport(parsedData);
      setFile(null);
      setParsedData([]);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Import failed. Check CSV column names.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/20">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">{title}</h3>
              <p className="text-xs text-slate-400">Bulk upload records via CSV format</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-5 space-y-5 overflow-y-auto">
          {/* Step 1: Download Template */}
          <div className="p-4 bg-slate-800/40 border border-slate-800 rounded-xl flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-white">1. Download CSV Sample Template</h4>
              <p className="text-xs text-slate-400 mt-0.5">Use the exact headers provided in our standard CSV template.</p>
            </div>
            <button
              onClick={handleDownloadTemplate}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-blue-400 bg-blue-500/10 border border-blue-500/20 rounded-xl hover:bg-blue-500/20 transition-colors shrink-0"
            >
              <Download className="w-4 h-4" /> Download Template
            </button>
          </div>

          {/* Step 2: Upload Area */}
          <div>
            <h4 className="text-sm font-semibold text-white mb-2">2. Upload your CSV File</h4>
            <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 hover:border-blue-500/50 bg-slate-950/40 rounded-xl cursor-pointer transition-colors group">
              <Upload className="w-8 h-8 text-slate-400 group-hover:text-blue-400 transition-colors mb-2" />
              <span className="text-xs font-semibold text-slate-300">
                {file ? file.name : 'Click or Drag & Drop .CSV file here'}
              </span>
              <span className="text-[11px] text-slate-500 mt-1">Accepts UTF-8 .csv files only</span>
              <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Step 3: Preview parsed data */}
          {parsedData.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" /> {parsedData.length} records ready to import
                </span>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/80 text-slate-400 sticky top-0">
                    <tr>
                      {Object.keys(parsedData[0] || {}).map((header, idx) => (
                        <th key={idx} className="px-3 py-2 border-b border-slate-700/50 font-semibold">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50 text-slate-300">
                    {parsedData.slice(0, 5).map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-800/30">
                        {Object.values(row).map((val, cIdx) => (
                          <td key={cIdx} className="px-3 py-2 truncate max-w-[140px]">
                            {val}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {parsedData.length > 5 && (
                <p className="text-[11px] text-slate-500 text-right">+ {parsedData.length - 5} more records</p>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800 mt-auto">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleImport}
            disabled={parsedData.length === 0 || isSubmitting}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-500/20 transition-all flex items-center gap-2"
          >
            {isSubmitting ? 'Importing...' : `Import ${parsedData.length} Records`}
          </button>
        </div>
      </div>
    </div>
  );
};
