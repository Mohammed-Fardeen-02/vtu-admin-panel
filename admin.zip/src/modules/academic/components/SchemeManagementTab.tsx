import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Archive,
  RotateCcw,
  Power,
  CheckCircle2,
  GraduationCap,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../../shared/components/ui/ConfirmationModal';
import { useAcademicStore } from '../../../store/useAcademicStore';
import { AcademicScheme } from '../../../shared/types/academic.types';

export const SchemeManagementTab: React.FC = () => {
  const {
    schemes,
    addScheme,
    updateScheme,
    toggleSchemeStatus,
    archiveScheme,
    restoreScheme,
  } = useAcademicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingScheme, setEditingScheme] = useState<AcademicScheme | null>(null);
  const [year, setYear] = useState('2025');
  const [title, setTitle] = useState('');
  const [totalCredits, setTotalCredits] = useState(160);
  const [isDefault, setIsDefault] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Confirmation modal state
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const filteredSchemes = schemes.filter((s) => {
    const matchesSearch =
      s.year.includes(searchTerm) || s.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenCreate = () => {
    setEditingScheme(null);
    setYear('2025');
    setTitle('2025 NEP Model Scheme');
    setTotalCredits(160);
    setIsDefault(false);
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (s: AcademicScheme) => {
    setEditingScheme(s);
    setYear(s.year);
    setTitle(s.title);
    setTotalCredits(s.totalCreditsRequired);
    setIsDefault(s.isDefault);
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!year.trim() || !title.trim()) {
      setErrorMsg('Scheme year and title are required.');
      return;
    }

    if (editingScheme) {
      updateScheme(editingScheme.id, {
        year: year.trim(),
        title: title.trim(),
        totalCreditsRequired: Number(totalCredits),
        isDefault,
      });
      setIsFormOpen(false);
    } else {
      const res = addScheme({
        year: year.trim(),
        title: title.trim(),
        isDefault,
        status: 'ACTIVE',
        totalCreditsRequired: Number(totalCredits),
      });
      if (!res.success) {
        setErrorMsg(res.error || 'Duplicate scheme year.');
      } else {
        setIsFormOpen(false);
      }
    }
  };

  const requestArchive = (s: AcademicScheme) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Scheme '${s.year}'?`,
      message: `Archiving the ${s.year} Scheme will disable new subject registration under this scheme. You can restore it anytime.`,
      action: () => archiveScheme(s.id),
    });
  };

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl border border-border bg-card">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search scheme year (e.g. 2022)..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Schemes ({schemes.length})</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
            <option value="ARCHIVED">Archived Only</option>
          </select>
        </div>

        <Button variant="primary" size="sm" onClick={handleOpenCreate} icon={<Plus className="h-4 w-4" />}>
          Create New Academic Scheme
        </Button>
      </div>

      {/* Schemes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredSchemes.map((s) => (
          <div
            key={s.id}
            className={`p-5 rounded-2xl border bg-card transition-all flex flex-col justify-between space-y-4 relative ${
              s.isDefault ? 'border-primary shadow-md border-t-4 border-t-primary' : 'border-border'
            }`}
          >
            {s.isDefault && (
              <div className="absolute top-3 right-3">
                <Badge variant="primary" icon={<CheckCircle2 className="h-3 w-3" />} className="text-[10px]">
                  Default Active Scheme
                </Badge>
              </div>
            )}

            <div className="space-y-1.5 pt-1">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-primary/10 text-primary font-black">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <h4 className="text-xl font-black text-foreground">{s.year} Scheme</h4>
              </div>
              <p className="text-xs font-bold text-foreground leading-snug">{s.title}</p>
              <p className="text-[11px] text-muted-foreground font-medium">
                Total Required Graduation Credits: <span className="font-extrabold text-foreground">{s.totalCreditsRequired} Credits</span>
              </p>
            </div>

            <div className="pt-3 border-t border-border/60 flex items-center justify-between gap-2">
              <Badge
                variant={
                  s.status === 'ACTIVE'
                    ? 'success'
                    : s.status === 'INACTIVE'
                    ? 'warning'
                    : 'neutral'
                }
                className="text-[10px]"
              >
                {s.status}
              </Badge>

              <div className="flex items-center gap-1.5">
                <Button variant="outline" size="sm" onClick={() => handleOpenEdit(s)} icon={<Edit2 className="h-3.5 w-3.5" />}>
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toggleSchemeStatus(s.id)}
                  icon={<Power className="h-3.5 w-3.5" />}
                >
                  {s.status === 'ACTIVE' ? 'Pause' : 'Activate'}
                </Button>

                {s.status === 'ARCHIVED' ? (
                  <Button variant="primary" size="sm" onClick={() => restoreScheme(s.id)} icon={<RotateCcw className="h-3.5 w-3.5" />}>
                    Restore
                  </Button>
                ) : (
                  <Button variant="destructive" size="sm" onClick={() => requestArchive(s)} icon={<Archive className="h-3.5 w-3.5" />}>
                    Archive
                  </Button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-foreground">
              {editingScheme ? 'Edit Scheme' : 'Create Academic Scheme'}
            </h3>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-foreground mb-1">Scheme Year *</label>
                  <input
                    type="text"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    placeholder="e.g. 2025"
                    className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-foreground mb-1">Total Graduation Credits *</label>
                  <input
                    type="number"
                    value={totalCredits}
                    onChange={(e) => setTotalCredits(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Full Scheme Name *</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 2025 NEP Model Curriculum"
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
                  required
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="defaultCheck"
                  checked={isDefault}
                  onChange={(e) => setIsDefault(e.target.checked)}
                  className="rounded accent-primary h-4 w-4 cursor-pointer"
                />
                <label htmlFor="defaultCheck" className="font-bold text-foreground cursor-pointer">
                  Set as Default Active Scheme for New Students
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
                <Button variant="outline" size="sm" type="button" onClick={() => setIsFormOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit">
                  Save Scheme
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
