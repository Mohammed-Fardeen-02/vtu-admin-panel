import React, { useState } from 'react';
import { Plus, Search, MapPin, Globe, Mail, CheckCircle2, XCircle, UserCheck, Calendar, Download, Upload } from 'lucide-react';
import { College, StatusType } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface CollegesTabProps {
  colleges: College[];
  onAddCollege: (payload: Partial<College>) => Promise<any>;
  onEditCollege: (id: string, payload: Partial<College>) => Promise<any>;
  onDeactivateCollege: (id: string) => Promise<any>;
  onBulkImportCollege?: (dtos: any[]) => Promise<any>;
}

export const CollegesTab: React.FC<CollegesTabProps> = ({
  colleges,
  onAddCollege,
  onEditCollege,
  onDeactivateCollege,
  onBulkImportCollege,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [regionFilter, setRegionFilter] = useState('');
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [region, setRegion] = useState('Bengaluru');
  const [type, setType] = useState('AFFILIATED');
  const [address, setAddress] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirm Modal State
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const collegeList = Array.isArray(colleges) ? colleges : [];
  const filteredColleges = collegeList.filter((c) => {
    const matchesSearch =
      c.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.region.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRegion = regionFilter ? c.region === regionFilter : true;
    return matchesSearch && matchesRegion;
  });

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_colleges_directory',
      ['code', 'name', 'region', 'type', 'address', 'contactEmail', 'contactPhone', 'websiteUrl', 'status'],
      filteredColleges.map((c) => [c.code, c.name, c.region, c.type, c.address || '', c.contactEmail || '', c.contactPhone || '', c.websiteUrl || '', c.status])
    );
  };

  const openCreateModal = () => {
    setEditingId(null);
    setCode('');
    setName('');
    setRegion('Bengaluru');
    setType('AFFILIATED');
    setAddress('');
    setContactEmail('');
    setContactPhone('');
    setWebsiteUrl('');
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (c: College) => {
    setEditingId(c.id);
    setCode(c.code);
    setName(c.name);
    setRegion(c.region);
    setType(c.type);
    setAddress(c.address || '');
    setContactEmail(c.contactEmail || '');
    setContactPhone(c.contactPhone || '');
    setWebsiteUrl(c.websiteUrl || '');
    setStatus(c.status);
    setIsFormModalOpen(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      code,
      name,
      region,
      type,
      address,
      contactEmail,
      contactPhone,
      websiteUrl,
      status,
    };

    if (editingId) {
      await onEditCollege(editingId, payload);
    } else {
      await onAddCollege(payload);
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (c: College) => {
    const nextStatus: StatusType = c.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditCollege(c.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (c: College) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate College "${c.code}"?`,
      message: `Are you sure you want to deactivate ${c.code} (${c.name})? Existing student profiles mapped to this college will remain safe.`,
      actionId: c.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search & Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="w-full sm:w-60">
            <Input
              placeholder="Search College Code or Name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search className="h-4 w-4" />}
            />
          </div>

          <div className="w-40">
            <Select
              value={regionFilter}
              onChange={(e) => setRegionFilter(e.target.value)}
              placeholder="All Regions"
              options={[
                { label: 'Bengaluru Region', value: 'Bengaluru' },
                { label: 'Mysuru Region', value: 'Mysuru' },
                { label: 'Belagavi Region', value: 'Belagavi' },
                { label: 'Kalaburagi Region', value: 'Kalaburagi' },
              ]}
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Register New College</span>
          </Button>
        </div>
      </div>

      {/* Colleges Table Component */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>College Code</TableHead>
            <TableHead>College Name</TableHead>
            <TableHead>Region / City</TableHead>
            <TableHead>Institution Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Audit Meta</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredColleges.map((col) => (
            <TableRow key={col.id}>
              <TableCell className="font-bold text-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-7 px-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-black text-xs">
                    {col.code}
                  </div>
                </div>
              </TableCell>
              <TableCell className="font-semibold text-foreground">
                {col.name}
                {col.contactEmail && (
                  <p className="text-[11px] text-muted-foreground font-normal flex items-center gap-1 mt-0.5">
                    <Mail className="h-3 w-3" /> {col.contactEmail}
                  </p>
                )}
              </TableCell>
              <TableCell className="font-medium text-foreground">
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5 text-muted-foreground" /> {col.region}
                </span>
              </TableCell>
              <TableCell className="font-bold text-foreground">
                <span className="px-2.5 py-1 rounded-full bg-accent text-[10px] uppercase font-black">
                  {col.type}
                </span>
              </TableCell>
              <TableCell>
                {col.status === 'ACTIVE' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-[10px] font-black uppercase tracking-wider text-red-600 dark:text-red-400">
                    <XCircle className="h-3 w-3" /> INACTIVE
                  </span>
                )}
              </TableCell>
              <TableCell className="text-[11px] text-muted-foreground">
                <div className="flex flex-col">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> {new Date(col.createdAt).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] mt-0.5 text-foreground/70 font-semibold">
                    <UserCheck className="h-3 w-3 text-primary" /> {col.createdBy || 'Admin'}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <ActionDropdown
                  status={col.status}
                  onView={() => {
                    setSelectedCollege(col);
                    setIsViewModalOpen(true);
                  }}
                  onEdit={() => openEditModal(col)}
                  onToggleStatus={() => handleToggleStatus(col)}
                  onDelete={() => triggerDeactivateConfirm(col)}
                />
              </TableCell>
            </TableRow>
          ))}

          {filteredColleges.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                No colleges found. Click "+ Register New College" to add one.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit College */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit College Registration' : 'Register New College'}
        subtitle="Manage VTU affiliated and autonomous engineering institutions"
        maxWidth="lg"
      >
        <form id="college-form" onSubmit={handleFormSubmit} className="space-y-4 pt-2">
          <Input
            label="College Code *"
            required
            disabled={!!editingId}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="e.g. 1VA, 1RV, 1BMS, 1MS"
          />

          <Input
            label="College Full Name *"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Sai Vidya Institute of Technology"
          />

          <div className="grid grid-cols-2 gap-4">
            <Select
              label="Region / City *"
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              options={[
                { label: 'Bengaluru', value: 'Bengaluru' },
                { label: 'Mysuru', value: 'Mysuru' },
                { label: 'Belagavi', value: 'Belagavi' },
                { label: 'Kalaburagi', value: 'Kalaburagi' },
              ]}
            />

            <Select
              label="Institution Type *"
              value={type}
              onChange={(e) => setType(e.target.value)}
              options={[
                { label: 'AFFILIATED', value: 'AFFILIATED' },
                { label: 'AUTONOMOUS', value: 'AUTONOMOUS' },
                { label: 'CONSTITUENT', value: 'CONSTITUENT' },
              ]}
            />
          </div>

          <Input
            label="Official Email"
            type="email"
            value={contactEmail}
            onChange={(e) => setContactEmail(e.target.value)}
            placeholder="e.g. info@saividya.ac.in"
          />

          <Input
            label="Official Website URL"
            value={websiteUrl}
            onChange={(e) => setWebsiteUrl(e.target.value)}
            placeholder="https://saividya.ac.in"
          />

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Register College'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Centered View Details Overview Modal */}
      {selectedCollege && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`College Overview: ${selectedCollege.code}`}
          subtitle={selectedCollege.name}
          maxWidth="md"
        >
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 border-b border-border pb-4">
              <div className="h-12 px-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 flex items-center justify-center font-black text-base">
                {selectedCollege.code}
              </div>
              <div>
                <h4 className="text-base font-extrabold text-foreground">{selectedCollege.name}</h4>
                <p className="text-xs text-muted-foreground">{selectedCollege.region} Region • {selectedCollege.type}</p>
              </div>
            </div>

            <div className="bg-muted/40 p-4 rounded-xl space-y-2 border border-border/60 text-xs">
              {selectedCollege.contactEmail && (
                <div className="flex items-center gap-2 text-foreground">
                  <Mail className="h-3.5 w-3.5 text-primary" />
                  <span>{selectedCollege.contactEmail}</span>
                </div>
              )}
              {selectedCollege.websiteUrl && (
                <div className="flex items-center gap-2 text-foreground">
                  <Globe className="h-3.5 w-3.5 text-primary" />
                  <a href={selectedCollege.websiteUrl} target="_blank" rel="noreferrer" className="underline text-blue-500 font-semibold">
                    {selectedCollege.websiteUrl}
                  </a>
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
              <span>Registered: {new Date(selectedCollege.createdAt).toLocaleDateString()}</span>
              <span>Created By: {selectedCollege.createdBy || 'Admin'}</span>
            </div>
          </div>
        </Modal>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import VTU Colleges Directory"
        entityName="Colleges"
        sampleHeaders={['code', 'name', 'region', 'type', 'address', 'contactEmail', 'contactPhone', 'websiteUrl', 'status']}
        sampleRows={[
          ['1BI', 'BMS Institute of Technology & Management', 'Bengaluru', 'AFFILIATED', 'Avalahalli, Yelahanka, Bengaluru', 'info@bmsit.in', '08028463242', 'https://bmsit.ac.in', 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportCollege) {
            await onBulkImportCollege(
              parsedRecords.map((r) => ({
                code: r.code,
                name: r.name,
                region: r.region || 'Bengaluru',
                type: r.type || 'AFFILIATED',
                address: r.address,
                contactEmail: r.contactEmail,
                contactPhone: r.contactPhone,
                websiteUrl: r.websiteUrl,
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateCollege(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
