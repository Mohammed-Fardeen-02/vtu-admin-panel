import React, { useState } from 'react';
import { Plus, Search, Layers, Calendar, CheckCircle2, XCircle, UserCheck, Download, Upload } from 'lucide-react';
import { Scheme, StatusType } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface SchemesTabProps {
  schemes: Scheme[];
  onAddScheme: (payload: Partial<Scheme>) => Promise<any>;
  onEditScheme: (id: string, payload: Partial<Scheme>) => Promise<any>;
  onDeactivateScheme: (id: string) => Promise<any>;
  onBulkImportScheme?: (dtos: any[]) => Promise<any>;
}

export const SchemesTab: React.FC<SchemesTabProps> = ({
  schemes,
  onAddScheme,
  onEditScheme,
  onDeactivateScheme,
  onBulkImportScheme,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedScheme, setSelectedScheme] = useState<Scheme | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [schemeYear, setSchemeYear] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [totalCredits, setTotalCredits] = useState<number>(160);
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirmation Modal State
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const schemeList = Array.isArray(schemes) ? schemes : [];
  const filteredSchemes = schemeList.filter(
    (s) =>
      s.schemeYear.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_academic_schemes',
      ['schemeYear', 'name', 'description', 'totalCredits', 'status'],
      filteredSchemes.map((s) => [s.schemeYear, s.name, s.description || '', s.totalCredits, s.status])
    );
  };

  const openCreateModal = () => {
    setEditingId(null);
    setSchemeYear('');
    setName('');
    setDescription('');
    setTotalCredits(160);
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (s: Scheme) => {
    setEditingId(s.id);
    setSchemeYear(s.schemeYear);
    setName(s.name);
    setDescription(s.description || '');
    setTotalCredits(s.totalCredits);
    setStatus(s.status);
    setIsFormModalOpen(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await onEditScheme(editingId, { name, description, totalCredits, status });
    } else {
      await onAddScheme({ schemeYear, name, description, totalCredits, status });
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (s: Scheme) => {
    const nextStatus: StatusType = s.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditScheme(s.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (s: Scheme) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate Scheme "${s.schemeYear}"?`,
      message: `Are you sure you want to set Scheme ${s.schemeYear} (${s.name}) to INACTIVE? Historic student records will remain preserved.`,
      actionId: s.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search & Actions Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="w-full sm:w-80">
          <Input
            placeholder="Search Scheme Year or Name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="h-4 w-4" />}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Add Academic Scheme</span>
          </Button>
        </div>
      </div>

      {/* Schemes List Table */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Scheme Year</TableHead>
            <TableHead>Scheme Name</TableHead>
            <TableHead>Total Credits</TableHead>
            <TableHead>Mapped Subjects</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Audit Meta</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredSchemes.map((scheme) => (
            <TableRow key={scheme.id}>
              <TableCell className="font-bold text-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center font-extrabold text-xs">
                    {scheme.schemeYear.substring(2)}
                  </div>
                  <span>{scheme.schemeYear} Scheme</span>
                </div>
              </TableCell>
              <TableCell className="font-semibold text-foreground">
                {scheme.name}
                {scheme.description && (
                  <p className="text-[11px] text-muted-foreground font-normal line-clamp-1">{scheme.description}</p>
                )}
              </TableCell>
              <TableCell className="font-extrabold text-foreground">{scheme.totalCredits} Credits</TableCell>
              <TableCell>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-accent text-[11px] font-bold text-foreground">
                  <Layers className="h-3 w-3 text-muted-foreground" />
                  {scheme._count?.courses || 0} Courses
                </span>
              </TableCell>
              <TableCell>
                {scheme.status === 'ACTIVE' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-[10px] font-black uppercase tracking-wider text-red-600 dark:text-red-400">
                    <XCircle className="h-3 w-3" /> INACTIVE
                  </span>
                )}
              </TableCell>
              <TableCell className="text-[11px] text-muted-foreground">
                <div className="flex flex-col">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> {new Date(scheme.createdAt).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] mt-0.5 text-foreground/70 font-semibold">
                    <UserCheck className="h-3 w-3 text-primary" /> {scheme.createdBy || 'Admin'}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <ActionDropdown
                  status={scheme.status}
                  onView={() => {
                    setSelectedScheme(scheme);
                    setIsViewModalOpen(true);
                  }}
                  onEdit={() => openEditModal(scheme)}
                  onToggleStatus={() => handleToggleStatus(scheme)}
                  onDelete={() => triggerDeactivateConfirm(scheme)}
                />
              </TableCell>
            </TableRow>
          ))}

          {filteredSchemes.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                No academic schemes found. Click "+ Add Academic Scheme" to define one.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit Scheme */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit Academic Scheme' : 'Add New Academic Scheme'}
        subtitle="Specify scheme regulations, total graduation credits, and status"
        maxWidth="lg"
      >
        <form id="scheme-form" onSubmit={handleFormSubmit} className="space-y-4 pt-2">
          <Input
            label="Scheme Year *"
            required
            disabled={!!editingId}
            value={schemeYear}
            onChange={(e) => setSchemeYear(e.target.value)}
            placeholder="e.g. 2022, 2026"
          />

          <Input
            label="Scheme Name / Title *"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. NEP 2022 Scheme"
          />

          <Input
            label="Total Graduation Credits *"
            type="number"
            step="0.5"
            required
            value={totalCredits}
            onChange={(e) => setTotalCredits(parseFloat(e.target.value) || 160)}
          />

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1.5">
              Description / Notes
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description of the scheme regulations..."
              className="w-full rounded-xl border border-input bg-card px-3.5 py-2 text-xs font-medium text-foreground transition-all duration-200 placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled across system)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Create Scheme'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Centered View Details Overview Modal */}
      {selectedScheme && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Scheme Overview: ${selectedScheme.schemeYear}`}
          subtitle={selectedScheme.name}
          maxWidth="md"
        >
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 border-b border-border pb-4">
              <div className="h-12 w-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-600 flex items-center justify-center font-black text-base">
                {selectedScheme.schemeYear}
              </div>
              <div>
                <h4 className="text-base font-extrabold text-foreground">{selectedScheme.name}</h4>
                <p className="text-xs text-muted-foreground">Scheme Code: {selectedScheme.schemeYear}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-muted/40 p-4 rounded-xl border border-border/60">
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Total Credits</span>
                <span className="font-extrabold text-foreground text-sm">{selectedScheme.totalCredits} Credits</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Status</span>
                <span className={`font-bold text-xs ${selectedScheme.status === 'ACTIVE' ? 'text-emerald-500' : 'text-red-500'}`}>
                  {selectedScheme.status}
                </span>
              </div>
            </div>

            <div>
              <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider mb-1">Description</span>
              <p className="text-foreground leading-relaxed bg-background p-3 rounded-xl border border-border text-xs">
                {selectedScheme.description || 'No detailed notes provided for this scheme.'}
              </p>
            </div>

            <div className="pt-2 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
              <span>Created: {new Date(selectedScheme.createdAt).toLocaleString()}</span>
              <span>Updated: {new Date(selectedScheme.updatedAt).toLocaleString()}</span>
            </div>
          </div>
        </Modal>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import Academic Schemes"
        entityName="Schemes"
        sampleHeaders={['schemeYear', 'name', 'description', 'totalCredits', 'status']}
        sampleRows={[
          ['2026', '2026 NEP Scheme', 'VTU 2026 Outcome Based Education Scheme', 160, 'ACTIVE'],
          ['2025', '2025 Autonomous Scheme', 'VTU 2025 Autonomous Syllabus', 160, 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportScheme) {
            await onBulkImportScheme(
              parsedRecords.map((r) => ({
                schemeYear: r.schemeYear,
                name: r.name,
                description: r.description,
                totalCredits: r.totalCredits ? Number(r.totalCredits) : 160,
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateScheme(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
