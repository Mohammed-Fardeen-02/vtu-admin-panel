import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Filter,
  Edit2,
  Archive,
  RotateCcw,
  Power,
  Layers,
  BookOpen,
  CheckCircle2,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../../shared/components/ui/ConfirmationModal';
import { SubjectFormModal } from './SubjectFormModal';
import { useAcademicStore } from '../../../store/useAcademicStore';
import { AcademicSubject } from '../../../shared/types/academic.types';

export interface SubjectManagementTabProps {
  onSelectSubjectForModules: (subject: AcademicSubject) => void;
}

export const SubjectManagementTab: React.FC<SubjectManagementTabProps> = ({
  onSelectSubjectForModules,
}) => {
  const {
    branches,
    schemes,
    subjects,
    addSubject,
    updateSubject,
    toggleSubjectStatus,
    archiveSubject,
    restoreSubject,
  } = useAcademicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [branchFilter, setBranchFilter] = useState('ALL');
  const [schemeFilter, setSchemeFilter] = useState('ALL');
  const [semFilter, setSemFilter] = useState<number | 'ALL'>('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Form modal
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<AcademicSubject | null>(null);

  // Confirmation modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const availableBranches = useMemo(() => branches.map((b) => b.code), [branches]);
  const availableSchemes = useMemo(() => schemes.map((s) => s.year), [schemes]);

  const filteredSubjects = useMemo(() => {
    return subjects.filter((s) => {
      let matchesSearch = true;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        matchesSearch =
          s.code.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q) ||
          (s.description || '').toLowerCase().includes(q);
      }

      const matchesBranch = branchFilter === 'ALL' || s.branchCode === branchFilter;
      const matchesScheme = schemeFilter === 'ALL' || s.schemeYear === schemeFilter;
      const matchesSem = semFilter === 'ALL' || s.semester === semFilter;
      const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;

      return matchesSearch && matchesBranch && matchesScheme && matchesSem && matchesStatus;
    });
  }, [subjects, searchTerm, branchFilter, schemeFilter, semFilter, statusFilter]);

  const handleOpenCreate = () => {
    setEditingSubject(null);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (s: AcademicSubject) => {
    setEditingSubject(s);
    setIsFormOpen(true);
  };

  const handleSaveSubject = (payload: Omit<AcademicSubject, 'id'> | AcademicSubject) => {
    if ('id' in payload) {
      return updateSubject(payload.id, payload);
    } else {
      return addSubject(payload);
    }
  };

  const requestArchive = (s: AcademicSubject) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Subject '${s.code}'?`,
      message: `Archiving ${s.code} - ${s.name} will unbind it from active student course lists while retaining all historical notes and question papers.`,
      action: () => archiveSubject(s.id),
    });
  };

  return (
    <div className="space-y-4">
      {/* Top Filter & Controls */}
      <div className="flex flex-col xl:flex-row items-center justify-between gap-3 p-4 rounded-2xl border border-border bg-card">
        {/* Search */}
        <div className="relative w-full xl:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search subject code or name..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
          />
        </div>

        {/* Multi-Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
          {/* Branch */}
          <select
            value={branchFilter}
            onChange={(e) => setBranchFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Branches ({branches.length})</option>
            {branches.map((b) => (
              <option key={b.id} value={b.code}>
                {b.code}
              </option>
            ))}
          </select>

          {/* Scheme */}
          <select
            value={schemeFilter}
            onChange={(e) => setSchemeFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Schemes ({schemes.length})</option>
            {schemes.map((s) => (
              <option key={s.id} value={s.year}>
                {s.year} Scheme
              </option>
            ))}
          </select>

          {/* Semester */}
          <select
            value={semFilter}
            onChange={(e) =>
              setSemFilter(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))
            }
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Semesters</option>
            {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
              <option key={sem} value={sem}>
                Sem {sem}
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
            <option value="ARCHIVED">Archived Only</option>
          </select>
        </div>

        <Button variant="primary" size="sm" onClick={handleOpenCreate} icon={<Plus className="h-4 w-4" />}>
          Add Subject Entity
        </Button>
      </div>

      {/* Subjects Table */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-table-header-bg text-table-header-text border-b border-table-header-border">
                <th className="p-3.5 font-extrabold">Subject Code</th>
                <th className="p-3.5 font-extrabold">Subject Title</th>
                <th className="p-3.5 font-extrabold">Branch</th>
                <th className="p-3.5 font-extrabold">Scheme</th>
                <th className="p-3.5 font-extrabold text-center">Sem</th>
                <th className="p-3.5 font-extrabold text-center">Credits</th>
                <th className="p-3.5 font-extrabold text-center">Category</th>
                <th className="p-3.5 font-extrabold text-center">Status</th>
                <th className="p-3.5 font-extrabold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {filteredSubjects.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-muted-foreground">
                    <BookOpen className="h-8 w-8 text-primary mx-auto mb-2 opacity-50" />
                    <p className="font-bold">No Subject Entities Found</p>
                    <p className="text-[11px] mt-0.5">Try resetting your search or filter selection.</p>
                  </td>
                </tr>
              ) : (
                filteredSubjects.map((s) => (
                  <tr key={s.id} className="hover:bg-accent/40 transition-colors">
                    <td className="p-3.5 font-black text-primary text-sm">{s.code}</td>
                    <td className="p-3.5 space-y-0.5">
                      <p className="font-bold text-foreground">{s.name}</p>
                      {s.description && (
                        <p className="text-[10px] text-muted-foreground truncate max-w-xs">
                          {s.description}
                        </p>
                      )}
                    </td>
                    <td className="p-3.5 font-bold">{s.branchCode}</td>
                    <td className="p-3.5 font-bold">{s.schemeYear} Scheme</td>
                    <td className="p-3.5 text-center font-extrabold">Sem {s.semester}</td>
                    <td className="p-3.5 text-center font-black text-foreground">{s.credits}</td>
                    <td className="p-3.5 text-center">
                      <Badge
                        variant={
                          s.category === 'THEORY'
                            ? 'primary'
                            : s.category === 'LAB'
                            ? 'info'
                            : s.category === 'INTEGRATED'
                            ? 'success'
                            : 'warning'
                        }
                        className="text-[9px]"
                      >
                        {s.category}
                      </Badge>
                    </td>
                    <td className="p-3.5 text-center">
                      <Badge
                        variant={
                          s.status === 'ACTIVE'
                            ? 'success'
                            : s.status === 'INACTIVE'
                            ? 'warning'
                            : 'neutral'
                        }
                        className="text-[10px]"
                      >
                        {s.status}
                      </Badge>
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => onSelectSubjectForModules(s)}
                          icon={<Layers className="h-3.5 w-3.5" />}
                        >
                          Modules & Units
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenEdit(s)}
                          icon={<Edit2 className="h-3.5 w-3.5" />}
                        >
                          Edit
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleSubjectStatus(s.id)}
                          icon={<Power className="h-3.5 w-3.5" />}
                        >
                          {s.status === 'ACTIVE' ? 'Pause' : 'Activate'}
                        </Button>

                        {s.status === 'ARCHIVED' ? (
                          <Button
                            variant="primary"
                            size="sm"
                            onClick={() => restoreSubject(s.id)}
                            icon={<RotateCcw className="h-3.5 w-3.5" />}
                          >
                            Restore
                          </Button>
                        ) : (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => requestArchive(s)}
                            icon={<Archive className="h-3.5 w-3.5" />}
                          >
                            Archive
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Form Modal */}
      <SubjectFormModal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        onSave={handleSaveSubject}
        initialSubject={editingSubject}
        availableBranches={availableBranches}
        availableSchemes={availableSchemes}
      />

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
