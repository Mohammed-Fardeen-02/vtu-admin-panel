import React, { useState } from 'react';
import { Plus, Search, BookOpen, CheckCircle2, XCircle, Download, Upload } from 'lucide-react';
import { Course, Scheme, Branch, Semester, CourseType, StatusType, SyllabusUnit } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface CoursesTabProps {
  courses: Course[];
  schemes: Scheme[];
  branches: Branch[];
  semesters: Semester[];
  courseTypes: CourseType[];
  onFilterCourses: (filters?: { schemeId?: string; branchId?: string; semesterId?: string }) => void;
  onAddCourse: (payload: Partial<Course>) => Promise<any>;
  onEditCourse: (id: string, payload: Partial<Course>) => Promise<any>;
  onDeactivateCourse: (id: string) => Promise<any>;
  onBulkImportCourse?: (dtos: any[]) => Promise<any>;
}

export const CoursesTab: React.FC<CoursesTabProps> = ({
  courses,
  schemes = [],
  branches = [],
  semesters = [],
  courseTypes = [],
  onFilterCourses,
  onAddCourse,
  onEditCourse,
  onDeactivateCourse,
  onBulkImportCourse,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSchemeId, setFilterSchemeId] = useState('');
  const [filterBranchId, setFilterBranchId] = useState('');
  const [filterSemId, setFilterSemId] = useState('');

  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [subjectCode, setSubjectCode] = useState('');
  const [title, setTitle] = useState('');
  const [schemeId, setSchemeId] = useState('');
  const [branchId, setBranchId] = useState('');
  const [semesterId, setSemesterId] = useState('');
  const [courseTypeId, setCourseTypeId] = useState('');
  const [credits, setCredits] = useState<number>(4.0);
  const [seeMarks, setSeeMarks] = useState<number>(50);
  const [cieMarks, setCieMarks] = useState<number>(50);
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirm Modal State
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const courseList = Array.isArray(courses) ? courses : [];

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_subjects_syllabus_master',
      ['subjectCode', 'title', 'credits', 'cieMarks', 'seeMarks', 'status'],
      courseList.map((c) => [c.subjectCode, c.title, c.credits, c.cieMarks, c.seeMarks, c.status])
    );
  };

  const filteredCourses = courseList.filter((c) => {
    const matchesSearch =
      c.subjectCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesScheme = filterSchemeId ? c.schemeId === filterSchemeId : true;
    const matchesBranch = filterBranchId ? c.branchId === filterBranchId : true;
    const matchesSem = filterSemId ? c.semesterId === filterSemId : true;
    return matchesSearch && matchesScheme && matchesBranch && matchesSem;
  });

  // Select Options mapped from Master Data
  const schemeOptions = schemes.map((s) => ({ label: `${s.schemeYear} Scheme (${s.name})`, value: s.id }));
  const branchOptions = branches.map((b) => ({ label: `${b.code} - ${b.name}`, value: b.id }));
  const semesterOptions = semesters.map((sem) => ({ label: `Semester ${sem.number} (${sem.label})`, value: sem.id }));
  const courseTypeOptions = courseTypes.map((ct) => ({ label: `${ct.code} - ${ct.name}`, value: ct.id }));

  const openCreateModal = () => {
    setEditingId(null);
    setSubjectCode('');
    setTitle('');
    setSchemeId(schemes[0]?.id || '');
    setBranchId(branches[0]?.id || '');
    setSemesterId(semesters[0]?.id || '');
    setCourseTypeId(courseTypes[0]?.id || '');
    setCredits(4.0);
    setSeeMarks(50);
    setCieMarks(50);
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (c: Course) => {
    setEditingId(c.id);
    setSubjectCode(c.subjectCode);
    setTitle(c.title);
    setSchemeId(c.schemeId);
    setBranchId(c.branchId);
    setSemesterId(c.semesterId);
    setCourseTypeId(c.courseTypeId);
    setCredits(c.credits);
    setSeeMarks(c.seeMarks);
    setCieMarks(c.cieMarks);
    setStatus(c.status);
    setIsFormModalOpen(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      subjectCode,
      title,
      schemeId,
      branchId,
      semesterId,
      courseTypeId,
      credits,
      seeMarks,
      cieMarks,
      status,
    };

    if (editingId) {
      await onEditCourse(editingId, payload);
    } else {
      await onAddCourse(payload);
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (c: Course) => {
    const nextStatus: StatusType = c.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditCourse(c.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (c: Course) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate Subject "${c.subjectCode}"?`,
      message: `Are you sure you want to deactivate ${c.subjectCode} (${c.title})?`,
      actionId: c.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Filters & Search Bar */}
      <div className="flex flex-col lg:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Search */}
          <div className="w-full sm:w-60">
            <Input
              placeholder="Search Code or Title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search className="h-4 w-4" />}
            />
          </div>

          {/* Scheme Filter Dropdown */}
          <div className="w-40">
            <Select
              value={filterSchemeId}
              onChange={(e) => setFilterSchemeId(e.target.value)}
              placeholder="All Schemes"
              options={schemeOptions}
            />
          </div>

          {/* Branch Filter Dropdown */}
          <div className="w-44">
            <Select
              value={filterBranchId}
              onChange={(e) => setFilterBranchId(e.target.value)}
              placeholder="All Branches"
              options={branchOptions}
            />
          </div>

          {/* Semester Filter Dropdown */}
          <div className="w-36">
            <Select
              value={filterSemId}
              onChange={(e) => setFilterSemId(e.target.value)}
              placeholder="All Semesters"
              options={semesterOptions}
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Add Subject / Syllabus</span>
          </Button>
        </div>
      </div>

      {/* Courses Table Component */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Subject Code</TableHead>
            <TableHead>Subject Title</TableHead>
            <TableHead>Scheme & Branch</TableHead>
            <TableHead>Semester</TableHead>
            <TableHead>Category & Credits</TableHead>
            <TableHead>SEE / CIE Marks</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredCourses.map((c) => (
            <TableRow key={c.id}>
              <TableCell className="font-bold text-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-7 px-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-600 dark:text-blue-400 flex items-center justify-center font-black text-xs">
                    {c.subjectCode}
                  </div>
                </div>
              </TableCell>
              <TableCell className="font-semibold text-foreground max-w-xs truncate">{c.title}</TableCell>
              <TableCell>
                <div className="flex flex-col text-[11px]">
                  <span className="font-bold text-foreground">{c.scheme?.schemeYear || '2022'} Scheme</span>
                  <span className="text-muted-foreground font-semibold">{c.branch?.code || 'CSE'}</span>
                </div>
              </TableCell>
              <TableCell>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-accent text-[11px] font-black text-foreground">
                  Sem {c.semester?.number || 5}
                </span>
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black text-emerald-600 dark:text-emerald-400">
                    {c.courseType?.code || 'PCC'}
                  </span>
                  <span className="font-bold text-foreground">{c.credits} Cr</span>
                </div>
              </TableCell>
              <TableCell className="text-[11px] text-muted-foreground font-semibold">
                SEE: {c.seeMarks} | CIE: {c.cieMarks}
              </TableCell>
              <TableCell>
                {c.status === 'ACTIVE' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-[10px] font-black uppercase tracking-wider text-red-600 dark:text-red-400">
                    <XCircle className="h-3 w-3" /> INACTIVE
                  </span>
                )}
              </TableCell>
              <TableCell className="text-right">
                <ActionDropdown
                  status={c.status}
                  onView={() => {
                    setSelectedCourse(c);
                    setIsViewModalOpen(true);
                  }}
                  onEdit={() => openEditModal(c)}
                  onToggleStatus={() => handleToggleStatus(c)}
                  onDelete={() => triggerDeactivateConfirm(c)}
                />
              </TableCell>
            </TableRow>
          ))}

          {filteredCourses.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} className="py-8 text-center text-muted-foreground">
                No subjects found matching selected filters. Click "+ Add Subject / Syllabus" to create one.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit Subject */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit Subject / Syllabus' : 'Add New Subject'}
        subtitle="Provision subjects, credits, and syllabus structure across schemes"
        maxWidth="xl"
      >
        <form id="course-form" onSubmit={handleFormSubmit} className="space-y-4 pt-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Subject Code *"
              required
              disabled={!!editingId}
              value={subjectCode}
              onChange={(e) => setSubjectCode(e.target.value.toUpperCase())}
              placeholder="e.g. 21CS53"
            />

            <Input
              label="Subject Title *"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Computer Networks & Security"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Academic Scheme *"
              value={schemeId}
              onChange={(e) => setSchemeId(e.target.value)}
              placeholder="-- Select Scheme --"
              options={schemeOptions}
            />

            <Select
              label="Engineering Branch *"
              value={branchId}
              onChange={(e) => setBranchId(e.target.value)}
              placeholder="-- Select Branch --"
              options={branchOptions}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Semester *"
              value={semesterId}
              onChange={(e) => setSemesterId(e.target.value)}
              placeholder="-- Select Semester --"
              options={semesterOptions}
            />

            <Select
              label="Course Category / Type *"
              value={courseTypeId}
              onChange={(e) => setCourseTypeId(e.target.value)}
              placeholder="-- Select Course Category --"
              options={courseTypeOptions}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <Input
              label="Credits *"
              type="number"
              step="0.5"
              required
              value={credits}
              onChange={(e) => setCredits(parseFloat(e.target.value) || 4.0)}
            />

            <Input
              label="SEE Marks *"
              type="number"
              required
              value={seeMarks}
              onChange={(e) => setSeeMarks(parseInt(e.target.value) || 50)}
            />

            <Input
              label="CIE Marks *"
              type="number"
              required
              value={cieMarks}
              onChange={(e) => setCieMarks(parseInt(e.target.value) || 50)}
            />
          </div>

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled across Mobile & Portal)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Create Subject'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Centered View Syllabus & Subject Overview Modal */}
      {selectedCourse && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Subject: ${selectedCourse.subjectCode}`}
          subtitle={selectedCourse.title}
          maxWidth="2xl"
        >
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 border-b border-border pb-4">
              <div className="h-12 w-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-blue-600 flex items-center justify-center font-black text-sm">
                {selectedCourse.subjectCode}
              </div>
              <div>
                <h4 className="text-base font-extrabold text-foreground">{selectedCourse.title}</h4>
                <p className="text-xs text-muted-foreground">
                  {selectedCourse.scheme?.schemeYear} Scheme | {selectedCourse.branch?.code} | Sem {selectedCourse.semester?.number}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-3 bg-muted/40 p-4 rounded-xl text-center border border-border/60">
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Category</span>
                <span className="font-extrabold text-foreground">{selectedCourse.courseType?.code}</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Credits</span>
                <span className="font-extrabold text-foreground">{selectedCourse.credits} Cr</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">SEE / CIE</span>
                <span className="font-extrabold text-foreground">{selectedCourse.seeMarks} / {selectedCourse.cieMarks}</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Status</span>
                <span className={`font-bold text-xs ${selectedCourse.status === 'ACTIVE' ? 'text-emerald-500' : 'text-red-500'}`}>
                  {selectedCourse.status}
                </span>
              </div>
            </div>

            <div>
              <h5 className="text-xs font-bold text-foreground uppercase tracking-wider mb-2">5-Unit Syllabus Breakdown</h5>
              {selectedCourse.syllabusUnits && selectedCourse.syllabusUnits.length > 0 ? (
                <div className="space-y-2">
                  {selectedCourse.syllabusUnits.map((u: SyllabusUnit, idx: number) => (
                    <div key={idx} className="p-3 rounded-xl border border-border bg-background">
                      <span className="text-xs font-extrabold text-primary block">
                        Unit {u.unitNumber || idx + 1}: {u.title}
                      </span>
                      <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">{u.topics}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground italic bg-background p-3 rounded-xl border border-border">
                  Standard 5-unit VTU syllabus outline registered for {selectedCourse.subjectCode}.
                </p>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import Subjects & Syllabus"
        entityName="Courses"
        sampleHeaders={['subjectCode', 'title', 'schemeId', 'branchId', 'semesterId', 'courseTypeId', 'credits', 'cieMarks', 'seeMarks', 'status']}
        sampleRows={[
          ['21CS51', 'Automata Theory & Computability', schemes[0]?.id || '', branches[0]?.id || '', semesters[0]?.id || '', courseTypes[0]?.id || '', 4, 50, 50, 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportCourse) {
            await onBulkImportCourse(
              parsedRecords.map((r) => ({
                subjectCode: r.subjectCode,
                title: r.title,
                schemeId: r.schemeId || schemes[0]?.id,
                branchId: r.branchId || branches[0]?.id,
                semesterId: r.semesterId || semesters[0]?.id,
                courseTypeId: r.courseTypeId || courseTypes[0]?.id,
                credits: r.credits ? Number(r.credits) : 4,
                cieMarks: r.cieMarks ? Number(r.cieMarks) : 50,
                seeMarks: r.seeMarks ? Number(r.seeMarks) : 50,
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateCourse(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
