import React, { useState, useEffect } from 'react';
import { X, FileCode, AlertCircle } from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { AcademicUnit } from '../../../shared/types/academic.types';

export interface UnitFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (unit: Omit<AcademicUnit, 'id'> | AcademicUnit) => { success: boolean; error?: string };
  moduleId: string;
  initialUnit?: AcademicUnit | null;
  existingUnitsCount: number;
}

export const UnitFormModal: React.FC<UnitFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  moduleId,
  initialUnit,
  existingUnitsCount,
}) => {
  const [unitNumber, setUnitNumber] = useState(1);
  const [title, setTitle] = useState('');
  const [topicsCount, setTopicsCount] = useState(4);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialUnit) {
      setUnitNumber(initialUnit.unitNumber);
      setTitle(initialUnit.title);
      setTopicsCount(initialUnit.topicsCount || 4);
    } else {
      setUnitNumber(existingUnitsCount + 1);
      setTitle(`Unit ${existingUnitsCount + 1}: `);
      setTopicsCount(4);
    }
    setErrorMsg('');
  }, [initialUnit, existingUnitsCount, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Unit title is required.');
      return;
    }

    const payload = {
      ...(initialUnit ? { id: initialUnit.id } : {}),
      moduleId,
      unitNumber: Number(unitNumber),
      title: title.trim(),
      topicsCount: Number(topicsCount),
      status: initialUnit ? initialUnit.status : ('ACTIVE' as const),
      order: Number(unitNumber),
    };

    const res = onSave(payload as any);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to save unit.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-border/60 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <FileCode className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-black text-foreground">
              {initialUnit ? 'Edit Topic Unit' : 'Add New Topic Unit'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-accent"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">Unit No. *</label>
              <input
                type="number"
                min="1"
                max="10"
                value={unitNumber}
                onChange={(e) => setUnitNumber(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Sub-topics Count *</label>
              <input
                type="number"
                min="1"
                max="20"
                value={topicsCount}
                onChange={(e) => setTopicsCount(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Unit Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Unit 1: ER Diagrams & Cardinality Constraints"
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
              required
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
            <Button variant="outline" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {initialUnit ? 'Update Unit' : 'Save Unit'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
