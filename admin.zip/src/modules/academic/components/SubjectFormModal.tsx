import React, { useState, useEffect } from 'react';
import { X, BookOpen, AlertCircle } from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { AcademicSubject, SubjectCategory } from '../../../shared/types/academic.types';

export interface SubjectFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subject: Omit<AcademicSubject, 'id'> | AcademicSubject) => { success: boolean; error?: string };
  initialSubject?: AcademicSubject | null;
  availableBranches: string[];
  availableSchemes: string[];
}

export const SubjectFormModal: React.FC<SubjectFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialSubject,
  availableBranches,
  availableSchemes,
}) => {
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [branchCode, setBranchCode] = useState(availableBranches[0] || 'CSE');
  const [schemeYear, setSchemeYear] = useState(availableSchemes[0] || '2022');
  const [semester, setSemester] = useState(5);
  const [credits, setCredits] = useState(4);
  const [category, setCategory] = useState<SubjectCategory>('THEORY');
  const [description, setDescription] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialSubject) {
      setCode(initialSubject.code);
      setName(initialSubject.name);
      setBranchCode(initialSubject.branchCode);
      setSchemeYear(initialSubject.schemeYear);
      setSemester(initialSubject.semester);
      setCredits(initialSubject.credits);
      setCategory(initialSubject.category);
      setDescription(initialSubject.description || '');
    } else {
      setCode('');
      setName('');
      setSemester(5);
      setCredits(4);
      setCategory('THEORY');
      setDescription('');
    }
    setErrorMsg('');
  }, [initialSubject, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) {
      setErrorMsg('Subject code and subject name are required.');
      return;
    }

    const payload = {
      ...(initialSubject ? { id: initialSubject.id } : {}),
      code: code.trim().toUpperCase(),
      name: name.trim(),
      branchCode,
      schemeYear,
      semester: Number(semester),
      credits: Number(credits),
      category,
      status: initialSubject ? initialSubject.status : ('ACTIVE' as const),
      order: initialSubject ? initialSubject.order : 1,
      description: description.trim(),
    };

    const res = onSave(payload as any);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to save subject.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-lg bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
        <div className="flex items-center justify-between border-b border-border/60 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">
              <BookOpen className="h-5 w-5" />
            </div>
            <h3 className="text-lg font-black text-foreground">
              {initialSubject ? 'Edit Subject Entity' : 'Create New Academic Subject'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-accent"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">Subject Code *</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. 21CS53"
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none uppercase font-bold"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Credits *</label>
              <input
                type="number"
                min="1"
                max="10"
                value={credits}
                onChange={(e) => setCredits(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Subject Name *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Database Management Systems"
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">Branch *</label>
              <select
                value={branchCode}
                onChange={(e) => setBranchCode(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
              >
                {availableBranches.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Scheme *</label>
              <select
                value={schemeYear}
                onChange={(e) => setSchemeYear(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
              >
                {availableSchemes.map((s) => (
                  <option key={s} value={s}>
                    {s} Scheme
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Semester *</label>
              <select
                value={semester}
                onChange={(e) => setSemester(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                  <option key={sem} value={sem}>
                    Sem {sem}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Course Type Category *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as SubjectCategory)}
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
            >
              <option value="THEORY">THEORY - Core Theory Course</option>
              <option value="LAB">LAB - Laboratory Practical</option>
              <option value="INTEGRATED">INTEGRATED - Integrated Theory + Lab</option>
              <option value="ELECTIVE">ELECTIVE - Professional / Open Elective</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-foreground mb-1">Syllabus Overview / Scope</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              placeholder="Brief description of modules and outcomes..."
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
            <Button variant="outline" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {initialSubject ? 'Update Subject' : 'Save Subject'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
