import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Archive,
  RotateCcw,
  Power,
  Layers,
  GraduationCap,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../../shared/components/ui/ConfirmationModal';
import { useAcademicStore } from '../../../store/useAcademicStore';
import { AcademicSemester } from '../../../shared/types/academic.types';

export const SemesterManagementTab: React.FC = () => {
  const {
    semesters,
    addSemester,
    updateSemester,
    toggleSemesterStatus,
    archiveSemester,
    restoreSemester,
    reorderSemesters,
    subjects,
  } = useAcademicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSem, setEditingSem] = useState<AcademicSemester | null>(null);
  const [semNumber, setSemNumber] = useState<number>(1);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Confirmation modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const filteredSemesters = semesters.filter((s) => {
    const matchesSearch =
      s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      `sem ${s.semesterNumber}`.includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || s.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenCreate = () => {
    setEditingSem(null);
    setSemNumber(semesters.length + 1);
    setTitle(`Semester ${semesters.length + 1}`);
    setDescription('');
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (s: AcademicSemester) => {
    setEditingSem(s);
    setSemNumber(s.semesterNumber);
    setTitle(s.title);
    setDescription(s.description || '');
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || semNumber < 1 || semNumber > 10) {
      setErrorMsg('Valid Semester Number (1-10) and Title are required.');
      return;
    }

    if (editingSem) {
      const res = updateSemester(editingSem.id, {
        semesterNumber: Number(semNumber),
        title: title.trim(),
        description: description.trim() || undefined,
      });
      if (res && !res.success) {
        setErrorMsg(res.error || 'Failed to update semester.');
        return;
      }
      setIsFormOpen(false);
    } else {
      const res = addSemester({
        semesterNumber: Number(semNumber),
        title: title.trim(),
        description: description.trim() || undefined,
        status: 'ACTIVE',
        order: semesters.length + 1,
      });
      if (!res.success) {
        setErrorMsg(res.error || 'Duplicate semester number.');
      } else {
        setIsFormOpen(false);
      }
    }
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= semesters.length) return;
    const reordered = [...semesters];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;
    reorderSemesters(reordered);
  };

  const requestArchive = (s: AcademicSemester) => {
    const activeSubjects = subjects.filter((subj) => subj.semester === s.semesterNumber);
    setConfirmModal({
      isOpen: true,
      title: `Archive Semester ${s.semesterNumber}?`,
      message: `Archiving Semester ${s.semesterNumber} will hide ${activeSubjects.length} subjects associated with this semester from default student navigation forms.`,
      action: () => archiveSemester(s.id),
    });
  };

  return (
    <div className="space-y-4">
      {/* Action & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl border border-border bg-card">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search semester..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Semesters ({semesters.length})</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
            <option value="ARCHIVED">Archived Only</option>
          </select>
        </div>

        <Button variant="primary" size="sm" onClick={handleOpenCreate} icon={<Plus className="h-4 w-4" />}>
          Add Semester Node
        </Button>
      </div>

      {/* Semesters Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredSemesters.map((s, idx) => {
          const semesterSubjectsCount = subjects.filter((subj) => subj.semester === s.semesterNumber).length;

          return (
            <div
              key={s.id}
              className="p-5 rounded-2xl border border-border bg-card shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4 relative"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-lg bg-primary/10 text-primary font-black text-xs">
                    Sem {s.semesterNumber}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleMove(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => handleMove(idx, 'down')}
                      disabled={idx === semesters.length - 1}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <h4 className="text-base font-black text-foreground">{s.title}</h4>
                <p className="text-xs text-muted-foreground">
                  {s.description || `Academic Semester ${s.semesterNumber} in VTU Engineering curriculum.`}
                </p>

                <div className="pt-2 flex items-center justify-between text-xs text-muted-foreground border-t border-border/40">
                  <span>Linked Subjects:</span>
                  <span className="font-extrabold text-foreground">{semesterSubjectsCount} Subjects</span>
                </div>
              </div>

              <div className="pt-3 border-t border-border/60 flex items-center justify-between gap-2">
                <Badge
                  variant={
                    s.status === 'ACTIVE'
                      ? 'success'
                      : s.status === 'INACTIVE'
                      ? 'warning'
                      : 'neutral'
                  }
                  className="text-[10px]"
                >
                  {s.status}
                </Badge>

                <div className="flex items-center gap-1">
                  <Button variant="outline" size="sm" onClick={() => handleOpenEdit(s)} icon={<Edit2 className="h-3.5 w-3.5" />}>
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleSemesterStatus(s.id)}
                    icon={<Power className="h-3.5 w-3.5" />}
                  >
                    {s.status === 'ACTIVE' ? 'Pause' : 'Activate'}
                  </Button>

                  {s.status === 'ARCHIVED' ? (
                    <Button variant="primary" size="sm" onClick={() => restoreSemester(s.id)} icon={<RotateCcw className="h-3.5 w-3.5" />}>
                      Restore
                    </Button>
                  ) : (
                    <Button variant="destructive" size="sm" onClick={() => requestArchive(s)} icon={<Archive className="h-3.5 w-3.5" />}>
                      Archive
                    </Button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-foreground">
              {editingSem ? 'Edit Semester' : 'Add Semester Node'}
            </h3>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-foreground mb-1">Semester Index (1 to 10) *</label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={semNumber}
                  onChange={(e) => setSemNumber(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Semester Title *</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. 5th Semester (Professional Core)"
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Description / Focus Area</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Core discipline courses, lab workshops and mini projects."
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
                <Button variant="outline" size="sm" type="button" onClick={() => setIsFormOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit">
                  Save Semester
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
