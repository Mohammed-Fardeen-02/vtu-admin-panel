import React, { useState } from 'react';
import { Plus, Search, Tag, CheckCircle2, XCircle, UserCheck, Calendar, Download, Upload } from 'lucide-react';
import { CourseType, StatusType } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface CourseTypesTabProps {
  courseTypes: CourseType[];
  onAddCourseType: (payload: Partial<CourseType>) => Promise<any>;
  onEditCourseType: (id: string, payload: Partial<CourseType>) => Promise<any>;
  onDeactivateCourseType: (id: string) => Promise<any>;
  onBulkImportCourseType?: (dtos: any[]) => Promise<any>;
}

export const CourseTypesTab: React.FC<CourseTypesTabProps> = ({
  courseTypes,
  onAddCourseType,
  onEditCourseType,
  onDeactivateCourseType,
  onBulkImportCourseType,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [defaultCredits, setDefaultCredits] = useState<number>(3.0);
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirm Modal
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const categoryList = Array.isArray(courseTypes) ? courseTypes : [];
  const filteredCourseTypes = categoryList.filter(
    (ct) =>
      ct.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ct.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_course_types_master',
      ['code', 'name', 'description', 'defaultCredits', 'status'],
      filteredCourseTypes.map((ct) => [ct.code, ct.name, ct.description || '', ct.defaultCredits, ct.status])
    );
  };

  const openCreateModal = () => {
    setEditingId(null);
    setCode('');
    setName('');
    setDescription('');
    setDefaultCredits(3.0);
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (ct: CourseType) => {
    setEditingId(ct.id);
    setCode(ct.code);
    setName(ct.name);
    setDescription(ct.description || '');
    setDefaultCredits(ct.defaultCredits);
    setStatus(ct.status);
    setIsFormModalOpen(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await onEditCourseType(editingId, { name, description, defaultCredits, status });
    } else {
      await onAddCourseType({ code, name, description, defaultCredits, status });
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (ct: CourseType) => {
    const nextStatus: StatusType = ct.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditCourseType(ct.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (ct: CourseType) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate Category "${ct.code}"?`,
      message: `Are you sure you want to deactivate ${ct.code} (${ct.name})? Existing course mappings will remain safe.`,
      actionId: ct.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search & Action Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="w-full sm:w-80">
          <Input
            placeholder="Search Category Code or Name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="h-4 w-4" />}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Add Course Category</span>
          </Button>
        </div>
      </div>

      {/* Course Types Table */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Category Code</TableHead>
            <TableHead>Category Name</TableHead>
            <TableHead>Default Credits</TableHead>
            <TableHead>Mapped Subjects</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Audit Meta</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredCourseTypes.map((ct) => (
            <TableRow key={ct.id}>
              <TableCell className="font-bold text-foreground">
                <div className="flex items-center gap-2">
                  <div className="h-7 px-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-black text-xs">
                    {ct.code}
                  </div>
                </div>
              </TableCell>
              <TableCell className="font-semibold text-foreground">
                {ct.name}
                {ct.description && <p className="text-[11px] text-muted-foreground font-normal line-clamp-1">{ct.description}</p>}
              </TableCell>
              <TableCell className="font-extrabold text-foreground">{ct.defaultCredits} Credits</TableCell>
              <TableCell>
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-accent text-[11px] font-bold text-foreground">
                  <Tag className="h-3 w-3 text-muted-foreground" />
                  {ct._count?.courses || 0} Subjects
                </span>
              </TableCell>
              <TableCell>
                {ct.status === 'ACTIVE' ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-black uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    <CheckCircle2 className="h-3 w-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20 text-[10px] font-black uppercase tracking-wider text-red-600 dark:text-red-400">
                    <XCircle className="h-3 w-3" /> INACTIVE
                  </span>
                )}
              </TableCell>
              <TableCell className="text-[11px] text-muted-foreground">
                <div className="flex flex-col">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> {new Date(ct.createdAt).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1 text-[10px] mt-0.5 text-foreground/70 font-semibold">
                    <UserCheck className="h-3 w-3 text-primary" /> {ct.createdBy || 'Admin'}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <ActionDropdown
                  status={ct.status}
                  onEdit={() => openEditModal(ct)}
                  onToggleStatus={() => handleToggleStatus(ct)}
                  onDelete={() => triggerDeactivateConfirm(ct)}
                />
              </TableCell>
            </TableRow>
          ))}

          {filteredCourseTypes.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="py-8 text-center text-muted-foreground">
                No course categories found. Click "+ Add Course Category" to define one.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit Category */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit Course Category' : 'Add Course Category'}
        subtitle="Manage subject category codes (e.g. IPC, PCC, PEC, OEC)"
        maxWidth="lg"
      >
        <form id="ct-form" onSubmit={handleFormSubmit} className="space-y-4 pt-2">
          <Input
            label="Category Code *"
            required
            disabled={!!editingId}
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="e.g. IPC, PCC, PEC, OEC"
          />

          <Input
            label="Category Title / Name *"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Integrated Professional Core"
          />

          <Input
            label="Default Course Credits *"
            type="number"
            step="0.5"
            required
            value={defaultCredits}
            onChange={(e) => setDefaultCredits(parseFloat(e.target.value) || 3.0)}
          />

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1.5">
              Description
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detailed category regulations..."
              className="w-full rounded-xl border border-input bg-card px-3.5 py-2 text-xs font-medium text-foreground transition-all duration-200 placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Create Category'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import Course Categories"
        entityName="CourseTypes"
        sampleHeaders={['code', 'name', 'description', 'defaultCredits', 'status']}
        sampleRows={[
          ['AEC', 'Ability Enhancement Course', 'Skill & Ability enhancement subjects', 2.0, 'ACTIVE'],
          ['SEC', 'Skill Enhancement Course', 'Practical & vocational skills', 3.0, 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportCourseType) {
            await onBulkImportCourseType(
              parsedRecords.map((r) => ({
                code: r.code,
                name: r.name,
                description: r.description,
                defaultCredits: r.defaultCredits ? Number(r.defaultCredits) : 3.0,
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateCourseType(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
