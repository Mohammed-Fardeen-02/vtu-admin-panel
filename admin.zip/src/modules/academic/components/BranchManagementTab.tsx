import React, { useState } from 'react';
import {
  Plus,
  Search,
  Edit2,
  Archive,
  RotateCcw,
  Power,
  ArrowUp,
  ArrowDown,
  Building2,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../../shared/components/ui/ConfirmationModal';
import { useAcademicStore } from '../../../store/useAcademicStore';
import { AcademicBranch } from '../../../shared/types/academic.types';

export const BranchManagementTab: React.FC = () => {
  const {
    branches,
    addBranch,
    updateBranch,
    toggleBranchStatus,
    archiveBranch,
    restoreBranch,
    reorderBranches,
  } = useAcademicStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingBranch, setEditingBranch] = useState<AcademicBranch | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Confirmation modal state
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const filteredBranches = branches.filter((b) => {
    const matchesSearch =
      b.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || b.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenCreate = () => {
    setEditingBranch(null);
    setCode('');
    setName('');
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (b: AcademicBranch) => {
    setEditingBranch(b);
    setCode(b.code);
    setName(b.name);
    setErrorMsg('');
    setIsFormOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) {
      setErrorMsg('Code and Name are required.');
      return;
    }

    if (editingBranch) {
      updateBranch(editingBranch.id, { code: code.trim().toUpperCase(), name: name.trim() });
      setIsFormOpen(false);
    } else {
      const res = addBranch({
        code: code.trim().toUpperCase(),
        name: name.trim(),
        status: 'ACTIVE',
        order: branches.length + 1,
      });
      if (!res.success) {
        setErrorMsg(res.error || 'Duplicate branch code.');
      } else {
        setIsFormOpen(false);
      }
    }
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= branches.length) return;
    const reordered = [...branches];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;
    reorderBranches(reordered);
  };

  const requestArchive = (b: AcademicBranch) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Branch '${b.code}'?`,
      message: `Archiving this branch will hide associated subjects from student selection forms. You can restore it later.`,
      action: () => archiveBranch(b.id),
    });
  };

  return (
    <div className="space-y-4">
      {/* Action & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl border border-border bg-card">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search branches (e.g. CSE)..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
          >
            <option value="ALL">All Statuses ({branches.length})</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
            <option value="ARCHIVED">Archived Only</option>
          </select>
        </div>

        <Button variant="primary" size="sm" onClick={handleOpenCreate} icon={<Plus className="h-4 w-4" />}>
          Add Engineering Branch
        </Button>
      </div>

      {/* Branch Table */}
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-table-header-bg text-table-header-text border-b border-table-header-border">
              <th className="p-3.5 font-extrabold w-12 text-center">Order</th>
              <th className="p-3.5 font-extrabold">Branch Code</th>
              <th className="p-3.5 font-extrabold">Full Discipline Name</th>
              <th className="p-3.5 font-extrabold text-center">Status</th>
              <th className="p-3.5 font-extrabold text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {filteredBranches.map((b, idx) => (
              <tr key={b.id} className="hover:bg-accent/40 transition-colors">
                <td className="p-3.5 text-center font-bold">
                  <div className="flex items-center justify-center gap-1">
                    <button
                      onClick={() => handleMove(idx, 'up')}
                      disabled={idx === 0}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowUp className="h-3 w-3" />
                    </button>
                    <span>{idx + 1}</span>
                    <button
                      onClick={() => handleMove(idx, 'down')}
                      disabled={idx === branches.length - 1}
                      className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                    >
                      <ArrowDown className="h-3 w-3" />
                    </button>
                  </div>
                </td>
                <td className="p-3.5 font-black text-primary text-sm">{b.code}</td>
                <td className="p-3.5 font-bold text-foreground">{b.name}</td>
                <td className="p-3.5 text-center">
                  <Badge
                    variant={
                      b.status === 'ACTIVE'
                        ? 'success'
                        : b.status === 'INACTIVE'
                        ? 'warning'
                        : 'neutral'
                    }
                    className="text-[10px]"
                  >
                    {b.status}
                  </Badge>
                </td>
                <td className="p-3.5 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenEdit(b)}
                      icon={<Edit2 className="h-3.5 w-3.5" />}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleBranchStatus(b.id)}
                      icon={<Power className="h-3.5 w-3.5" />}
                    >
                      {b.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
                    </Button>

                    {b.status === 'ARCHIVED' ? (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => restoreBranch(b.id)}
                        icon={<RotateCcw className="h-3.5 w-3.5" />}
                      >
                        Restore
                      </Button>
                    ) : (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => requestArchive(b)}
                        icon={<Archive className="h-3.5 w-3.5" />}
                      >
                        Archive
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Form */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-foreground">
              {editingBranch ? 'Edit Branch' : 'Add Engineering Branch'}
            </h3>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-foreground mb-1">Branch Abbreviation Code *</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="e.g. CSE"
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none uppercase font-bold"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Full Branch Title *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Computer Science & Engineering"
                  className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-border/60">
                <Button variant="outline" size="sm" type="button" onClick={() => setIsFormOpen(false)}>
                  Cancel
                </Button>
                <Button variant="primary" size="sm" type="submit">
                  Save Branch
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Destructive Action Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
