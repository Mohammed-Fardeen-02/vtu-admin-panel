import React, { useState } from 'react';
import { Plus, Search, Building, CheckCircle2, XCircle, UserCheck, Calendar, Download, Upload } from 'lucide-react';
import { Department, StatusType } from '../types/type';
import { ActionDropdown } from './ActionDropdown';
import { ConfirmModal } from './ConfirmModal';
import { BulkImportModal } from './BulkImportModal';
import { downloadCSV } from '../../../shared/utils/csvExport';
import { Input, Select, Modal, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Button } from '../../../shared/components/ui';

interface DepartmentsTabProps {
  departments: Department[];
  onAddDepartment: (payload: Partial<Department>) => Promise<any>;
  onEditDepartment: (id: string, payload: Partial<Department>) => Promise<any>;
  onDeactivateDepartment: (id: string) => Promise<any>;
  onBulkImportDepartment?: (dtos: any[]) => Promise<any>;
}

export const DepartmentsTab: React.FC<DepartmentsTabProps> = ({
  departments,
  onAddDepartment,
  onEditDepartment,
  onDeactivateDepartment,
  onBulkImportDepartment,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState<Department | null>(null);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isBulkImportOpen, setIsBulkImportOpen] = useState(false);

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<StatusType>('ACTIVE');

  // Confirm Modal State
  const [confirmModalState, setConfirmModalState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionId: string | null;
  }>({ isOpen: false, title: '', message: '', actionId: null });

  const deptList = Array.isArray(departments) ? departments : [];
  const filteredDepts = deptList.filter(
    (d) =>
      d.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExportCSV = () => {
    downloadCSV(
      'vtu_academic_departments',
      ['code', 'name', 'description', 'status'],
      filteredDepts.map((d) => [d.code, d.name, d.description || '', d.status])
    );
  };

  const openCreateModal = () => {
    setEditingId(null);
    setCode('');
    setName('');
    setDescription('');
    setStatus('ACTIVE');
    setIsFormModalOpen(true);
  };

  const openEditModal = (d: Department) => {
    setEditingId(d.id);
    setCode(d.code);
    setName(d.name);
    setDescription(d.description || '');
    setStatus(d.status);
    setIsFormModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await onEditDepartment(editingId, { code, name, description, status });
    } else {
      await onAddDepartment({ code, name, description, status });
    }
    setIsFormModalOpen(false);
  };

  const handleToggleStatus = (d: Department) => {
    const nextStatus: StatusType = d.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    onEditDepartment(d.id, { status: nextStatus });
  };

  const triggerDeactivateConfirm = (d: Department) => {
    setConfirmModalState({
      isOpen: true,
      title: `Deactivate Department "${d.code}"?`,
      message: `Are you sure you want to set ${d.code} (${d.name}) to INACTIVE? Mapped branches will remain intact.`,
      actionId: d.id,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search & Actions Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-card/50 p-4 rounded-2xl border border-border">
        <div className="w-full sm:w-80">
          <Input
            placeholder="Search Department Code or Name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            icon={<Search className="h-4 w-4" />}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export CSV</span>
          </Button>

          <Button variant="outline" size="sm" onClick={() => setIsBulkImportOpen(true)} className="gap-1.5">
            <Upload className="w-3.5 h-3.5 text-blue-500" />
            <span>Bulk Import</span>
          </Button>

          <Button variant="primary" size="sm" onClick={openCreateModal} className="gap-2">
            <Plus className="h-4 w-4" />
            <span>Add Department Master</span>
          </Button>
        </div>
      </div>

      {/* Table Component */}
      <Table>
        <TableHeader>
          <tr>
            <TableHead>Dept Code</TableHead>
            <TableHead>Department Name</TableHead>
            <TableHead>Mapped Branches</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Audit Meta</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </tr>
        </TableHeader>
        <TableBody>
          {filteredDepts.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                No academic departments found. Click "Add Department Master" to create one.
              </TableCell>
            </TableRow>
          ) : (
            filteredDepts.map((d) => (
              <TableRow key={d.id}>
                <TableCell className="font-bold text-primary">
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-primary/70 shrink-0" />
                    <span>{d.code}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="font-semibold text-foreground">{d.name}</div>
                  {d.description && <div className="text-[11px] text-muted-foreground line-clamp-1">{d.description}</div>}
                </TableCell>
                <TableCell className="font-semibold text-foreground">
                  <span className="px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-500 text-[11px]">
                    {d._count?.branches ?? 0} Branches Mapped
                  </span>
                </TableCell>
                <TableCell>
                  <span
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      d.status === 'ACTIVE'
                        ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                        : 'bg-red-500/10 text-red-500 border border-red-500/20'
                    }`}
                  >
                    {d.status === 'ACTIVE' ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                    {d.status}
                  </span>
                </TableCell>
                <TableCell className="text-[11px] text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <UserCheck className="h-3 w-3 text-primary" />
                    <span>By: {d.createdBy || 'SYSTEM'}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <Calendar className="h-3 w-3" />
                    <span>{new Date(d.updatedAt).toLocaleDateString()}</span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <ActionDropdown
                    status={d.status}
                    onView={() => {
                      setSelectedDept(d);
                      setIsViewModalOpen(true);
                    }}
                    onEdit={() => openEditModal(d)}
                    onToggleStatus={() => handleToggleStatus(d)}
                    onDelete={() => triggerDeactivateConfirm(d)}
                  />
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {/* Centered Form Modal for Add/Edit Department */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={editingId ? 'Edit Department Master' : 'Add Department Master'}
        subtitle="Manage master department datasets for VTU academic hierarchy"
        maxWidth="lg"
      >
        <form id="dept-form" onSubmit={handleSubmit} className="space-y-4 pt-2">
          <Input
            label="Department Code *"
            required
            placeholder="e.g. CSE, ECE, ME, CV"
            value={code}
            disabled={!!editingId}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
          />

          <Input
            label="Department Name *"
            required
            placeholder="e.g. Department of Computer Science & Engineering"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1.5">
              Description
            </label>
            <textarea
              rows={3}
              placeholder="Brief description of department offerings..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-xl border border-input bg-card px-3.5 py-2 text-xs font-medium text-foreground transition-all duration-200 placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>

          <Select
            label="Status Provisioning *"
            value={status}
            onChange={(e) => setStatus(e.target.value as StatusType)}
            options={[
              { label: 'ACTIVE (Enabled)', value: 'ACTIVE' },
              { label: 'INACTIVE (Disabled)', value: 'INACTIVE' },
            ]}
          />

          <div className="pt-4 border-t border-border flex items-center justify-end gap-3">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsFormModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {editingId ? 'Save Changes' : 'Create Department'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Centered View Department Overview Modal */}
      {selectedDept && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Department: ${selectedDept.code}`}
          subtitle={selectedDept.name}
          maxWidth="md"
        >
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-3 border-b border-border pb-4">
              <div className="p-3 bg-primary/10 text-primary rounded-xl">
                <Building className="h-6 w-6" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-foreground">{selectedDept.code}</h4>
                <p className="text-xs text-muted-foreground">{selectedDept.name}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-muted/40 p-4 rounded-xl border border-border/60">
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Mapped Branches</span>
                <span className="font-extrabold text-foreground text-sm">{selectedDept._count?.branches ?? 0} Branches</span>
              </div>
              <div>
                <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider">Status</span>
                <span className={`font-bold text-xs ${selectedDept.status === 'ACTIVE' ? 'text-emerald-500' : 'text-red-500'}`}>
                  {selectedDept.status}
                </span>
              </div>
            </div>

            <div>
              <span className="text-muted-foreground block text-[10px] uppercase font-bold tracking-wider mb-1">Description</span>
              <p className="text-foreground leading-relaxed bg-background p-3 rounded-xl border border-border text-xs">
                {selectedDept.description || 'No detailed description recorded.'}
              </p>
            </div>

            <div className="pt-2 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
              <span>Created: {new Date(selectedDept.createdAt).toLocaleString()}</span>
              <span>Updated: {new Date(selectedDept.updatedAt).toLocaleString()}</span>
            </div>
          </div>
        </Modal>
      )}

      {/* Bulk Import Modal */}
      <BulkImportModal
        isOpen={isBulkImportOpen}
        onClose={() => setIsBulkImportOpen(false)}
        title="Bulk Import Academic Departments"
        entityName="Departments"
        sampleHeaders={['code', 'name', 'description', 'status']}
        sampleRows={[
          ['CSE', 'Department of Computer Science & Engineering', 'Core CS & AI/ML Streams', 'ACTIVE'],
          ['ECE', 'Department of Electronics & Communication', 'VLSI & Communications', 'ACTIVE'],
        ]}
        onConfirmImport={async (parsedRecords) => {
          if (onBulkImportDepartment) {
            await onBulkImportDepartment(
              parsedRecords.map((r) => ({
                code: r.code,
                name: r.name,
                description: r.description,
                status: r.status || 'ACTIVE',
              }))
            );
          }
        }}
      />

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModalState.isOpen}
        title={confirmModalState.title}
        message={confirmModalState.message}
        onConfirm={() => {
          if (confirmModalState.actionId) {
            onDeactivateDepartment(confirmModalState.actionId);
          }
          setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null });
        }}
        onCancel={() => setConfirmModalState({ isOpen: false, title: '', message: '', actionId: null })}
      />
    </div>
  );
};
