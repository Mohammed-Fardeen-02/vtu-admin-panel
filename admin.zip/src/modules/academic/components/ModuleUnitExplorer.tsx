import React, { useState } from 'react';
import {
  ArrowLeft,
  Plus,
  Edit2,
  Archive,
  RotateCcw,
  Power,
  ChevronDown,
  ChevronRight,
  Layers,
  FileCode,
  Clock,
  BookOpen,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../../shared/components/ui/ConfirmationModal';
import { ModuleFormModal } from './ModuleFormModal';
import { UnitFormModal } from './UnitFormModal';
import { useAcademicStore } from '../../../store/useAcademicStore';
import {
  AcademicSubject,
  AcademicModule,
  AcademicUnit,
} from '../../../shared/types/academic.types';

export interface ModuleUnitExplorerProps {
  subject: AcademicSubject;
  onBack: () => void;
}

export const ModuleUnitExplorer: React.FC<ModuleUnitExplorerProps> = ({
  subject,
  onBack,
}) => {
  const {
    getModulesForSubject,
    getUnitsForModule,
    addModule,
    updateModule,
    toggleModuleStatus,
    archiveModule,
    restoreModule,
    addUnit,
    updateUnit,
    toggleUnitStatus,
    archiveUnit,
    restoreUnit,
  } = useAcademicStore();

  const modules = getModulesForSubject(subject.id);

  // Expanded accordion modules
  const [expandedModules, setExpandedModules] = useState<Set<string>>(
    new Set(modules.map((m) => m.id))
  );

  // Module Modal
  const [isModuleModalOpen, setIsModuleModalOpen] = useState(false);
  const [editingModule, setEditingModule] = useState<AcademicModule | null>(null);

  // Unit Modal
  const [isUnitModalOpen, setIsUnitModalOpen] = useState(false);
  const [targetModuleIdForUnit, setTargetModuleIdForUnit] = useState<string>('');
  const [editingUnit, setEditingUnit] = useState<AcademicUnit | null>(null);

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const toggleAccordion = (id: string) => {
    const next = new Set(expandedModules);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedModules(next);
  };

  const handleOpenAddModule = () => {
    setEditingModule(null);
    setIsModuleModalOpen(true);
  };

  const handleOpenEditModule = (m: AcademicModule) => {
    setEditingModule(m);
    setIsModuleModalOpen(true);
  };

  const handleSaveModule = (payload: Omit<AcademicModule, 'id'> | AcademicModule) => {
    if ('id' in payload) {
      updateModule(payload.id, payload);
      return { success: true };
    } else {
      return addModule(payload);
    }
  };

  const handleOpenAddUnit = (moduleId: string) => {
    setTargetModuleIdForUnit(moduleId);
    setEditingUnit(null);
    setIsUnitModalOpen(true);
  };

  const handleOpenEditUnit = (u: AcademicUnit) => {
    setTargetModuleIdForUnit(u.moduleId);
    setEditingUnit(u);
    setIsUnitModalOpen(true);
  };

  const handleSaveUnit = (payload: Omit<AcademicUnit, 'id'> | AcademicUnit) => {
    if ('id' in payload) {
      updateUnit(payload.id, payload);
      return { success: true };
    } else {
      return addUnit(payload);
    }
  };

  const requestArchiveModule = (m: AcademicModule) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Module ${m.moduleNumber}?`,
      message: `Archiving '${m.title}' will hide its nested units from students. You can restore it anytime.`,
      action: () => archiveModule(m.id),
    });
  };

  const requestArchiveUnit = (u: AcademicUnit) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Unit?`,
      message: `Archiving unit '${u.title}' will hide this subtopic section from note readers.`,
      action: () => archiveUnit(u.id),
    });
  };

  return (
    <div className="space-y-6">
      {/* Subject Header Card */}
      <div className="p-6 rounded-2xl border border-primary/30 bg-gradient-to-r from-blue-950 via-primary to-indigo-900 text-white shadow-lg space-y-3">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-bold text-blue-200 transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to Subject List</span>
        </button>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-xs font-black bg-white/20 text-white">
                {subject.code}
              </span>
              <span className="text-xs font-bold text-blue-200">
                {subject.branchCode} • Sem {subject.semester} • {subject.schemeYear} Scheme
              </span>
            </div>
            <h2 className="text-2xl font-black tracking-tight text-white">{subject.name}</h2>
            <p className="text-xs text-blue-100/80 max-w-2xl">{subject.description}</p>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="text-right">
              <span className="text-2xl font-black">{subject.credits}</span>
              <p className="text-[10px] font-bold text-blue-200 uppercase">Credits</p>
            </div>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleOpenAddModule}
              icon={<Plus className="h-4 w-4" />}
            >
              Add Module
            </Button>
          </div>
        </div>
      </div>

      {/* Modules List Tree */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-extrabold text-foreground uppercase tracking-wider flex items-center gap-2">
            <Layers className="h-4 w-4 text-primary" />
            <span>Modules & Topic Breakdown ({modules.length} Modules)</span>
          </h3>
        </div>

        {modules.length === 0 ? (
          <div className="p-12 text-center border-2 border-dashed border-border rounded-2xl bg-card">
            <Layers className="h-10 w-10 text-primary mx-auto mb-2 opacity-50" />
            <h4 className="text-sm font-extrabold text-foreground">No Modules Created Yet</h4>
            <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
              Start building the syllabus hierarchy for {subject.code} by adding Module 1 to 5.
            </p>
            <Button
              variant="primary"
              size="sm"
              className="mt-4"
              onClick={handleOpenAddModule}
              icon={<Plus className="h-4 w-4" />}
            >
              Add Module 1
            </Button>
          </div>
        ) : (
          modules.map((m) => {
            const isExpanded = expandedModules.has(m.id);
            const units = getUnitsForModule(m.id);

            return (
              <div
                key={m.id}
                className="rounded-2xl border border-border bg-card shadow-sm overflow-hidden"
              >
                {/* Module Bar */}
                <div
                  onClick={() => toggleAccordion(m.id)}
                  className="p-4 bg-accent/30 hover:bg-accent/60 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button className="text-muted-foreground hover:text-foreground">
                      {isExpanded ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </button>
                    <div className="p-2 rounded-lg bg-primary/10 text-primary font-black text-xs">
                      M{m.moduleNumber}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-extrabold text-foreground truncate">
                          {m.title}
                        </h4>
                        <Badge
                          variant={
                            m.status === 'ACTIVE'
                              ? 'success'
                              : m.status === 'INACTIVE'
                              ? 'warning'
                              : 'neutral'
                          }
                          className="text-[9px]"
                        >
                          {m.status}
                        </Badge>
                      </div>
                      <p className="text-[11px] text-muted-foreground flex items-center gap-2 mt-0.5">
                        <span className="flex items-center gap-1 font-semibold">
                          <Clock className="h-3 w-3" /> {m.teachingHours} Hours
                        </span>
                        <span>•</span>
                        <span>{units.length} Topic Units</span>
                      </p>
                    </div>
                  </div>

                  <div
                    className="flex items-center gap-2 flex-shrink-0"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenAddUnit(m.id)}
                      icon={<Plus className="h-3.5 w-3.5" />}
                    >
                      Add Unit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenEditModule(m)}
                      icon={<Edit2 className="h-3.5 w-3.5" />}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleModuleStatus(m.id)}
                      icon={<Power className="h-3.5 w-3.5" />}
                    >
                      {m.status === 'ACTIVE' ? 'Pause' : 'Activate'}
                    </Button>

                    {m.status === 'ARCHIVED' ? (
                      <Button
                        variant="primary"
                        size="sm"
                        onClick={() => restoreModule(m.id)}
                        icon={<RotateCcw className="h-3.5 w-3.5" />}
                      >
                        Restore
                      </Button>
                    ) : (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => requestArchiveModule(m)}
                        icon={<Archive className="h-3.5 w-3.5" />}
                      >
                        Archive
                      </Button>
                    )}
                  </div>
                </div>

                {/* Expanded Units List */}
                {isExpanded && (
                  <div className="p-4 border-t border-border bg-card space-y-3">
                    <p className="text-xs text-muted-foreground italic px-2">
                      {m.description}
                    </p>

                    {units.length === 0 ? (
                      <div className="p-4 text-center border border-dashed border-border rounded-xl">
                        <p className="text-xs text-muted-foreground font-semibold">
                          No subtopic units added to Module {m.moduleNumber} yet.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2 pl-4 border-l-2 border-primary/20">
                        {units.map((u) => (
                          <div
                            key={u.id}
                            className="p-3 rounded-xl border border-border/80 bg-accent/10 hover:bg-accent/30 transition-colors flex items-center justify-between gap-3 text-xs"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <FileCode className="h-4 w-4 text-primary flex-shrink-0" />
                              <div className="min-w-0">
                                <span className="font-extrabold text-foreground truncate block">
                                  {u.title}
                                </span>
                                <span className="text-[10px] text-muted-foreground">
                                  {u.topicsCount} detailed sub-topics
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 flex-shrink-0">
                              <Badge
                                variant={u.status === 'ACTIVE' ? 'success' : 'neutral'}
                                className="text-[9px]"
                              >
                                {u.status}
                              </Badge>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleOpenEditUnit(u)}
                                icon={<Edit2 className="h-3 w-3" />}
                              >
                                Edit
                              </Button>
                              {u.status === 'ARCHIVED' ? (
                                <Button
                                  variant="primary"
                                  size="sm"
                                  onClick={() => restoreUnit(u.id)}
                                  icon={<RotateCcw className="h-3 w-3" />}
                                >
                                  Restore
                                </Button>
                              ) : (
                                <Button
                                  variant="destructive"
                                  size="sm"
                                  onClick={() => requestArchiveUnit(u)}
                                  icon={<Archive className="h-3 w-3" />}
                                >
                                  Archive
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Module Modal */}
      <ModuleFormModal
        isOpen={isModuleModalOpen}
        onClose={() => setIsModuleModalOpen(false)}
        onSave={handleSaveModule}
        subjectId={subject.id}
        initialModule={editingModule}
        existingModulesCount={modules.length}
      />

      {/* Unit Modal */}
      <UnitFormModal
        isOpen={isUnitModalOpen}
        onClose={() => setIsUnitModalOpen(false)}
        onSave={handleSaveUnit}
        moduleId={targetModuleIdForUnit}
        initialUnit={editingUnit}
        existingUnitsCount={getUnitsForModule(targetModuleIdForUnit).length}
      />

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
