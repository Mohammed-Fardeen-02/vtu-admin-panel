import React, { useState, useMemo } from 'react';
import {
  HelpCircle,
  Search,
  Filter,
  Plus,
  Edit2,
  Upload,
  Eye,
  Download,
  CheckCircle2,
  XCircle,
  Archive,
  Trash2,
  ArrowUp,
  ArrowDown,
  RefreshCcw,
  CheckSquare,
  Square,
  FileCheck,
  BookOpen,
  Layers,
  Sparkles,
} from 'lucide-react';
import { Card, CardContent } from '../../shared/components/ui/Card';
import { Button } from '../../shared/components/ui/Button';
import { Badge } from '../../shared/components/ui/Badge';
import { ConfirmationModal } from '../../shared/components/ui/ConfirmationModal';
import { PageHeader } from '../../shared/components/ui/PageHeader';

import { PaperFormModal } from './components/PaperFormModal';
import { ReplacePaperFileModal } from './components/ReplacePaperFileModal';
import { PaperPreviewModal } from './components/PaperPreviewModal';
import { BulkReassignPaperModal } from './components/BulkReassignPaperModal';

import { usePaperStore } from '../../store/usePaperStore';
import { useAcademicStore } from '../../store/useAcademicStore';
import { AdminQuestionPaper, PaperType, ExamCategory, PaperStatus } from '../../shared/types/papers.types';

export const QuestionPapersPage: React.FC = () => {
  const {
    papers,
    addPaper,
    updatePaper,
    replacePaperFile,
    publishPaper,
    unpublishPaper,
    archivePaper,
    deletePaper,
    reorderPapers,
    bulkPublishPapers,
    bulkUnpublishPapers,
    bulkArchivePapers,
    bulkDeletePapers,
    bulkReassignSubject,
  } = usePaperStore();

  const { branches, schemes, semesters, subjects } = useAcademicStore();

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [branchFilter, setBranchFilter] = useState('ALL');
  const [schemeFilter, setSchemeFilter] = useState('ALL');
  const [semFilter, setSemFilter] = useState<number | 'ALL'>('ALL');
  const [subjectFilter, setSubjectFilter] = useState('ALL');
  const [paperTypeFilter, setPaperTypeFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Selection state for Bulk operations
  const [selectedPaperIds, setSelectedPaperIds] = useState<Set<string>>(new Set());

  // Modal States
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingPaper, setEditingPaper] = useState<AdminQuestionPaper | null>(null);

  const [isReplaceFileModalOpen, setIsReplaceFileModalOpen] = useState(false);
  const [paperForReplaceFile, setPaperForReplaceFile] = useState<AdminQuestionPaper | null>(null);

  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [previewPaper, setPreviewPaper] = useState<AdminQuestionPaper | null>(null);

  const [isBulkReassignOpen, setIsBulkReassignOpen] = useState(false);

  // Destructive Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  // Filtered Papers calculation
  const filteredPapers = useMemo(() => {
    return papers.filter((p) => {
      let matchesSearch = true;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        matchesSearch =
          p.title.toLowerCase().includes(q) ||
          p.subjectCode.toLowerCase().includes(q) ||
          p.subjectName.toLowerCase().includes(q) ||
          p.year.toString().includes(q) ||
          p.uploadedBy.toLowerCase().includes(q);
      }

      const matchesBranch = branchFilter === 'ALL' || p.branchCode === branchFilter;
      const matchesScheme = schemeFilter === 'ALL' || p.schemeYear === schemeFilter;
      const matchesSem = semFilter === 'ALL' || p.semester === semFilter;
      const matchesSubject = subjectFilter === 'ALL' || p.subjectId === subjectFilter;
      const matchesPaperType = paperTypeFilter === 'ALL' || p.paperType === paperTypeFilter;
      const matchesCategory = categoryFilter === 'ALL' || p.examCategory === categoryFilter;
      const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;

      return (
        matchesSearch &&
        matchesBranch &&
        matchesScheme &&
        matchesSem &&
        matchesSubject &&
        matchesPaperType &&
        matchesCategory &&
        matchesStatus
      );
    });
  }, [
    papers,
    searchQuery,
    branchFilter,
    schemeFilter,
    semFilter,
    subjectFilter,
    paperTypeFilter,
    categoryFilter,
    statusFilter,
  ]);

  // Aggregate Metrics
  const totalDownloads = useMemo(() => papers.reduce((acc, p) => acc + p.downloads, 0), [papers]);
  const regularCount = useMemo(() => papers.filter((p) => p.examCategory === 'REGULAR').length, [papers]);
  const makeupCount = useMemo(() => papers.filter((p) => p.examCategory === 'MAKEUP').length, [papers]);
  const modelCount = useMemo(() => papers.filter((p) => p.examCategory === 'MODEL').length, [papers]);

  // Select Handlers
  const handleToggleSelectAll = () => {
    if (selectedPaperIds.size === filteredPapers.length && filteredPapers.length > 0) {
      setSelectedPaperIds(new Set());
    } else {
      setSelectedPaperIds(new Set(filteredPapers.map((p) => p.id)));
    }
  };

  const handleToggleSelectPaper = (id: string) => {
    const next = new Set(selectedPaperIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedPaperIds(next);
  };

  // Reorder Handler
  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= papers.length) return;
    const reordered = [...papers];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;
    reorderPapers(reordered);
  };

  // Modals Open Actions
  const handleOpenCreatePaper = () => {
    setEditingPaper(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEditPaper = (p: AdminQuestionPaper) => {
    setEditingPaper(p);
    setIsFormModalOpen(true);
  };

  const handleOpenReplaceFile = (p: AdminQuestionPaper) => {
    setPaperForReplaceFile(p);
    setIsReplaceFileModalOpen(true);
  };

  const handleOpenPreview = (p: AdminQuestionPaper) => {
    setPreviewPaper(p);
    setIsPreviewModalOpen(true);
  };

  const requestDeletePaper = (p: AdminQuestionPaper) => {
    setConfirmModal({
      isOpen: true,
      title: `Permanently Delete Question Paper?`,
      message: `Are you sure you want to delete '${p.title}' (${p.subjectCode})? This action cannot be undone.`,
      action: () => deletePaper(p.id),
    });
  };

  const requestArchivePaper = (p: AdminQuestionPaper) => {
    setConfirmModal({
      isOpen: true,
      title: `Archive Question Paper '${p.subjectCode}'?`,
      message: `Archiving this paper will hide it from student paper search while retaining historical download statistics.`,
      action: () => archivePaper(p.id),
    });
  };

  const requestBulkDelete = () => {
    const count = selectedPaperIds.size;
    setConfirmModal({
      isOpen: true,
      title: `Bulk Delete ${count} Selected Question Papers?`,
      message: `This will permanently remove ${count} paper documents from the repository. Proceed with caution.`,
      action: () => {
        bulkDeletePapers(Array.from(selectedPaperIds));
        setSelectedPaperIds(new Set());
      },
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <PageHeader
          title="Previous Year Question Paper Management (ADMIN-FR-04)"
          description="Upload, metadata validation, solution key management, replace file, preview, publish, archive, and bulk paper reassignments."
        />
        <Button
          variant="primary"
          onClick={handleOpenCreatePaper}
          icon={<Plus className="h-4 w-4" />}
          className="flex-shrink-0"
        >
          Upload Question Paper PDF
        </Button>
      </div>

      {/* Telemetry Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <HelpCircle className="h-3.5 w-3.5 text-primary" /> Total Papers
          </span>
          <p className="text-2xl font-black text-foreground">{papers.length}</p>
          <span className="text-[10px] text-muted-foreground">SEE & IA papers</span>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <FileCheck className="h-3.5 w-3.5 text-emerald-500" /> Regular Exams
          </span>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{regularCount}</p>
          <span className="text-[10px] text-emerald-600/80">Main SEE papers</span>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <Sparkles className="h-3.5 w-3.5 text-amber-500" /> Makeup / Supp
          </span>
          <p className="text-2xl font-black text-amber-600 dark:text-amber-400">{makeupCount}</p>
          <span className="text-[10px] text-amber-600/80">Supplementary exams</span>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <Layers className="h-3.5 w-3.5 text-purple-500" /> Model Papers
          </span>
          <p className="text-2xl font-black text-purple-600 dark:text-purple-400">{modelCount}</p>
          <span className="text-[10px] text-purple-600/80">VTU Sample papers</span>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5 text-blue-500" /> With Solution Keys
          </span>
          <p className="text-2xl font-black text-foreground">
            {papers.filter((p) => p.hasSolutionKey).length}
          </p>
          <span className="text-[10px] text-muted-foreground">Answer keys attached</span>
        </div>

        <div className="p-4 rounded-2xl border border-border bg-card shadow-sm space-y-1">
          <span className="text-[11px] font-bold text-muted-foreground uppercase flex items-center gap-1.5">
            <Download className="h-3.5 w-3.5 text-rose-500" /> Total Downloads
          </span>
          <p className="text-2xl font-black text-foreground">{totalDownloads.toLocaleString()}</p>
          <span className="text-[10px] text-muted-foreground">Student downloads</span>
        </div>
      </div>

      {/* Controls & Filter Bar */}
      <div className="p-4 rounded-2xl border border-border bg-card space-y-3">
        <div className="flex flex-col xl:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full xl:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search title, subject, code, year..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none"
            />
          </div>

          {/* Academic Structure Multi-Filters */}
          <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
            {/* Branch */}
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Branches ({branches.length})</option>
              {branches.map((b) => (
                <option key={b.id} value={b.code}>
                  {b.code}
                </option>
              ))}
            </select>

            {/* Scheme */}
            <select
              value={schemeFilter}
              onChange={(e) => setSchemeFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Schemes ({schemes.length})</option>
              {schemes.map((s) => (
                <option key={s.id} value={s.year}>
                  {s.year} Scheme
                </option>
              ))}
            </select>

            {/* Semester */}
            <select
              value={semFilter}
              onChange={(e) =>
                setSemFilter(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))
              }
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Semesters</option>
              {[1, 2, 3, 4, 5, 6, 7, 8].map((sem) => (
                <option key={sem} value={sem}>
                  Sem {sem}
                </option>
              ))}
            </select>

            {/* Paper Type */}
            <select
              value={paperTypeFilter}
              onChange={(e) => setPaperTypeFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Paper Types</option>
              <option value="SEE_THEORY">SEE Theory Paper</option>
              <option value="IA_1">Internal Test (IA-1)</option>
              <option value="IA_2">Internal Test (IA-2)</option>
              <option value="IA_3">Internal Test (IA-3)</option>
              <option value="LAB_EXAM">Lab Practical</option>
              <option value="SOLUTION_KEY">Solution Key Only</option>
            </select>

            {/* Category */}
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Sessions</option>
              <option value="REGULAR">Regular Main Exam</option>
              <option value="MAKEUP">Makeup Exam</option>
              <option value="MODEL">VTU Model Paper</option>
            </select>

            {/* Status */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
            >
              <option value="ALL">All Statuses</option>
              <option value="PUBLISHED">Published</option>
              <option value="UNPUBLISHED">Unpublished</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </div>
        </div>

        {/* Bulk Action Controls */}
        {selectedPaperIds.size > 0 && (
          <div className="p-3 rounded-xl bg-primary/10 border border-primary/30 flex flex-wrap items-center justify-between gap-3 animate-fadeIn text-xs">
            <span className="font-extrabold text-primary flex items-center gap-1.5">
              <CheckSquare className="h-4 w-4" />
              <span>{selectedPaperIds.size} Question Papers Selected</span>
            </span>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  bulkPublishPapers(Array.from(selectedPaperIds));
                  setSelectedPaperIds(new Set());
                }}
                icon={<CheckCircle2 className="h-3.5 w-3.5" />}
              >
                Bulk Publish
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  bulkUnpublishPapers(Array.from(selectedPaperIds));
                  setSelectedPaperIds(new Set());
                }}
                icon={<XCircle className="h-3.5 w-3.5" />}
              >
                Bulk Unpublish
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsBulkReassignOpen(true)}
                icon={<Layers className="h-3.5 w-3.5" />}
              >
                Bulk Reassign Subject
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  bulkArchivePapers(Array.from(selectedPaperIds));
                  setSelectedPaperIds(new Set());
                }}
                icon={<Archive className="h-3.5 w-3.5" />}
              >
                Bulk Archive
              </Button>

              <Button
                variant="destructive"
                size="sm"
                onClick={requestBulkDelete}
                icon={<Trash2 className="h-3.5 w-3.5" />}
              >
                Bulk Delete
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Main Data Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-table-header-bg text-table-header-text border-b border-table-header-border">
                  <th className="p-3.5 w-10 text-center">
                    <button
                      onClick={handleToggleSelectAll}
                      className="text-muted-foreground hover:text-foreground cursor-pointer"
                    >
                      {selectedPaperIds.size > 0 &&
                      selectedPaperIds.size === filteredPapers.length ? (
                        <CheckSquare className="h-4 w-4 text-primary" />
                      ) : (
                        <Square className="h-4 w-4" />
                      )}
                    </button>
                  </th>
                  <th className="p-3.5 font-extrabold w-12 text-center">Order</th>
                  <th className="p-3.5 font-extrabold">Paper Title & Subject</th>
                  <th className="p-3.5 font-extrabold">Academic Hierarchy</th>
                  <th className="p-3.5 font-extrabold">Exam Year & Type</th>
                  <th className="p-3.5 font-extrabold text-center">Solution Key</th>
                  <th className="p-3.5 font-extrabold text-center">Downloads</th>
                  <th className="p-3.5 font-extrabold text-center">Status</th>
                  <th className="p-3.5 font-extrabold text-right">Actions</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-border/60">
                {filteredPapers.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-12 text-center text-muted-foreground">
                      <HelpCircle className="h-10 w-10 text-primary mx-auto mb-2 opacity-50" />
                      <p className="font-bold">No Question Papers Found</p>
                      <p className="text-[11px] mt-0.5">Try adjusting your filters or upload a new paper.</p>
                    </td>
                  </tr>
                ) : (
                  filteredPapers.map((paper, idx) => {
                    const isSelected = selectedPaperIds.has(paper.id);

                    return (
                      <tr
                        key={paper.id}
                        className={`hover:bg-accent/40 transition-colors ${
                          isSelected ? 'bg-primary/5' : ''
                        }`}
                      >
                        {/* Checkbox */}
                        <td className="p-3.5 text-center">
                          <button
                            onClick={() => handleToggleSelectPaper(paper.id)}
                            className="text-muted-foreground hover:text-foreground cursor-pointer"
                          >
                            {isSelected ? (
                              <CheckSquare className="h-4 w-4 text-primary" />
                            ) : (
                              <Square className="h-4 w-4" />
                            )}
                          </button>
                        </td>

                        {/* Order Priority */}
                        <td className="p-3.5 text-center font-bold">
                          <div className="flex items-center justify-center gap-0.5">
                            <button
                              onClick={() => handleMove(idx, 'up')}
                              disabled={idx === 0}
                              className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowUp className="h-3 w-3" />
                            </button>
                            <span className="text-[11px]">{idx + 1}</span>
                            <button
                              onClick={() => handleMove(idx, 'down')}
                              disabled={idx === papers.length - 1}
                              className="p-1 text-muted-foreground hover:text-foreground disabled:opacity-30 cursor-pointer"
                            >
                              <ArrowDown className="h-3 w-3" />
                            </button>
                          </div>
                        </td>

                        {/* Title & Subject */}
                        <td className="p-3.5 max-w-sm space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-black text-primary text-xs">{paper.subjectCode}</span>
                            <span className="font-bold text-foreground text-xs">{paper.subjectName}</span>
                          </div>
                          <p className="font-black text-foreground text-xs leading-snug line-clamp-2">
                            {paper.title}
                          </p>
                        </td>

                        {/* Academic Hierarchy */}
                        <td className="p-3.5 space-y-1 text-xs">
                          <Badge variant="primary" className="text-[10px]">
                            {paper.branchCode} • Sem {paper.semester}
                          </Badge>
                          <p className="text-[11px] text-muted-foreground font-semibold">
                            {paper.schemeYear} Scheme
                          </p>
                        </td>

                        {/* Exam Year & Type */}
                        <td className="p-3.5 space-y-1">
                          <div className="flex items-center gap-1.5">
                            <Badge variant="neutral" className="text-[10px]">
                              {paper.year} Exam
                            </Badge>
                            <Badge
                              variant={paper.examCategory === 'REGULAR' ? 'success' : 'warning'}
                              className="text-[9px]"
                            >
                              {paper.examCategory}
                            </Badge>
                          </div>
                          <p className="text-[11px] text-muted-foreground font-bold">
                            {paper.paperType.replace('_', ' ')} • {paper.fileSize}
                          </p>
                        </td>

                        {/* Solution Key */}
                        <td className="p-3.5 text-center">
                          {paper.hasSolutionKey ? (
                            <Badge variant="success" icon={<CheckCircle2 className="h-3 w-3" />} className="text-[9px]">
                              Solution Key Included
                            </Badge>
                          ) : (
                            <Badge variant="warning" className="text-[9px]">
                              Paper Only
                            </Badge>
                          )}
                        </td>

                        {/* Downloads */}
                        <td className="p-3.5 text-center font-extrabold text-blue-600 dark:text-blue-400">
                          <div className="flex items-center justify-center gap-1">
                            <Download className="h-3.5 w-3.5" />
                            <span>{paper.downloads.toLocaleString()}</span>
                          </div>
                        </td>

                        {/* Status */}
                        <td className="p-3.5 text-center">
                          <Badge
                            variant={
                              paper.status === 'PUBLISHED'
                                ? 'success'
                                : paper.status === 'UNPUBLISHED'
                                ? 'warning'
                                : 'neutral'
                            }
                            className="text-[10px]"
                          >
                            {paper.status}
                          </Badge>
                        </td>

                        {/* Actions */}
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Preview */}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenPreview(paper)}
                              icon={<Eye className="h-3.5 w-3.5 text-purple-500" />}
                            >
                              Preview
                            </Button>

                            {/* Edit */}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenEditPaper(paper)}
                              icon={<Edit2 className="h-3.5 w-3.5" />}
                            >
                              Edit
                            </Button>

                            {/* Replace File */}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleOpenReplaceFile(paper)}
                              icon={<Upload className="h-3.5 w-3.5 text-blue-500" />}
                            >
                              Replace PDF
                            </Button>

                            {/* Publish / Unpublish */}
                            {paper.status === 'PUBLISHED' ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => unpublishPaper(paper.id)}
                                icon={<XCircle className="h-3.5 w-3.5 text-amber-500" />}
                              >
                                Pause
                              </Button>
                            ) : (
                              <Button
                                variant="primary"
                                size="sm"
                                onClick={() => publishPaper(paper.id)}
                                icon={<CheckCircle2 className="h-3.5 w-3.5" />}
                              >
                                Publish
                              </Button>
                            )}

                            {/* Archive */}
                            {paper.status === 'ARCHIVED' ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => publishPaper(paper.id)}
                                icon={<RefreshCcw className="h-3.5 w-3.5" />}
                              >
                                Restore
                              </Button>
                            ) : (
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => requestArchivePaper(paper)}
                                icon={<Archive className="h-3.5 w-3.5" />}
                              >
                                Archive
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <PaperFormModal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        onSave={(data) => {
          if (editingPaper) {
            return updatePaper(editingPaper.id, data);
          } else {
            return addPaper(data);
          }
        }}
        initialPaper={editingPaper}
      />

      {paperForReplaceFile && (
        <ReplacePaperFileModal
          isOpen={isReplaceFileModalOpen}
          onClose={() => {
            setIsReplaceFileModalOpen(false);
            setPaperForReplaceFile(null);
          }}
          paper={paperForReplaceFile}
          onReplaceFile={replacePaperFile}
        />
      )}

      {previewPaper && (
        <PaperPreviewModal
          isOpen={isPreviewModalOpen}
          onClose={() => {
            setIsPreviewModalOpen(false);
            setPreviewPaper(null);
          }}
          paper={previewPaper}
        />
      )}

      <BulkReassignPaperModal
        isOpen={isBulkReassignOpen}
        onClose={() => setIsBulkReassignOpen(false)}
        selectedCount={selectedPaperIds.size}
        onConfirmReassign={(targetSubjId, code, name, branch, scheme, sem) => {
          bulkReassignSubject(
            Array.from(selectedPaperIds),
            targetSubjId,
            code,
            name,
            branch,
            scheme,
            sem
          );
          setSelectedPaperIds(new Set());
        }}
      />

      <ConfirmationModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={() => {
          confirmModal.action();
          setConfirmModal((prev) => ({ ...prev, isOpen: false }));
        }}
        onCancel={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
