import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, BookOpen, AlertCircle, HelpCircle, CheckCircle2, Folder } from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { useAcademicStore } from '../../../store/useAcademicStore';
import { AdminQuestionPaper, PaperType, ExamCategory, PaperStatus } from '../../../shared/types/papers.types';

export interface PaperFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: any) => { success: boolean; error?: string };
  initialPaper?: AdminQuestionPaper | null;
}

export const PaperFormModal: React.FC<PaperFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialPaper,
}) => {
  const { branches, schemes, semesters, subjects } = useAcademicStore();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [title, setTitle] = useState('');
  const [branchCode, setBranchCode] = useState('CSE');
  const [schemeYear, setSchemeYear] = useState('2022');
  const [semester, setSemester] = useState<number>(5);
  const [subjectId, setSubjectId] = useState('');
  const [year, setYear] = useState<number>(2025);
  const [paperType, setPaperType] = useState<PaperType>('SEE_THEORY');
  const [examCategory, setExamCategory] = useState<ExamCategory>('REGULAR');
  const [hasSolutionKey, setHasSolutionKey] = useState<boolean>(true);
  const [status, setStatus] = useState<PaperStatus>('PUBLISHED');
  const [uploadedBy, setUploadedBy] = useState('VTU Exam Cell');
  const [fileUrl, setFileUrl] = useState('s3://vtu-papers-prod/official_paper.pdf');
  const [fileSize, setFileSize] = useState('3.8 MB');
  const [fileSizeBytes, setFileSizeBytes] = useState<number>(3800000);
  const [pageCount, setPageCount] = useState<number>(6);
  const [selectedFileName, setSelectedFileName] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState('');

  // Available subjects for selected branch, scheme, semester
  const availableSubjects = subjects.filter(
    (s) =>
      s.branchCode === branchCode &&
      s.schemeYear === schemeYear &&
      s.semester === semester
  );

  useEffect(() => {
    if (initialPaper) {
      setTitle(initialPaper.title);
      setBranchCode(initialPaper.branchCode);
      setSchemeYear(initialPaper.schemeYear);
      setSemester(initialPaper.semester);
      setSubjectId(initialPaper.subjectId);
      setYear(initialPaper.year);
      setPaperType(initialPaper.paperType);
      setExamCategory(initialPaper.examCategory);
      setHasSolutionKey(initialPaper.hasSolutionKey);
      setStatus(initialPaper.status);
      setUploadedBy(initialPaper.uploadedBy);
      setFileUrl(initialPaper.fileUrl);
      setFileSize(initialPaper.fileSize);
      setFileSizeBytes(initialPaper.fileSizeBytes || 3800000);
      setPageCount(initialPaper.pageCount);
      setSelectedFileName(initialPaper.fileUrl.split('/').pop() || '');
    } else {
      setTitle('');
      setSelectedFileName('');
      if (availableSubjects.length > 0) {
        setSubjectId(availableSubjects[0].id);
      }
    }
  }, [initialPaper]);

  useEffect(() => {
    if (availableSubjects.length > 0 && !availableSubjects.some((s) => s.id === subjectId)) {
      setSubjectId(availableSubjects[0].id);
    }
  }, [branchCode, schemeYear, semester]);

  if (!isOpen) return null;

  const handleSystemFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFileName(file.name);
    const bytes = file.size;
    setFileSizeBytes(bytes);
    const formattedSize =
      bytes > 1024 * 1024
        ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
        : `${Math.round(bytes / 1024)} KB`;
    setFileSize(formattedSize);
    setFileUrl(`s3://vtu-papers-prod/uploads/${file.name}`);

    // Auto-fill title if empty
    if (!title.trim()) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      setTitle(cleanName);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Paper Title is required.');
      return;
    }
    const targetSubject = subjects.find((s) => s.id === subjectId);
    if (!targetSubject) {
      setErrorMsg('Please select a valid subject entity.');
      return;
    }

    const payload = {
      title: title.trim(),
      branchCode,
      schemeYear,
      semester,
      subjectId,
      subjectCode: targetSubject.code,
      subjectName: targetSubject.name,
      year: Number(year),
      paperType,
      examCategory,
      hasSolutionKey,
      status,
      uploadedBy: uploadedBy.trim(),
      fileUrl: fileUrl.trim(),
      fileSize: fileSize.trim(),
      fileSizeBytes,
      pageCount: Number(pageCount),
    };

    const res = onSave(payload);
    if (res && !res.success) {
      setErrorMsg(res.error || 'Failed to save question paper.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-border">
          <div>
            <h3 className="text-lg font-black text-foreground">
              {initialPaper ? 'Edit Question Paper Metadata' : 'Add Question Paper (ADMIN-FR-04)'}
            </h3>
            <p className="text-xs text-muted-foreground">
              Strictly validated against Central Academic Structure (Branch, Scheme, Semester, Subject).
            </p>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* File Upload System Button Section */}
          <div className="p-4 border-2 border-dashed border-primary/40 rounded-2xl bg-primary/5 text-center space-y-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleSystemFileSelect}
              accept=".pdf,.doc,.docx"
              className="hidden"
            />

            <Upload className="h-7 w-7 text-primary mx-auto" />
            <div>
              <h4 className="text-xs font-black text-foreground">Upload Question Paper File from System</h4>
              <p className="text-[11px] text-muted-foreground">
                Select high-resolution PDF paper scan or answer key document from your computer/device.
              </p>
            </div>

            <Button
              variant="primary"
              size="sm"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              icon={<Folder className="h-4 w-4" />}
            >
              Browse & Select Paper File from System
            </Button>

            {selectedFileName && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center justify-center gap-2 mt-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                <span className="truncate">Selected File: {selectedFileName} ({fileSize})</span>
              </div>
            )}
          </div>

          {/* Paper Title */}
          <div>
            <label className="block font-bold text-foreground mb-1">Paper Title *</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. DBMS (21CS53) SEE Theory Question Paper - Jan/Feb 2025"
              className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold text-sm"
              required
            />
          </div>

          {/* Academic Structure Hierarchy Selection */}
          <div className="p-4 rounded-xl border border-primary/20 bg-accent/20 space-y-3">
            <span className="font-black text-primary text-xs flex items-center gap-1.5">
              <BookOpen className="h-4 w-4" />
              <span>Academic Hierarchy Mapping Validation</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-bold text-foreground mb-1">Branch *</label>
                <select
                  value={branchCode}
                  onChange={(e) => setBranchCode(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-border bg-card text-foreground font-bold cursor-pointer"
                >
                  {branches.map((b) => (
                    <option key={b.id} value={b.code}>
                      {b.code} - {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Scheme *</label>
                <select
                  value={schemeYear}
                  onChange={(e) => setSchemeYear(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-border bg-card text-foreground font-bold cursor-pointer"
                >
                  {schemes.map((s) => (
                    <option key={s.id} value={s.year}>
                      {s.year} Scheme
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-foreground mb-1">Semester *</label>
                <select
                  value={semester}
                  onChange={(e) => setSemester(Number(e.target.value))}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-border bg-card text-foreground font-bold cursor-pointer"
                >
                  {semesters.map((sem) => (
                    <option key={sem.id} value={sem.semesterNumber}>
                      Sem {sem.semesterNumber}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Subject Entity *</label>
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full px-2.5 py-2 rounded-lg border border-border bg-card text-foreground font-bold cursor-pointer"
                required
              >
                {availableSubjects.length === 0 ? (
                  <option value="">No subjects registered for this branch/scheme/sem</option>
                ) : (
                  availableSubjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} - {s.name}
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          {/* Exam Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-foreground mb-1">Exam Year *</label>
              <input
                type="number"
                min={2015}
                max={2030}
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground font-bold focus:ring-2 focus:ring-primary/40 outline-none"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Paper Type *</label>
              <select
                value={paperType}
                onChange={(e) => setPaperType(e.target.value as PaperType)}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
              >
                <option value="SEE_THEORY">SEE Theory Paper</option>
                <option value="IA_1">First Internal (IA-1)</option>
                <option value="IA_2">Second Internal (IA-2)</option>
                <option value="IA_3">Third Internal (IA-3)</option>
                <option value="LAB_EXAM">Lab / Practical Exam</option>
                <option value="SOLUTION_KEY">Solution Answer Key Only</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Exam Session Category *</label>
              <select
                value={examCategory}
                onChange={(e) => setExamCategory(e.target.value as ExamCategory)}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
              >
                <option value="REGULAR">Regular Main Exam</option>
                <option value="MAKEUP">Makeup / Supplementary</option>
                <option value="MODEL">VTU Model Sample Paper</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div>
              <label className="block font-bold text-foreground mb-1">Publishing Status *</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as PaperStatus)}
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground font-bold cursor-pointer"
              >
                <option value="PUBLISHED">Published (Live to Students)</option>
                <option value="UNPUBLISHED">Unpublished (Draft)</option>
                <option value="ARCHIVED">Archived</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">Uploaded By / Cell *</label>
              <input
                type="text"
                value={uploadedBy}
                onChange={(e) => setUploadedBy(e.target.value)}
                placeholder="e.g. VTU Controller of Examinations"
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-semibold"
                required
              />
            </div>
          </div>

          {/* Solution Key Checkbox */}
          <div className="p-3 rounded-xl border border-border bg-accent/10 flex items-center gap-3">
            <input
              type="checkbox"
              id="solutionCheck"
              checked={hasSolutionKey}
              onChange={(e) => setHasSolutionKey(e.target.checked)}
              className="h-4 w-4 rounded accent-primary cursor-pointer"
            />
            <label htmlFor="solutionCheck" className="font-bold text-foreground cursor-pointer flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span>Includes Verified Official Answer / Solution Key</span>
            </label>
          </div>

          {/* Storage Details */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block font-bold text-foreground mb-1">Storage File Path / Key *</label>
              <input
                type="text"
                value={fileUrl}
                onChange={(e) => setFileUrl(e.target.value)}
                placeholder="s3://vtu-papers-prod/paper.pdf"
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-mono text-xs"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-foreground mb-1">File Size *</label>
              <input
                type="text"
                value={fileSize}
                onChange={(e) => setFileSize(e.target.value)}
                placeholder="e.g. 3.8 MB"
                className="w-full px-3 py-2 rounded-xl border border-border bg-card text-foreground focus:ring-2 focus:ring-primary/40 outline-none font-bold"
                required
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
            <Button variant="outline" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" size="sm" type="submit" icon={<Upload className="h-4 w-4" />}>
              Save Question Paper
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
