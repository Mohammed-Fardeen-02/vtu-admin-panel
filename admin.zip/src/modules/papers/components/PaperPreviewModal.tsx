import React, { useState } from 'react';
import {
  X,
  HelpCircle,
  Download,
  Eye,
  Lock,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Copy,
  Check,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { AdminQuestionPaper } from '../../../shared/types/papers.types';

export interface PaperPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  paper: AdminQuestionPaper;
}

export const PaperPreviewModal: React.FC<PaperPreviewModalProps> = ({
  isOpen,
  onClose,
  paper,
}) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [showSolutionMode, setShowSolutionMode] = useState<boolean>(paper.hasSolutionKey);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (!isOpen) return null;

  const handleCopySecureUrl = () => {
    navigator.clipboard.writeText(paper.secureUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4 max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-500 font-black">
              <HelpCircle className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-primary text-xs">{paper.subjectCode}</span>
                <span className="text-xs font-bold text-foreground">{paper.subjectName}</span>
                <Badge variant="primary" className="text-[9px]">
                  {paper.year} {paper.examCategory} Exam
                </Badge>
              </div>
              <h3 className="text-base font-black text-foreground truncate max-w-xl">{paper.title}</h3>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Academic Hierarchy & Metadata Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-xl bg-accent/20 border border-border text-xs flex-shrink-0">
          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Academic Hierarchy</span>
            <span className="font-bold text-foreground">
              {paper.branchCode} • Sem {paper.semester} ({paper.schemeYear} Scheme)
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Paper Type</span>
            <span className="font-bold text-foreground">
              {paper.paperType} ({paper.examCategory})
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Solution Key Status</span>
            <span className="font-bold text-foreground">
              {paper.hasSolutionKey ? (
                <Badge variant="success" icon={<CheckCircle2 className="h-3 w-3" />}>Solution Included</Badge>
              ) : (
                <Badge variant="warning">Paper Only</Badge>
              )}
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Downloads & Views</span>
            <span className="font-bold text-foreground flex items-center gap-2">
              <span className="flex items-center gap-1"><Download className="h-3 w-3 text-blue-500" /> {paper.downloads}</span>
              <span className="flex items-center gap-1"><Eye className="h-3 w-3 text-purple-500" /> {paper.viewsCount}</span>
            </span>
          </div>
        </div>

        {/* Question Paper Preview Viewer Container */}
        <div className="flex-1 min-h-[350px] rounded-xl bg-slate-950 border border-slate-800 p-4 flex flex-col justify-between overflow-hidden relative text-slate-100">
          {/* Viewer Toolbar */}
          <div className="flex flex-wrap items-center justify-between bg-slate-900/90 px-4 py-2 rounded-lg border border-slate-800 text-xs gap-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="font-bold">Page {currentPage} of {paper.pageCount}</span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(paper.pageCount, p + 1))}
                disabled={currentPage === paper.pageCount}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            {/* Answer Key Toggle */}
            {paper.hasSolutionKey && (
              <button
                onClick={() => setShowSolutionMode(!showSolutionMode)}
                className={`px-3 py-1 rounded-lg text-xs font-black transition-colors flex items-center gap-1.5 ${
                  showSolutionMode
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>{showSolutionMode ? 'Viewing Verified Answer Key' : 'Switch to Answer Key'}</span>
              </button>
            )}

            <div className="flex items-center gap-1">
              <button
                onClick={() => setZoomLevel((z) => Math.max(75, z - 25))}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700"
              >
                <ZoomOut className="h-3.5 w-3.5" />
              </button>
              <span className="font-mono text-[11px] w-12 text-center">{zoomLevel}%</span>
              <button
                onClick={() => setZoomLevel((z) => Math.min(150, z + 25))}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Paper Canvas Simulation */}
          <div className="flex-1 my-4 overflow-auto flex items-center justify-center">
            <div
              style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'center center' }}
              className="w-full max-w-lg min-h-[260px] bg-slate-900 border border-slate-700 rounded-xl p-8 shadow-2xl flex flex-col justify-between text-slate-300 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 text-[11px] text-slate-400">
                <span className="font-bold text-white uppercase">{paper.subjectCode} - {paper.subjectName}</span>
                <span>USN: __________________</span>
              </div>

              <div className="space-y-3 py-2 text-xs">
                <div className="text-center font-black text-white space-y-0.5">
                  <h4>VISVESVARAYA TECHNOLOGICAL UNIVERSITY, BELAGAVI</h4>
                  <p className="text-[10px] text-slate-400">
                    {paper.semester}th Semester B.E./B.Tech Degree Examination, {paper.year}
                  </p>
                  <p className="text-[10px] text-purple-400 font-extrabold uppercase">
                    {paper.paperType.replace('_', ' ')} ({paper.examCategory})
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 space-y-2">
                  <p className="font-bold text-slate-200">Q1. (a) Define Entity Relationship (ER) Model and explain its components with an example.</p>
                  {showSolutionMode && (
                    <div className="p-2 rounded bg-emerald-950/60 border border-emerald-800/60 text-[11px] text-emerald-300 font-mono">
                      <span className="font-bold block text-emerald-400 mb-0.5">[FACULTY VERIFIED SOLUTION]</span>
                      An ER model describes structure of database with schema diagrams: Entities (Rectangles), Attributes (Ovals), Relationships (Diamonds).
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-[10px] text-slate-500">
                <span>Page {currentPage} of {paper.pageCount}</span>
                <span>VTU Central Question Paper Bank</span>
              </div>
            </div>
          </div>

          {/* Secure Signed URL Display */}
          <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <Lock className="h-3.5 w-3.5 text-purple-400 flex-shrink-0" />
              <span className="text-[10px] text-slate-400 font-mono truncate">{paper.secureUrl}</span>
            </div>
            <button
              onClick={handleCopySecureUrl}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-white flex items-center gap-1.5 flex-shrink-0"
            >
              {copiedUrl ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              <span>{copiedUrl ? 'Copied' : 'Copy Tokenized URL'}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 flex-shrink-0">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
            <span>Unrestricted Storage Bucket URLs are strictly hidden. Tokenized access active.</span>
          </div>

          <Button variant="outline" size="sm" onClick={onClose}>
            Close Paper Preview
          </Button>
        </div>
      </div>
    </div>
  );
};
