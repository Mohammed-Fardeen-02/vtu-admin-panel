import React, { useState } from 'react';
import {
  X,
  FileText,
  Download,
  Eye,
  Bookmark,
  Share2,
  Lock,
  ChevronLeft,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  Copy,
  Check,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '../../../shared/components/ui/Button';
import { Badge } from '../../../shared/components/ui/Badge';
import { AdminNote } from '../../../shared/types/notes.types';

export interface NotePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  note: AdminNote;
}

export const NotePreviewModal: React.FC<NotePreviewModalProps> = ({
  isOpen,
  onClose,
  note,
}) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [copiedUrl, setCopiedUrl] = useState(false);

  if (!isOpen) return null;

  const handleCopySecureUrl = () => {
    navigator.clipboard.writeText(note.secureUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-card border border-border rounded-2xl p-6 shadow-2xl space-y-4 max-h-[95vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-primary/10 text-primary font-black">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-primary text-xs">{note.subjectCode}</span>
                <span className="text-xs font-bold text-foreground">{note.subjectName}</span>
                <Badge variant={note.status === 'PUBLISHED' ? 'success' : 'neutral'} className="text-[9px]">
                  {note.status}
                </Badge>
              </div>
              <h3 className="text-base font-black text-foreground truncate max-w-xl">{note.title}</h3>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Academic Hierarchy & Telemetry Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-xl bg-accent/20 border border-border text-xs flex-shrink-0">
          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Academic Path</span>
            <span className="font-bold text-foreground">
              {note.branchCode} • Sem {note.semester} ({note.schemeYear} Scheme)
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Author</span>
            <span className="font-bold text-foreground">
              {note.authorName} ({note.authorRole})
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Format & Size</span>
            <span className="font-bold text-foreground">
              {note.format} • {note.fileSize} ({note.pageCount} Pages)
            </span>
          </div>

          <div>
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase block">Usage Telemetry</span>
            <span className="font-bold text-foreground flex items-center gap-2">
              <span className="flex items-center gap-1"><Download className="h-3 w-3 text-blue-500" /> {note.downloads}</span>
              <span className="flex items-center gap-1"><Bookmark className="h-3 w-3 text-amber-500" /> {note.bookmarksCount}</span>
            </span>
          </div>
        </div>

        {/* Document Interactive Reader Viewer */}
        <div className="flex-1 min-h-[350px] rounded-xl bg-slate-950 border border-slate-800 p-4 flex flex-col justify-between overflow-hidden relative text-slate-100">
          {/* Controls Bar */}
          <div className="flex items-center justify-between bg-slate-900/80 px-4 py-2 rounded-lg border border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="font-bold">Page {currentPage} of {note.pageCount}</span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(note.pageCount, p + 1))}
                disabled={currentPage === note.pageCount}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setZoomLevel((z) => Math.max(75, z - 25))}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700"
                >
                  <ZoomOut className="h-3.5 w-3.5" />
                </button>
                <span className="font-mono text-[11px] w-12 text-center">{zoomLevel}%</span>
                <button
                  onClick={() => setZoomLevel((z) => Math.min(150, z + 25))}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700"
                >
                  <ZoomIn className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Page Preview Simulation */}
          <div className="flex-1 my-4 overflow-auto flex items-center justify-center">
            <div
              style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: 'center center' }}
              className="w-full max-w-lg min-h-[260px] bg-slate-900 border border-slate-700 rounded-xl p-8 shadow-2xl flex flex-col justify-between text-slate-300 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 text-[11px] text-slate-400">
                <span>VTU OFFICIAL DOCUMENT PREVIEW</span>
                <span>PAGE {currentPage}</span>
              </div>

              <div className="space-y-3 py-4">
                <div className="h-4 bg-slate-800 rounded w-3/4 animate-pulse" />
                <div className="h-3 bg-slate-800/80 rounded w-full" />
                <div className="h-3 bg-slate-800/80 rounded w-5/6" />
                <div className="h-20 bg-blue-950/40 border border-blue-800/40 rounded-lg p-3 text-[11px] text-blue-200">
                  <p className="font-bold text-white mb-1">Module Highlight - Page {currentPage}</p>
                  <p>{note.description || 'Core syllabus topic explanation, handwritten formulas, and diagrams for VTU semester examination revision.'}</p>
                </div>
                <div className="h-3 bg-slate-800/80 rounded w-4/5" />
              </div>

              <div className="flex items-center justify-between border-t border-slate-800 pt-3 text-[10px] text-slate-500">
                <span>{note.subjectCode} • {note.authorName}</span>
                <span>CONFIDENTIAL VTU REPOSITORY ACCESS</span>
              </div>
            </div>
          </div>

          {/* Secure URL Display */}
          <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <Lock className="h-3.5 w-3.5 text-emerald-400 flex-shrink-0" />
              <span className="text-[10px] text-slate-400 font-mono truncate">{note.secureUrl}</span>
            </div>
            <button
              onClick={handleCopySecureUrl}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] font-bold text-white flex items-center gap-1.5 flex-shrink-0"
            >
              {copiedUrl ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
              <span>{copiedUrl ? 'Copied' : 'Copy Signed URL'}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 flex-shrink-0">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-emerald-500" />
            <span>Unrestricted Storage Bucket URLs are strictly hidden. Tokenized access active.</span>
          </div>

          <Button variant="outline" size="sm" onClick={onClose}>
            Close Reader
          </Button>
        </div>
      </div>
    </div>
  );
};
