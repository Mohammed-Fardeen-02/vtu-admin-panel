import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  FileText,
  HelpCircle,
  BarChart3,
  Calculator,
  Calendar,
  Bell,
  Settings,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Building2,
  Award,
  BookOpen,
  Video,
  Search,
  Layers,
  UserCheck,
  FolderTree,
} from 'lucide-react';
import { useThemeStore } from '../../store/useThemeStore';
import { MortarboardSvg } from '../../shared/components/graphics/MortarboardSvg';

export const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const navigation = [
    { name: 'Dashboard Overview', href: '/', icon: LayoutDashboard },
    { name: 'Academic Hierarchy', href: '/academic-structure', icon: BookOpen },
    { name: 'Syllabus & Modules', href: '/syllabus-modules', icon: FolderTree },
    { name: 'Student Directory', href: '/students', icon: Users },
    { name: 'VTU Colleges', href: '/colleges', icon: Building2 },
    { name: 'Notes Moderation', href: '/notes', icon: FileText },
    { name: 'Question Papers', href: '/papers', icon: HelpCircle },
    { name: 'Passing Packages', href: '/passing-packages', icon: Layers },
    { name: 'Video Learning', href: '/videos', icon: Video },
    { name: 'Rewards & Coins', href: '/rewards', icon: Award },
    { name: 'Contributors', href: '/contributors', icon: UserCheck },
    { name: 'Smart Search Admin', href: '/search-admin', icon: Search },
    { name: 'Downloads & Bookmarks', href: '/analytics', icon: BarChart3 },
    { name: 'Grading & Schemes', href: '/grading', icon: Calculator },
    { name: 'Academic Calendar', href: '/calendar', icon: Calendar },
    { name: 'Circulars & Alerts', href: '/circulars', icon: Bell },
    { name: 'Governance Settings', href: '/settings', icon: Settings },
  ];

  return (
    <aside
      className={`relative flex flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-all duration-300 ease-in-out z-30 ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="flex h-16 items-center justify-between px-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3 overflow-hidden">
          <MortarboardSvg className="w-9 h-9 flex-shrink-0" />
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-base font-black tracking-tight text-white leading-tight">
                VTU SUPER APP
              </span>
              <span className="text-[10px] font-bold text-blue-400 tracking-wider uppercase">
                Governance Portal
              </span>
            </div>
          )}
        </div>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="rounded-lg p-1.5 text-slate-400 hover:bg-sidebar-accent hover:text-white transition-colors"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* University Badge Tag */}
      {!collapsed && (
        <div className="mx-4 mt-4 p-3 rounded-xl bg-blue-950/60 border border-blue-800/40 flex items-center gap-2.5">
          <ShieldCheck className="h-5 w-5 text-blue-400 flex-shrink-0" />
          <div className="flex flex-col">
            <span className="text-xs font-bold text-white leading-tight">VTU Belagavi</span>
            <span className="text-[10px] text-slate-400">Autonomous Admin Console</span>
          </div>
        </div>
      )}

      {/* Navigation Links */}
      <nav className="flex-1 space-y-1.5 px-3 py-4 overflow-y-auto">
        {navigation.map((item) => {
          const isActive =
            item.href === '/'
              ? location.pathname === '/'
              : location.pathname.startsWith(item.href);

          return (
            <NavLink
              key={item.name}
              to={item.href}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold transition-all duration-200 ${
                isActive
                  ? 'bg-sidebar-primary text-white shadow-md shadow-blue-900/40 font-extrabold'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-white'
              }`}
            >
              <item.icon
                className={`h-4 w-4 flex-shrink-0 transition-colors ${
                  isActive ? 'text-white' : 'text-slate-400 group-hover:text-white'
                }`}
              />
              {!collapsed && (
                <div className="flex items-center justify-between flex-1 overflow-hidden">
                  <span className="truncate">{item.name}</span>
                </div>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Controller Information Footer */}
      {!collapsed && (
        <div className="p-4 border-t border-sidebar-border bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-full bg-blue-600 flex items-center justify-center font-bold text-white border-2 border-blue-400 shadow-sm text-xs">
              KV
            </div>
            <div className="flex flex-col truncate">
              <span className="text-xs font-bold text-white truncate">Dr. K. V. Suresh</span>
              <span className="text-[10px] text-slate-400 truncate">Exam Controller</span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
