import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

export const Breadcrumbs: React.FC = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  const routeNames: Record<string, string> = {
    students: 'Student Directory',
    colleges: 'VTU Colleges',
    notes: 'Notes Moderation',
    papers: 'Question Papers Archive',
    grading: 'Grading & Schemes',
    calendar: 'Academic Calendar',
    circulars: 'Circulars & Push Alerts',
    settings: 'Governance Settings',
  };

  return (
    <nav className="flex items-center gap-2 text-xs font-semibold text-muted-foreground mb-4">
      <Link to="/" className="hover:text-primary transition-colors flex items-center gap-1">
        <Home className="h-3.5 w-3.5" />
        <span>Dashboard</span>
      </Link>
      {pathnames.map((name, index) => {
        const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
        const isLast = index === pathnames.length - 1;
        const displayName = routeNames[name] || name;

        return (
          <React.Fragment key={name}>
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60" />
            {isLast ? (
              <span className="font-extrabold text-foreground">{displayName}</span>
            ) : (
              <Link to={routeTo} className="hover:text-primary transition-colors">
                {displayName}
              </Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};
