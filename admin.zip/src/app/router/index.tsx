import React from 'react';
import { createBrowserRouter } from 'react-router-dom';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { DashboardPage } from '../../modules/dashboard/DashboardPage';
import { StudentsListPage } from '../../modules/students/StudentsListPage';
import { CollegesListPage } from '../../modules/colleges/CollegesListPage';
import { NotesModerationPage } from '../../modules/notes/NotesModerationPage';
import { QuestionPapersPage } from '../../modules/papers/QuestionPapersPage';
import { SchemeConfigPage } from '../../modules/grading/SchemeConfigPage';
import { AcademicCalendarPage } from '../../modules/calendar/AcademicCalendarPage';
import { CircularsPage } from '../../modules/circulars/CircularsPage';
import { SettingsPage } from '../../modules/settings/SettingsPage';
import { LoginPage } from '../../modules/auth/LoginPage';
import { AcademicStructurePage } from '../../modules/academic/AcademicStructurePage';
import { SyllabusModulesMasterPage } from '../../modules/academic/SyllabusModulesMasterPage';
import { BookmarksDownloadsAdminPage } from '../../modules/analytics/BookmarksDownloadsAdminPage';
import { PassingPackagesPage } from '../../modules/packages/PassingPackagesPage';
import { RewardRulesPage } from '../../modules/rewards/RewardRulesPage';
import { ContributorDirectoryPage } from '../../modules/contributors/ContributorDirectoryPage';
import { SmartSearchAdminPage } from '../../modules/search/SmartSearchAdminPage';
import { VideoCoursesPage } from '../../modules/videos/VideoCoursesPage';

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/',
    element: <DashboardLayout />,
    children: [
      {
        index: true,
        element: <DashboardPage />,
      },
      {
        path: 'academic-structure',
        element: <AcademicStructurePage />,
      },
      {
        path: 'syllabus-modules',
        element: <SyllabusModulesMasterPage />,
      },
      {
        path: 'students',
        element: <StudentsListPage />,
      },
      {
        path: 'colleges',
        element: <CollegesListPage />,
      },
      {
        path: 'notes',
        element: <NotesModerationPage />,
      },
      {
        path: 'papers',
        element: <QuestionPapersPage />,
      },
      {
        path: 'passing-packages',
        element: <PassingPackagesPage />,
      },
      {
        path: 'videos',
        element: <VideoCoursesPage />,
      },
      {
        path: 'analytics',
        element: <BookmarksDownloadsAdminPage />,
      },
      {
        path: 'grading',
        element: <SchemeConfigPage />,
      },
      {
        path: 'rewards',
        element: <RewardRulesPage />,
      },
      {
        path: 'contributors',
        element: <ContributorDirectoryPage />,
      },
      {
        path: 'search-admin',
        element: <SmartSearchAdminPage />,
      },
      {
        path: 'calendar',
        element: <AcademicCalendarPage />,
      },
      {
        path: 'circulars',
        element: <CircularsPage />,
      },
      {
        path: 'settings',
        element: <SettingsPage />,
      },
    ],
  },
]);
