export type PaperType =
  | 'SEE_THEORY'
  | 'IA_1'
  | 'IA_2'
  | 'IA_3'
  | 'LAB_EXAM'
  | 'SOLUTION_KEY';

export type ExamCategory = 'REGULAR' | 'MAKEUP' | 'MODEL';

export type PaperStatus = 'PUBLISHED' | 'UNPUBLISHED' | 'ARCHIVED';

export interface AdminQuestionPaper {
  id: string;
  title: string;
  // Associated Central Academic Structure
  branchCode: string;
  schemeYear: string;
  semester: number;
  subjectId: string;
  subjectCode: string;
  subjectName: string;
  // Exam Specific Metadata
  year: number; // e.g. 2025, 2024, 2023
  paperType: PaperType;
  examCategory: ExamCategory;
  hasSolutionKey: boolean;
  status: PaperStatus;
  // Storage & Access
  fileUrl: string;
  secureUrl: string;
  fileSize: string;
  fileSizeBytes: number;
  pageCount: number;
  // Telemetry
  downloads: number;
  viewsCount: number;
  uploadedBy: string;
  uploadDate: string;
  lastModified: string;
}

export interface PaperFilterState {
  searchQuery: string;
  branchCode: string;
  schemeYear: string;
  semester: number | 'ALL';
  subjectId: string;
  paperType: PaperType | 'ALL';
  examCategory: ExamCategory | 'ALL';
  status: PaperStatus | 'ALL';
  hasSolutionKey: boolean | 'ALL';
}
