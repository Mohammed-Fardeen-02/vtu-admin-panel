import { create } from 'zustand';
import { AdminQuestionPaper, PaperType, ExamCategory, PaperStatus } from '../shared/types/papers.types';
import { useAcademicStore } from './useAcademicStore';

// Helper to generate secure signed URL for PYQ papers
export const generateSecurePaperUrl = (paperId: string, fileKey: string): string => {
  const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  const expiry = Math.floor(Date.now() / 1000) + 86400; // 24 hours validity
  return `https://storage.vtu.ac.in/sec/v1/papers/${paperId}?key=${encodeURIComponent(fileKey)}&exp=${expiry}&sig=${token}`;
};

const INITIAL_PAPERS: AdminQuestionPaper[] = [
  {
    id: 'paper-101',
    title: 'DBMS (21CS53) SEE Examination Question Paper - Jan/Feb 2025',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    subjectId: 'subj-101',
    subjectCode: '21CS53',
    subjectName: 'Database Management Systems',
    year: 2025,
    paperType: 'SEE_THEORY',
    examCategory: 'REGULAR',
    hasSolutionKey: true,
    status: 'PUBLISHED',
    fileUrl: 's3://vtu-papers-prod/cse/2022/sem5/21CS53_SEE_2025.pdf',
    secureUrl: generateSecurePaperUrl('paper-101', '21CS53_SEE_2025.pdf'),
    fileSize: '3.6 MB',
    fileSizeBytes: 3774873,
    pageCount: 6,
    downloads: 3450,
    viewsCount: 14200,
    uploadedBy: 'VTU Controller of Examinations',
    uploadDate: '2025-03-01',
    lastModified: '2025-03-01',
  },
  {
    id: 'paper-102',
    title: 'Computer Networks (21CS52) SEE Regular Examination - June/July 2025',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    subjectId: 'subj-102',
    subjectCode: '21CS52',
    subjectName: 'Computer Networks',
    year: 2025,
    paperType: 'SEE_THEORY',
    examCategory: 'REGULAR',
    hasSolutionKey: true,
    status: 'PUBLISHED',
    fileUrl: 's3://vtu-papers-prod/cse/2022/sem5/21CS52_SEE_2025.pdf',
    secureUrl: generateSecurePaperUrl('paper-102', '21CS52_SEE_2025.pdf'),
    fileSize: '4.1 MB',
    fileSizeBytes: 4299161,
    pageCount: 8,
    downloads: 2890,
    viewsCount: 9800,
    uploadedBy: 'VTU Controller of Examinations',
    uploadDate: '2025-08-10',
    lastModified: '2025-08-10',
  },
  {
    id: 'paper-103',
    title: 'Theory of Computation (21CS54) Makeup Examination Paper - Feb 2025',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    subjectId: 'subj-103',
    subjectCode: '21CS54',
    subjectName: 'Theory of Computation',
    year: 2025,
    paperType: 'SEE_THEORY',
    examCategory: 'MAKEUP',
    hasSolutionKey: false,
    status: 'PUBLISHED',
    fileUrl: 's3://vtu-papers-prod/cse/2022/sem5/21CS54_MAKEUP_2025.pdf',
    secureUrl: generateSecurePaperUrl('paper-103', '21CS54_MAKEUP_2025.pdf'),
    fileSize: '2.9 MB',
    fileSizeBytes: 3040870,
    pageCount: 5,
    downloads: 1980,
    viewsCount: 6500,
    uploadedBy: 'VTU Academic Board',
    uploadDate: '2025-03-15',
    lastModified: '2025-03-15',
  },
  {
    id: 'paper-104',
    title: 'Digital Signal Processing (21EC42) VTU Model Question Paper 2025',
    branchCode: 'ECE',
    schemeYear: '2022',
    semester: 4,
    subjectId: 'subj-104',
    subjectCode: '21EC42',
    subjectName: 'Digital Signal Processing',
    year: 2025,
    paperType: 'SEE_THEORY',
    examCategory: 'MODEL',
    hasSolutionKey: true,
    status: 'PUBLISHED',
    fileUrl: 's3://vtu-papers-prod/ece/2022/sem4/21EC42_MODEL_2025.pdf',
    secureUrl: generateSecurePaperUrl('paper-104', '21EC42_MODEL_2025.pdf'),
    fileSize: '3.2 MB',
    fileSizeBytes: 3355443,
    pageCount: 7,
    downloads: 4120,
    viewsCount: 15600,
    uploadedBy: 'VTU Board of Studies',
    uploadDate: '2025-01-10',
    lastModified: '2025-01-10',
  },
  {
    id: 'paper-105',
    title: 'DBMS (21CS53) First Internal Assessment Test Paper (IA-1)',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    subjectId: 'subj-101',
    subjectCode: '21CS53',
    subjectName: 'Database Management Systems',
    year: 2026,
    paperType: 'IA_1',
    examCategory: 'REGULAR',
    hasSolutionKey: true,
    status: 'UNPUBLISHED',
    fileUrl: 's3://vtu-papers-prod/cse/2022/sem5/21CS53_IA1_2026.pdf',
    secureUrl: generateSecurePaperUrl('paper-105', '21CS53_IA1_2026.pdf'),
    fileSize: '1.4 MB',
    fileSizeBytes: 1468006,
    pageCount: 3,
    downloads: 120,
    viewsCount: 450,
    uploadedBy: 'Department of CSE',
    uploadDate: '2026-08-30',
    lastModified: '2026-08-30',
  },
];

interface PaperStore {
  papers: AdminQuestionPaper[];
  // CRUD
  addPaper: (paperData: Omit<AdminQuestionPaper, 'id' | 'secureUrl' | 'downloads' | 'viewsCount' | 'uploadDate' | 'lastModified'>) => { success: boolean; error?: string };
  updatePaper: (id: string, updates: Partial<AdminQuestionPaper>) => { success: boolean; error?: string };
  replacePaperFile: (id: string, fileKey: string, fileSize: string, fileSizeBytes: number, pageCount?: number) => void;
  publishPaper: (id: string) => void;
  unpublishPaper: (id: string) => void;
  archivePaper: (id: string) => void;
  deletePaper: (id: string) => void;
  reorderPapers: (reordered: AdminQuestionPaper[]) => void;
  // Bulk operations
  bulkPublishPapers: (ids: string[]) => void;
  bulkUnpublishPapers: (ids: string[]) => void;
  bulkArchivePapers: (ids: string[]) => void;
  bulkDeletePapers: (ids: string[]) => void;
  bulkReassignSubject: (ids: string[], targetSubjectId: string, subjectCode: string, subjectName: string, branchCode: string, schemeYear: string, semester: number) => void;
}

export const usePaperStore = create<PaperStore>((set, get) => ({
  papers: INITIAL_PAPERS,

  addPaper: (data) => {
    // Validate Academic Hierarchy mapping before storing
    const academicStore = useAcademicStore.getState();
    const validation = academicStore.validateHierarchyMapping(
      data.branchCode,
      data.schemeYear,
      data.semester,
      data.subjectId
    );
    if (!validation.isValid) {
      return { success: false, error: validation.error || 'Invalid Academic Hierarchy mapping.' };
    }

    const { papers } = get();
    const id = `paper-${Date.now()}`;
    const secureUrl = generateSecurePaperUrl(id, data.fileUrl);

    const newPaper: AdminQuestionPaper = {
      ...data,
      id,
      secureUrl,
      downloads: 0,
      viewsCount: 1,
      uploadDate: new Date().toISOString().split('T')[0],
      lastModified: new Date().toISOString().split('T')[0],
    };

    set({ papers: [newPaper, ...papers] });
    return { success: true };
  },

  updatePaper: (id, updates) => {
    const { papers } = get();
    const target = papers.find((p) => p.id === id);
    if (!target) return { success: false, error: 'Question Paper not found.' };

    const branch = updates.branchCode || target.branchCode;
    const scheme = updates.schemeYear || target.schemeYear;
    const sem = updates.semester || target.semester;
    const subjectId = updates.subjectId || target.subjectId;

    // Validate hierarchy mapping
    const academicStore = useAcademicStore.getState();
    const validation = academicStore.validateHierarchyMapping(branch, scheme, sem, subjectId);
    if (!validation.isValid) {
      return { success: false, error: validation.error || 'Invalid Academic Hierarchy mapping.' };
    }

    set((state) => ({
      papers: state.papers.map((p) =>
        p.id === id
          ? {
              ...p,
              ...updates,
              lastModified: new Date().toISOString().split('T')[0],
            }
          : p
      ),
    }));
    return { success: true };
  },

  replacePaperFile: (id, fileKey, fileSize, fileSizeBytes, pageCount) => {
    set((state) => ({
      papers: state.papers.map((p) => {
        if (p.id !== id) return p;
        const secureUrl = generateSecurePaperUrl(id, fileKey);
        return {
          ...p,
          fileUrl: fileKey,
          secureUrl,
          fileSize,
          fileSizeBytes,
          pageCount: pageCount || p.pageCount,
          lastModified: new Date().toISOString().split('T')[0],
        };
      }),
    }));
  },

  publishPaper: (id) => {
    set((state) => ({
      papers: state.papers.map((p) => (p.id === id ? { ...p, status: 'PUBLISHED' } : p)),
    }));
  },

  unpublishPaper: (id) => {
    set((state) => ({
      papers: state.papers.map((p) => (p.id === id ? { ...p, status: 'UNPUBLISHED' } : p)),
    }));
  },

  archivePaper: (id) => {
    set((state) => ({
      papers: state.papers.map((p) => (p.id === id ? { ...p, status: 'ARCHIVED' } : p)),
    }));
  },

  deletePaper: (id) => {
    set((state) => ({
      papers: state.papers.filter((p) => p.id !== id),
    }));
  },

  reorderPapers: (reordered) => {
    set({ papers: reordered });
  },

  // Bulk Operations
  bulkPublishPapers: (ids) => {
    set((state) => ({
      papers: state.papers.map((p) => (ids.includes(p.id) ? { ...p, status: 'PUBLISHED' } : p)),
    }));
  },

  bulkUnpublishPapers: (ids) => {
    set((state) => ({
      papers: state.papers.map((p) => (ids.includes(p.id) ? { ...p, status: 'UNPUBLISHED' } : p)),
    }));
  },

  bulkArchivePapers: (ids) => {
    set((state) => ({
      papers: state.papers.map((p) => (ids.includes(p.id) ? { ...p, status: 'ARCHIVED' } : p)),
    }));
  },

  bulkDeletePapers: (ids) => {
    set((state) => ({
      papers: state.papers.filter((p) => !ids.includes(p.id)),
    }));
  },

  bulkReassignSubject: (ids, targetSubjectId, subjectCode, subjectName, branchCode, schemeYear, semester) => {
    set((state) => ({
      papers: state.papers.map((p) =>
        ids.includes(p.id)
          ? {
              ...p,
              subjectId: targetSubjectId,
              subjectCode,
              subjectName,
              branchCode,
              schemeYear,
              semester,
              lastModified: new Date().toISOString().split('T')[0],
            }
          : p
      ),
    }));
  },
}));
