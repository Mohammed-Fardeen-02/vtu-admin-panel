import { create } from 'zustand';
import {
  AcademicBranch,
  AcademicScheme,
  AcademicSemester,
  AcademicSubject,
  AcademicModule,
  AcademicUnit,
  SharedAcademicSourceOfTruth,
} from '../shared/types/academic.types';

// Mock Initial Data for Central Source of Truth
const INITIAL_BRANCHES: AcademicBranch[] = [
  { id: 'b-1', code: 'CSE', name: 'Computer Science & Engineering', status: 'ACTIVE', order: 1 },
  { id: 'b-2', code: 'ISE', name: 'Information Science & Engineering', status: 'ACTIVE', order: 2 },
  { id: 'b-3', code: 'ECE', name: 'Electronics & Communication Engineering', status: 'ACTIVE', order: 3 },
  { id: 'b-4', code: 'AIML', name: 'Artificial Intelligence & Machine Learning', status: 'ACTIVE', order: 4 },
  { id: 'b-5', code: 'EEE', name: 'Electrical & Electronics Engineering', status: 'ACTIVE', order: 5 },
  { id: 'b-6', code: 'CIVIL', name: 'Civil Engineering', status: 'ACTIVE', order: 6 },
  { id: 'b-7', code: 'MECH', name: 'Mechanical Engineering', status: 'ACTIVE', order: 7 },
];

const INITIAL_SCHEMES: AcademicScheme[] = [
  { id: 'sc-1', year: '2025', title: '2025 NEP Model Scheme', isDefault: false, status: 'ACTIVE', totalCreditsRequired: 160 },
  { id: 'sc-2', year: '2022', title: '2022 NEP Choice Based Credit Scheme (CBCS)', isDefault: true, status: 'ACTIVE', totalCreditsRequired: 160 },
  { id: 'sc-3', year: '2021', title: '2021 Outcome Based Education Scheme', isDefault: false, status: 'ACTIVE', totalCreditsRequired: 160 },
  { id: 'sc-4', year: '2018', title: '2018 Legacy CBCS Scheme', isDefault: false, status: 'ARCHIVED', totalCreditsRequired: 175 },
];

const INITIAL_SEMESTERS: AcademicSemester[] = [
  { id: 'sem-1', semesterNumber: 1, title: '1st Semester (Physics/Chemistry Cycle)', status: 'ACTIVE', order: 1 },
  { id: 'sem-2', semesterNumber: 2, title: '2nd Semester (Physics/Chemistry Cycle)', status: 'ACTIVE', order: 2 },
  { id: 'sem-3', semesterNumber: 3, title: '3rd Semester (Core Discipline Engineering)', status: 'ACTIVE', order: 3 },
  { id: 'sem-4', semesterNumber: 4, title: '4th Semester (Core Discipline Engineering)', status: 'ACTIVE', order: 4 },
  { id: 'sem-5', semesterNumber: 5, title: '5th Semester (Professional Core & Electives)', status: 'ACTIVE', order: 5 },
  { id: 'sem-6', semesterNumber: 6, title: '6th Semester (Professional Core & Open Electives)', status: 'ACTIVE', order: 6 },
  { id: 'sem-7', semesterNumber: 7, title: '7th Semester (Advanced Specialization & Project)', status: 'ACTIVE', order: 7 },
  { id: 'sem-8', semesterNumber: 8, title: '8th Semester (Major Industry Project & Internship)', status: 'ACTIVE', order: 8 },
];

const INITIAL_SUBJECTS: AcademicSubject[] = [
  {
    id: 'subj-101',
    code: '21CS53',
    name: 'Database Management Systems',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    credits: 4,
    category: 'THEORY',
    status: 'ACTIVE',
    order: 1,
    description: 'Relational Model, SQL, ER Diagrams, Normalization & Transaction Processing.',
  },
  {
    id: 'subj-102',
    code: '21CS52',
    name: 'Computer Networks',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    credits: 4,
    category: 'THEORY',
    status: 'ACTIVE',
    order: 2,
    description: 'OSI Reference Model, TCP/IP, Routing Protocols & Socket Programming.',
  },
  {
    id: 'subj-103',
    code: '21CS54',
    name: 'Theory of Computation',
    branchCode: 'CSE',
    schemeYear: '2022',
    semester: 5,
    credits: 3,
    category: 'THEORY',
    status: 'ACTIVE',
    order: 3,
    description: 'Finite Automata, Context-Free Grammars, Pushdown Automata & Turing Machines.',
  },
  {
    id: 'subj-104',
    code: '21EC42',
    name: 'Digital Signal Processing',
    branchCode: 'ECE',
    schemeYear: '2022',
    semester: 4,
    credits: 4,
    category: 'INTEGRATED',
    status: 'ACTIVE',
    order: 1,
    description: 'Discrete Fourier Transform, FFT Algorithms, IIR & FIR Filter Design.',
  },
  {
    id: 'subj-105',
    code: '18CS71',
    name: 'Artificial Intelligence & Machine Learning',
    branchCode: 'CSE',
    schemeYear: '2018',
    semester: 7,
    credits: 4,
    category: 'THEORY',
    status: 'ARCHIVED',
    order: 1,
    description: 'Search Algorithms, Supervised Learning, Neural Networks & Decision Trees.',
  },
];

const INITIAL_MODULES: AcademicModule[] = [
  { id: 'mod-1', subjectId: 'subj-101', moduleNumber: 1, title: 'Module 1: Introduction & Entity Relationship Model', description: 'Concepts of Database Systems, Data Abstraction, ER Diagrams & Keys.', teachingHours: 8, status: 'ACTIVE', order: 1 },
  { id: 'mod-2', subjectId: 'subj-101', moduleNumber: 2, title: 'Module 2: Relational Model & Relational Algebra', description: 'Relational Data Model, Tuple Relational Calculus & Relational Operations.', teachingHours: 8, status: 'ACTIVE', order: 2 },
  { id: 'mod-3', subjectId: 'subj-101', moduleNumber: 3, title: 'Module 3: Structured Query Language (SQL)', description: 'DDL, DML, DCL commands, Joins, Subqueries & Triggers.', teachingHours: 10, status: 'ACTIVE', order: 3 },
  { id: 'mod-4', subjectId: 'subj-101', moduleNumber: 4, title: 'Module 4: Database Design & Normalization', description: 'Functional Dependencies, 1NF, 2NF, 3NF & BCNF Decomposition.', teachingHours: 8, status: 'ACTIVE', order: 4 },
  { id: 'mod-5', subjectId: 'subj-101', moduleNumber: 5, title: 'Module 5: Transaction Processing & Concurrency Control', description: 'ACID Properties, Serializability, Two-Phase Locking & Recovery.', teachingHours: 8, status: 'ACTIVE', order: 5 },
  { id: 'mod-6', subjectId: 'subj-102', moduleNumber: 1, title: 'Module 1: Introduction to Computer Networks & Physical Layer', description: 'Network Topologies, OSI Reference Model, TCP/IP Suite & Data Transmission.', teachingHours: 8, status: 'ACTIVE', order: 1 },
  { id: 'mod-7', subjectId: 'subj-102', moduleNumber: 2, title: 'Module 2: Data Link Layer & Medium Access Control', description: 'Framing, Error Detection/Correction, CSMA/CD & Ethernet Standards.', teachingHours: 8, status: 'ACTIVE', order: 2 },
];

const INITIAL_UNITS: AcademicUnit[] = [
  { id: 'u-1', moduleId: 'mod-1', unitNumber: 1, title: 'Database System Concepts & Architecture', topicsCount: 5, status: 'ACTIVE', order: 1 },
  { id: 'u-2', moduleId: 'mod-1', unitNumber: 2, title: 'Data Modeling using Entity-Relationship Diagrams', topicsCount: 6, status: 'ACTIVE', order: 2 },
  { id: 'u-3', moduleId: 'mod-2', unitNumber: 1, title: 'Relational Model Constraints & Relational Schemas', topicsCount: 4, status: 'ACTIVE', order: 1 },
  { id: 'u-4', moduleId: 'mod-3', unitNumber: 1, title: 'Complex Queries, Nested Subqueries & Views in SQL', topicsCount: 8, status: 'ACTIVE', order: 1 },
  { id: 'u-5', moduleId: 'mod-6', unitNumber: 1, title: 'OSI Reference Model vs TCP/IP Protocol Stack', topicsCount: 6, status: 'ACTIVE', order: 1 },
];

interface AcademicStore {
  branches: AcademicBranch[];
  schemes: AcademicScheme[];
  semesters: AcademicSemester[];
  subjects: AcademicSubject[];
  modules: AcademicModule[];
  units: AcademicUnit[];

  // Branch CRUD
  addBranch: (branch: Omit<AcademicBranch, 'id'>) => { success: boolean; error?: string };
  updateBranch: (id: string, updates: Partial<AcademicBranch>) => { success: boolean; error?: string };
  toggleBranchStatus: (id: string) => void;
  archiveBranch: (id: string) => void;
  restoreBranch: (id: string) => void;
  reorderBranches: (branches: AcademicBranch[]) => void;

  // Scheme CRUD
  addScheme: (scheme: Omit<AcademicScheme, 'id'>) => { success: boolean; error?: string };
  updateScheme: (id: string, updates: Partial<AcademicScheme>) => { success: boolean; error?: string };
  toggleSchemeStatus: (id: string) => void;
  archiveScheme: (id: string) => void;
  restoreScheme: (id: string) => void;
  reorderSchemes: (schemes: AcademicScheme[]) => void;

  // Semester CRUD
  addSemester: (sem: Omit<AcademicSemester, 'id'>) => { success: boolean; error?: string };
  updateSemester: (id: string, updates: Partial<AcademicSemester>) => { success: boolean; error?: string };
  toggleSemesterStatus: (id: string) => void;
  archiveSemester: (id: string) => void;
  restoreSemester: (id: string) => void;
  reorderSemesters: (semesters: AcademicSemester[]) => void;

  // Subject CRUD
  addSubject: (subject: Omit<AcademicSubject, 'id'>) => { success: boolean; error?: string };
  updateSubject: (id: string, updates: Partial<AcademicSubject>) => { success: boolean; error?: string };
  toggleSubjectStatus: (id: string) => void;
  archiveSubject: (id: string) => void;
  restoreSubject: (id: string) => void;
  reorderSubjects: (subjects: AcademicSubject[]) => void;

  // Module CRUD
  addModule: (mod: Omit<AcademicModule, 'id'>) => { success: boolean; error?: string };
  updateModule: (id: string, updates: Partial<AcademicModule>) => { success: boolean; error?: string };
  toggleModuleStatus: (id: string) => void;
  archiveModule: (id: string) => void;
  restoreModule: (id: string) => void;
  reorderModules: (modules: AcademicModule[]) => void;

  // Unit CRUD
  addUnit: (unit: Omit<AcademicUnit, 'id'>) => { success: boolean; error?: string };
  updateUnit: (id: string, updates: Partial<AcademicUnit>) => { success: boolean; error?: string };
  toggleUnitStatus: (id: string) => void;
  archiveUnit: (id: string) => void;
  restoreUnit: (id: string) => void;
  reorderUnits: (units: AcademicUnit[]) => void;

  // Selectors for Shared Source of Truth
  getSharedAcademicSourceOfTruth: () => SharedAcademicSourceOfTruth;
  getSubjectsByBranchAndScheme: (branchCode?: string, schemeYear?: string, semester?: number) => AcademicSubject[];
  getModulesForSubject: (subjectId: string) => AcademicModule[];
  getUnitsForModule: (moduleId: string) => AcademicUnit[];
  validateHierarchyMapping: (
    branchCode: string,
    schemeYear: string,
    semester: number,
    subjectId: string,
    moduleId?: string,
    unitId?: string
  ) => { isValid: boolean; error?: string };
}

export const useAcademicStore = create<AcademicStore>((set, get) => ({
  branches: INITIAL_BRANCHES,
  schemes: INITIAL_SCHEMES,
  semesters: INITIAL_SEMESTERS,
  subjects: INITIAL_SUBJECTS,
  modules: INITIAL_MODULES,
  units: INITIAL_UNITS,

  // Branch operations
  addBranch: (branchData) => {
    const { branches } = get();
    if (branches.some((b) => b.code.toUpperCase() === branchData.code.toUpperCase())) {
      return { success: false, error: `Branch code '${branchData.code}' already exists.` };
    }
    const newBranch: AcademicBranch = {
      ...branchData,
      id: `b-${Date.now()}`,
    };
    set({ branches: [...branches, newBranch] });
    return { success: true };
  },

  updateBranch: (id, updates) => {
    const { branches } = get();
    if (updates.code) {
      const duplicate = branches.some(
        (b) => b.id !== id && b.code.toUpperCase() === updates.code!.toUpperCase()
      );
      if (duplicate) {
        return { success: false, error: `Branch code '${updates.code}' is already used.` };
      }
    }
    set((state) => ({
      branches: state.branches.map((b) => (b.id === id ? { ...b, ...updates } : b)),
    }));
    return { success: true };
  },

  toggleBranchStatus: (id) => {
    set((state) => ({
      branches: state.branches.map((b) =>
        b.id === id ? { ...b, status: b.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : b
      ),
    }));
  },

  archiveBranch: (id) => {
    set((state) => ({
      branches: state.branches.map((b) => (b.id === id ? { ...b, status: 'ARCHIVED' } : b)),
    }));
  },

  restoreBranch: (id) => {
    set((state) => ({
      branches: state.branches.map((b) => (b.id === id ? { ...b, status: 'ACTIVE' } : b)),
    }));
  },

  reorderBranches: (reordered) => {
    set({ branches: reordered });
  },

  // Scheme operations
  addScheme: (schemeData) => {
    const { schemes } = get();
    if (schemes.some((s) => s.year === schemeData.year)) {
      return { success: false, error: `Scheme year '${schemeData.year}' already exists.` };
    }
    const newScheme: AcademicScheme = {
      ...schemeData,
      id: `sc-${Date.now()}`,
    };
    set({ schemes: [...schemes, newScheme] });
    return { success: true };
  },

  updateScheme: (id, updates) => {
    const { schemes } = get();
    if (updates.year) {
      const duplicate = schemes.some((s) => s.id !== id && s.year === updates.year);
      if (duplicate) {
        return { success: false, error: `Scheme year '${updates.year}' already exists.` };
      }
    }
    set((state) => ({
      schemes: state.schemes.map((s) => (s.id === id ? { ...s, ...updates } : s)),
    }));
    return { success: true };
  },

  toggleSchemeStatus: (id) => {
    set((state) => ({
      schemes: state.schemes.map((s) =>
        s.id === id ? { ...s, status: s.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : s
      ),
    }));
  },

  archiveScheme: (id) => {
    set((state) => ({
      schemes: state.schemes.map((s) => (s.id === id ? { ...s, status: 'ARCHIVED' } : s)),
    }));
  },

  restoreScheme: (id) => {
    set((state) => ({
      schemes: state.schemes.map((s) => (s.id === id ? { ...s, status: 'ACTIVE' } : s)),
    }));
  },

  reorderSchemes: (reordered) => {
    set({ schemes: reordered });
  },

  // Semester operations
  addSemester: (semData) => {
    const { semesters } = get();
    if (semesters.some((s) => s.semesterNumber === semData.semesterNumber)) {
      return { success: false, error: `Semester ${semData.semesterNumber} already exists.` };
    }
    const newSem: AcademicSemester = {
      ...semData,
      id: `sem-${Date.now()}`,
    };
    set({ semesters: [...semesters, newSem].sort((a, b) => a.semesterNumber - b.semesterNumber) });
    return { success: true };
  },

  updateSemester: (id, updates) => {
    const { semesters } = get();
    if (updates.semesterNumber) {
      const duplicate = semesters.some((s) => s.id !== id && s.semesterNumber === updates.semesterNumber);
      if (duplicate) {
        return { success: false, error: `Semester ${updates.semesterNumber} already exists.` };
      }
    }
    set((state) => ({
      semesters: state.semesters.map((s) => (s.id === id ? { ...s, ...updates } : s)),
    }));
    return { success: true };
  },

  toggleSemesterStatus: (id) => {
    set((state) => ({
      semesters: state.semesters.map((s) =>
        s.id === id ? { ...s, status: s.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : s
      ),
    }));
  },

  archiveSemester: (id) => {
    set((state) => ({
      semesters: state.semesters.map((s) => (s.id === id ? { ...s, status: 'ARCHIVED' } : s)),
    }));
  },

  restoreSemester: (id) => {
    set((state) => ({
      semesters: state.semesters.map((s) => (s.id === id ? { ...s, status: 'ACTIVE' } : s)),
    }));
  },

  reorderSemesters: (reordered) => {
    set({ semesters: reordered });
  },

  // Subject operations with validation
  addSubject: (subjectData) => {
    const { subjects, branches, schemes } = get();
    // Validate Branch
    if (!branches.some((b) => b.code === subjectData.branchCode && b.status !== 'ARCHIVED')) {
      return { success: false, error: `Invalid or archived Branch code '${subjectData.branchCode}'.` };
    }
    // Validate Scheme
    if (!schemes.some((s) => s.year === subjectData.schemeYear && s.status !== 'ARCHIVED')) {
      return { success: false, error: `Invalid or archived Scheme '${subjectData.schemeYear}'.` };
    }
    // Validate Duplicate Subject Code in Scheme
    const duplicate = subjects.some(
      (s) =>
        s.code.toUpperCase() === subjectData.code.toUpperCase() &&
        s.schemeYear === subjectData.schemeYear
    );
    if (duplicate) {
      return {
        success: false,
        error: `Subject code '${subjectData.code}' already exists under the ${subjectData.schemeYear} Scheme.`,
      };
    }
    const newSubject: AcademicSubject = {
      ...subjectData,
      id: `subj-${Date.now()}`,
    };
    set({ subjects: [...subjects, newSubject] });
    return { success: true };
  },

  updateSubject: (id, updates) => {
    const { subjects, branches, schemes } = get();
    const target = subjects.find((s) => s.id === id);
    if (!target) return { success: false, error: 'Subject not found.' };

    const branch = updates.branchCode || target.branchCode;
    const scheme = updates.schemeYear || target.schemeYear;
    const code = updates.code || target.code;

    if (updates.branchCode && !branches.some((b) => b.code === branch)) {
      return { success: false, error: `Invalid Branch code '${branch}'.` };
    }
    if (updates.schemeYear && !schemes.some((s) => s.year === scheme)) {
      return { success: false, error: `Invalid Scheme year '${scheme}'.` };
    }

    const duplicate = subjects.some(
      (s) =>
        s.id !== id &&
        s.code.toUpperCase() === code.toUpperCase() &&
        s.schemeYear === scheme
    );
    if (duplicate) {
      return {
        success: false,
        error: `Subject code '${code}' is already used in scheme ${scheme}.`,
      };
    }

    set((state) => ({
      subjects: state.subjects.map((s) => (s.id === id ? { ...s, ...updates } : s)),
    }));
    return { success: true };
  },

  toggleSubjectStatus: (id) => {
    set((state) => ({
      subjects: state.subjects.map((s) =>
        s.id === id ? { ...s, status: s.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : s
      ),
    }));
  },

  archiveSubject: (id) => {
    set((state) => ({
      subjects: state.subjects.map((s) => (s.id === id ? { ...s, status: 'ARCHIVED' } : s)),
    }));
  },

  restoreSubject: (id) => {
    set((state) => ({
      subjects: state.subjects.map((s) => (s.id === id ? { ...s, status: 'ACTIVE' } : s)),
    }));
  },

  reorderSubjects: (reordered) => {
    set({ subjects: reordered });
  },

  // Module operations
  addModule: (moduleData) => {
    const { modules, subjects } = get();
    if (!subjects.some((s) => s.id === moduleData.subjectId)) {
      return { success: false, error: 'Target subject entity does not exist.' };
    }
    const duplicateMod = modules.some(
      (m) => m.subjectId === moduleData.subjectId && m.moduleNumber === moduleData.moduleNumber
    );
    if (duplicateMod) {
      return {
        success: false,
        error: `Module Number ${moduleData.moduleNumber} already exists for this subject.`,
      };
    }
    const newModule: AcademicModule = {
      ...moduleData,
      id: `mod-${Date.now()}`,
    };
    set({ modules: [...modules, newModule] });
    return { success: true };
  },

  updateModule: (id, updates) => {
    const { modules } = get();
    const target = modules.find((m) => m.id === id);
    if (!target) return { success: false, error: 'Module not found.' };

    if (updates.moduleNumber) {
      const duplicate = modules.some(
        (m) =>
          m.id !== id &&
          m.subjectId === target.subjectId &&
          m.moduleNumber === updates.moduleNumber
      );
      if (duplicate) {
        return {
          success: false,
          error: `Module Number ${updates.moduleNumber} already exists for this subject.`,
        };
      }
    }

    set((state) => ({
      modules: state.modules.map((m) => (m.id === id ? { ...m, ...updates } : m)),
    }));
    return { success: true };
  },

  toggleModuleStatus: (id) => {
    set((state) => ({
      modules: state.modules.map((m) =>
        m.id === id ? { ...m, status: m.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : m
      ),
    }));
  },

  archiveModule: (id) => {
    set((state) => ({
      modules: state.modules.map((m) => (m.id === id ? { ...m, status: 'ARCHIVED' } : m)),
    }));
  },

  restoreModule: (id) => {
    set((state) => ({
      modules: state.modules.map((m) => (m.id === id ? { ...m, status: 'ACTIVE' } : m)),
    }));
  },

  reorderModules: (reordered) => {
    set({ modules: reordered });
  },

  // Unit operations
  addUnit: (unitData) => {
    const { units, modules } = get();
    if (!modules.some((m) => m.id === unitData.moduleId)) {
      return { success: false, error: 'Target module does not exist.' };
    }
    const newUnit: AcademicUnit = {
      ...unitData,
      id: `u-${Date.now()}`,
    };
    set({ units: [...units, newUnit] });
    return { success: true };
  },

  updateUnit: (id, updates) => {
    set((state) => ({
      units: state.units.map((u) => (u.id === id ? { ...u, ...updates } : u)),
    }));
    return { success: true };
  },

  toggleUnitStatus: (id) => {
    set((state) => ({
      units: state.units.map((u) =>
        u.id === id ? { ...u, status: u.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : u
      ),
    }));
  },

  archiveUnit: (id) => {
    set((state) => ({
      units: state.units.map((u) => (u.id === id ? { ...u, status: 'ARCHIVED' } : u)),
    }));
  },

  restoreUnit: (id) => {
    set((state) => ({
      units: state.units.map((u) => (u.id === id ? { ...u, status: 'ACTIVE' } : u)),
    }));
  },

  reorderUnits: (reordered) => {
    set({ units: reordered });
  },

  // Selectors for Shared Source of Truth across features
  getSharedAcademicSourceOfTruth: () => {
    const { branches, schemes, semesters, subjects, modules, units } = get();
    return { branches, schemes, semesters, subjects, modules, units };
  },

  getSubjectsByBranchAndScheme: (branchCode, schemeYear, semester) => {
    const { subjects } = get();
    return subjects.filter(
      (s) =>
        (!branchCode || branchCode === 'ALL' || s.branchCode === branchCode) &&
        (!schemeYear || schemeYear === 'ALL' || s.schemeYear === schemeYear) &&
        (!semester || semester === 0 || s.semester === semester)
    );
  },

  getModulesForSubject: (subjectId) => {
    const { modules } = get();
    return modules
      .filter((m) => m.subjectId === subjectId)
      .sort((a, b) => a.moduleNumber - b.moduleNumber);
  },

  getUnitsForModule: (moduleId) => {
    const { units } = get();
    return units
      .filter((u) => u.moduleId === moduleId)
      .sort((a, b) => a.unitNumber - b.unitNumber);
  },

  validateHierarchyMapping: (branchCode, schemeYear, semester, subjectId, moduleId, unitId) => {
    const { branches, schemes, semesters, subjects, modules, units } = get();
    const branch = branches.find((b) => b.code === branchCode);
    if (!branch) return { isValid: false, error: `Invalid branch '${branchCode}'` };

    const scheme = schemes.find((s) => s.year === schemeYear);
    if (!scheme) return { isValid: false, error: `Invalid scheme '${schemeYear}'` };

    const sem = semesters.find((s) => s.semesterNumber === semester);
    if (!sem) return { isValid: false, error: `Invalid semester ${semester}` };

    const subject = subjects.find((s) => s.id === subjectId);
    if (!subject) return { isValid: false, error: `Invalid subject ID '${subjectId}'` };

    if (subject.branchCode !== branchCode || subject.schemeYear !== schemeYear || subject.semester !== semester) {
      return {
        isValid: false,
        error: `Subject ${subject.code} does not belong to ${branchCode} / ${schemeYear} / Sem ${semester}`,
      };
    }

    if (moduleId) {
      const moduleItem = modules.find((m) => m.id === moduleId);
      if (!moduleItem || moduleItem.subjectId !== subjectId) {
        return { isValid: false, error: `Module ${moduleId} does not belong to subject ${subject.code}` };
      }

      if (unitId) {
        const unitItem = units.find((u) => u.id === unitId);
        if (!unitItem || unitItem.moduleId !== moduleId) {
          return { isValid: false, error: `Unit ${unitId} does not belong to module ${moduleId}` };
        }
      }
    }

    return { isValid: true };
  },
}));
